import logging
import socket
import threading
import time
import weakref
from contextlib import ExitStack, nullcontext

from Core.Crypto import Crypto, CryptoError
from Database.DatabaseManager import DataBase
from Logic.ClubService import ClubService
from Logic.Device import Device
from Logic.GameRoomGateway import GameRoomGateway
from Logic.GameRoomService import GameRoomService
from Logic.Player import Players
from Logic.PresenceService import PresenceService
from Logic.SeasonService import SeasonService
from Packets.LogicMessageFactory import packets
from Packets.Messages.Server.NotifAdd import LogicAddNotificationCommand
from Packets.Messages.Server.LobbyInfoMessage import LobbyInfoMessage
from Packets.Messages.Server.Friend.FriendListMessage import FriendListMessage
from Packets.Messages.Server.Alliance.Alliance_Data_Message import AllianceDataMessage
from Utils.Config import Config
from Utils.Helpers import Helpers


LOGGER = logging.getLogger(__name__)


class Server:
    Clients = {"ClientCounts": 0, "Clients": {}}
    SEASON_PUSH_LEAD = 0.5

    def __init__(self, ip=None, port=None):
        settings = Config.GetValue()
        self.ip = ip if ip is not None else settings.get("ServerIP", "0.0.0.0")
        self.port = port if port is not None else settings.get("ServerPort", 9339)
        self.max_packet_size = settings.get("MaxPacketSize", 1024 * 1024)
        self.crypto_settings = settings.get("Crypto", {"Enabled": True})
        self.clients_lock = threading.RLock()
        self._account_locks = weakref.WeakValueDictionary()
        self._account_locks_guard = threading.Lock()
        self.Clients = {"ClientCounts": 0, "Clients": {}, "RegistryLock": self.clients_lock, "AccountLock": self.account_lock}
        self._season_timer_lock = threading.Lock()
        self._season_timers = {}
        self.running = False
        self.scid_client = None
        PresenceService.bind_clients(self.Clients)

        self.server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

    def start_scid(self):
        settings = Config.GetValue()
        from SCIDClient.Runtime import set_service
        if not settings.get("SCID", {}).get("Enabled", True):
            set_service(None)
            return None
        from SCIDClient.Remote import RemoteSCIDClient
        if self.scid_client is None:
            self.scid_client = RemoteSCIDClient(settings)
        set_service(self.scid_client)
        print("SCIDClient | Integração remota configurada")
        return None

    def stop_scid(self):
        from SCIDClient.Runtime import set_service
        set_service(None)
        self.scid_client = None

    def start(self):
        settings = Config.GetValue()
                                                                             
                                                  
        Crypto(self.crypto_settings)
        migration = ClubService.migrate_legacy()
        if any(migration.values()):
            print(f"Server | Legacy club migration: {migration}")
        GameRoomService.init()
        self.running = True
        self.server.bind((self.ip, self.port))
        self.port = self.server.getsockname()[1]
        self.server.listen()

        version = (
            f"{settings['ClientMajor']}."
            f"{settings['ClientMinor']}."
            f"{settings['ClientBuild']}"
        )
        transport = (
            "V13 crypto ATIVADA" if self.crypto_settings.get("Enabled", True)
            else "raw V13 transport"
        )
        print(f"Server | NostBrawl R120 V13 - client {version}")
        print(f"Server | Listening on {self.ip}:{self.port} ({transport})")
        print(
            "Server | SQLite: "
            f"{settings.get('Database', {}).get('Path', 'Database/players.sqlite')}"
        )

        try:
            while self.running:
                client, address = self.server.accept()
                client.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, True)
                Helpers.PlayersCount += 1
                print(f"Server | New connection from {address[0]}:{address[1]}")
                ClientThread(client, address, self).start()
        finally:
            self.running = False
            self.stop_scid()
            self.server.close()

    def account_lock(self, low_id):
        key = int(low_id or 0)
        with self._account_locks_guard:
            lock = self._account_locks.get(key)
            if lock is None:
                lock = threading.RLock()
                self._account_locks[key] = lock
            return lock

    def _cancel_season_timer(self, key, client=None):
        with self._season_timer_lock:
            timer = self._season_timers.get(key)
            if timer is None or (client is not None and timer.session_client is not client):
                return
            del self._season_timers[key]
        timer.cancel()

    def _deliver_season_notification(self, player, client, key, notification):
        try:
            LogicAddNotificationCommand(
                client, player, None, notification=notification
            ).send()
        except OSError as error:
            LOGGER.warning("Season notification delivery failed for %s: %s", key, error)

    def schedule_season(self, player, client):
        with self.account_lock(getattr(player, "low_id", 0)):
            return self._schedule_season_locked(player, client)

    def _schedule_season_locked(self, player, client):
        key = str(getattr(player, "low_id", 0))
        with self.clients_lock:
            current = self.Clients["Clients"].get(key)
            if not current or current["SocketInfo"] is not client:
                return None
            if not SeasonService.is_persistent(player) or not getattr(player, "logged_in", False):
                self._cancel_season_timer(key, client)
                return None
        result = SeasonService.sync(player)
        delay = max(
            0.0,
            result["endsAt"] - time.time() - self.SEASON_PUSH_LEAD,
        )
        timer = threading.Timer(
            delay,
            self._season_timer_fired,
            args=(player, client, key, result["endsAt"]),
        )
        timer.daemon = True
        timer.session_client = client
        with self.clients_lock:
            current = self.Clients["Clients"].get(key)
            if not current or current["SocketInfo"] is not client:
                return None
            self._cancel_season_timer(key)
            with self._season_timer_lock:
                self._season_timers[key] = timer
            timer.start()
        if result["reset"] and result["notification"] is not None:
            self._deliver_season_notification(
                player, client, key, result["notification"]
            )
        return timer

    def _season_timer_fired(self, player, client, key, expected_ends_at):
        with self.account_lock(getattr(player, "low_id", 0)):
            self._season_timer_fired_locked(player, client, key, expected_ends_at)

    def _season_timer_fired_locked(self, player, client, key, expected_ends_at):
        with self.clients_lock:
            current = self.Clients["Clients"].get(key)
        if not current or current["SocketInfo"] is not client:
            return
        if not getattr(player, "logged_in", False):
            return
        season = getattr(player, "progression", {}).get(SeasonService.STATE_KEY, {})
        if season.get("endsAt") != expected_ends_at:
            return
        try:
            result = SeasonService.end_now(
                player,
                now=expected_ends_at,
                expected_ends_at=expected_ends_at,
            )
            if result is not None:
                self._deliver_season_notification(
                    player, client, key, result["notification"]
                )
            self.schedule_season(player, client)
        except Exception:
            LOGGER.exception("Season timer failed for account %s", key)

    def register_client(self, player, client, address=None):
        with self.account_lock(getattr(player, "low_id", 0)):
            return self._register_client_locked(player, client, address)

    def _register_client_locked(self, player, client, address=None):
        key = str(player.low_id)
        with self.clients_lock:
            previous = self.Clients["Clients"].get(key)
        old_send_lock = previous.get("Lock") if previous is not None else None
        with old_send_lock or nullcontext(), self.clients_lock:
            self.Clients["RegistryLock"] = self.clients_lock
            self.Clients["AccountLock"] = self.account_lock
            now = int(time.time())
            if not DataBase.update_presence(player, int(getattr(player, "online", 1) or 0), now):
                raise ValueError("Conta não encontrada ao registrar presença")
            player.last_activity_at = now
            self.Clients["Clients"][str(player.low_id)] = {
                "SocketInfo": client,
                "Crypto": player.crypto,
                "Lock": player.send_lock,
                "Status": int(getattr(player, "online", 1) or 0),
                "StatusSince": now,
                "LastActivity": now,
                "Player": player,
            }
            self.Clients["ClientCounts"] = len(self.Clients["Clients"])
            player.ClientDict = self.Clients
            ClubService.refresh_online_player(player, player.low_id)
            from SCIDClient.GameSessions import GAME_SESSIONS
            GAME_SESSIONS.register(player, client, address)
        self.schedule_season(player, client)
        PresenceService.publish(player)
        print(f"Server | Account {player.low_id} logged in; players online: "
              f"{self.Clients['ClientCounts']}")

    def unregister_client(self, player, client):
        with self.account_lock(getattr(player, "low_id", 0)):
            return self._unregister_client_locked(player, client)

    def _unregister_client_locked(self, player, client):
        key = str(getattr(player, "low_id", 0))
        with self.clients_lock:
            current = self.Clients["Clients"].get(key)
        send_lock = current.get("Lock") if current and current["SocketInfo"] is client else None
        with send_lock or nullcontext(), self.clients_lock:
            current = self.Clients["Clients"].get(key)
            if current and current["SocketInfo"] is client:
                del self.Clients["Clients"][key]
                self._cancel_season_timer(key, client)
            self.Clients["ClientCounts"] = len(self.Clients["Clients"])
            from SCIDClient.GameSessions import GAME_SESSIONS
            GAME_SESSIONS.unregister(player, client)


class ClientThread(threading.Thread):
    def __init__(self, client, address, server):
        super().__init__(daemon=True)
        self.client = client
        self.address = address
        self.server = server
        self.device = Device(client)
        self.player = Players(self.device)
        self.player.crypto = Crypto(server.crypto_settings)
        self.player.ClientDict = server.Clients

    def recvall(self, length):
        """Read exactly length bytes; TCP recv is allowed to return less."""
        data = bytearray()
        while len(data) < length:
            chunk = self.client.recv(length - len(data))
            if not chunk:
                if not data:
                    return b""
                raise ConnectionError("Connection closed in the middle of a packet")
            data.extend(chunk)
        return bytes(data)

    def _finish_login(self, message):
        account_id = int(getattr(self.player, "low_id", 0) or 0)
        with self.server.account_lock(account_id):
            if not DataBase.loadAccount(message) or self.player.low_id != account_id:
                return message._fail(9, "Invalid account credentials.")
            if not message._send_success(defer_registration=True):
                return False
            if Config.GetValue().get("SendLobbyInfo", False):
                LobbyInfoMessage(self.client, self.player).send()
            self.server.register_client(self.player, self.client, self.address)
            FriendListMessage(self.client, self.player).send()
            club_id = int(getattr(self.player, "club_low_id", 0) or 0)
            if club_id:
                AllianceDataMessage(self.client, self.player, 0, club_id).send()
            PresenceService.sync_view(self.player)
            message._resume_room()
            return True

    def _dispatch(self, packet_id, data):
        message_class = packets.get(packet_id)
        if message_class is None:
            print(f"Client | Unhandled packet {packet_id}; length: {len(data)}")
            return
        message = message_class(self.client, self.player, data)
        if Config.GetValue().get("ShowPacketsInLog", False):
            print(
                f"Client | {message.__class__.__name__} received; "
                f"ID: {packet_id}. Length: {len(data)}"
            )
        if packet_id == 10101:
            message.account_lock = self.server.account_lock
            message.finish_login = self._finish_login
        message.decode()
        message.process()

    def _release_game_room(self):
        outcome = GameRoomService.disconnect(self.player)
        if outcome is None:
            return None
        room = outcome.get("room")
        if room is not None:
            GameRoomGateway.broadcast_data_and_stream(self.player, room)
        for member in outcome.get("disbanded", []):
            GameRoomGateway.send_left(
                self.player,
                int(member["low_id"]),
                reason=GameRoomService.DISBAND_REASON,
            )
            participant = member.get("_player")
            if participant is not None:
                GameRoomService.sync_presence(
                    participant, GameRoomService.HOME_PRESENCE
                )
        return outcome

    def _dispatch_account_ids(self, packet_id, data):
        ids = {int(self.player.low_id)}
        if packet_id == 14352:
            message_class = packets.get(packet_id)
            if message_class is not None:
                message = message_class(self.client, self.player, data)
                message.decode()
                if message.target_high_id == 0 and message.target_id > 0:
                    ids.add(int(message.target_id))
        return sorted(ids)

    def run(self):
        disconnect_reason = "connection loop ended"
        try:
            while True:
                header = self.recvall(7)
                if not header:
                    disconnect_reason = "client EOF (the APK closed the socket)"
                    break

                packet_id = int.from_bytes(header[:2], "big")
                length = int.from_bytes(header[2:5], "big")

                if length > self.server.max_packet_size:
                    disconnect_reason = f"invalid packet length {length} for ID {packet_id}"
                    LOGGER.warning(
                        "Closing %s: packet %s has invalid length %s",
                        self.address[0], packet_id, length,
                    )
                    break

                data = self.recvall(length) if length else b""
                try:
                                                                            
                                                                       
                    data = self.player.crypto.decrypt(packet_id, data)
                except CryptoError as error:
                    disconnect_reason = f"crypto error on packet {packet_id}: {error}"
                    LOGGER.warning(
                        "Cryptography error from %s on packet %s: %s",
                        self.address[0], packet_id, error,
                    )
                    break

                if getattr(self.player, "logged_in", False):
                    account_ids = self._dispatch_account_ids(packet_id, data)
                    with ExitStack() as locks:
                        for account_id in account_ids:
                            locks.enter_context(self.server.account_lock(account_id))
                        if not PresenceService.record_activity(self.player, self.client):
                            raise ConnectionError("Sessão substituída")
                        if packet_id == 10101:
                            raise ConnectionError("Login repetido na sessão autenticada")
                        self._dispatch(packet_id, data)
                else:
                    self._dispatch(packet_id, data)

        except (ConnectionError, ConnectionAbortedError, ConnectionResetError,
                BrokenPipeError, socket.timeout, OSError) as error:
            disconnect_reason = f"{type(error).__name__}: {error}"
        except ValueError as error:
            disconnect_reason = f"malformed packet: {error}"
            LOGGER.warning("Malformed packet from %s: %s", self.address[0], error)
        except Exception as error:
            disconnect_reason = f"server error: {type(error).__name__}: {error}"
            LOGGER.exception("Unhandled client error from %s", self.address[0])
        finally:
            battle = getattr(self.player, "battle_thread", None)
            if battle is not None:
                battle.started = 0
            with self.server.account_lock(getattr(self.player, "low_id", 0)):
                if getattr(self.player, "logged_in", False):
                    try:
                        self._release_game_room()
                    except Exception:
                        LOGGER.warning("Could not update %s in the active GameRoom",
                                       getattr(self.player, "low_id", 0))
                    try:
                        if PresenceService.set_status(self.player, 0, self.client, persist=True):
                            PresenceService.publish(self.player)
                    except Exception:
                        LOGGER.warning("Could not clear online state for %s",
                                       self.player.low_id)
                    self.player.logged_in = False

                self.server.unregister_client(self.player, self.client)
            try:
                self.client.close()
            except OSError:
                pass
            Helpers.PlayersCount = max(0, Helpers.PlayersCount - 1)
            print(f"Server | {self.address[0]} disconnected; reason: {disconnect_reason}")


if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(message)s",
    )
    server = Server()
    try:
        server.start_scid()
        server.start()
    except KeyboardInterrupt:
        print("\nServer | Server stopped")
    finally:
        server.running = False
        server.stop_scid()
        try:
            DataBase.resetOnlineStatus()
        except Exception:
            LOGGER.warning("Could not reset account online states during shutdown")
