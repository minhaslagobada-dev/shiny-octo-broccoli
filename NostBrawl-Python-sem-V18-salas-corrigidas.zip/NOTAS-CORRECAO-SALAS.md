# Correção de salas, convites e desconexões

Relato corrigido: ao sair de uma sala e aceitar um novo convite para ela o jogo fechava;
depois do fechamento o jogador continuava aparecendo na sala; convidá-lo de novo
também falhava.

## Causas encontradas

1. **Desconexão só marcava presença, não removia o jogador.**
   `GameRoomService.disconnect` mudava `status` para 0 e mantinha o membro na sala.
   O jogador ficava como "fantasma": aparecia na sala do anfitrião, ocupava vaga,
   bloqueava convites (`ALREADY_IN_TEAM`) e o `roomID` continuava gravado no SQLite.

2. **O histórico da equipe era reenviado inteiro em cada mensagem de stream.**
   `GameRoomService.stream()` devolvia todos os eventos da sala desde a criação, e o
   `TeamStreamMessage` (24131) era enviado assim para todos os membros. Quem saía e
   voltava recebia de novo o evento `103` (saída) do próprio jogador, além dos eventos
   anteriores à sua entrada - estado antigo sendo reprocessado pelo cliente, o que
   derrubava o APK no aceite.

3. **Convites e pedidos pendentes sobreviviam ao estado que os originou.**
   Convite cujo remetente já tinha saído continuava válido; convite marcado como
   offline continuava na sala depois de o destinatário voltar; pedido de entrada de
   quem caiu continuava na fila do anfitrião.

4. **Pedido de entrada reaproveitava o objeto de sessão do momento do pedido.**
   `respond_join_request` usava `request["member"]` criado no pedido, com o `Player`
   daquela sessão; se o solicitante tivesse reconectado, as mensagens iriam para um
   socket morto e o jogador atual não seria atualizado.

## Correções aplicadas

`Logic/GameRoomService.py`
- `disconnect(player)` agora executa a mesma transição de saída da equipe
  (`_exit_locked`): remove o membro, transfere/limpa `host`, grava `roomID = 0`,
  registra o evento `103`, remove convites e pedidos do jogador e, quando o anfitrião
  cai, dissolve a equipe liberando os demais (mesma regra já usada ao sair).
- `_exit_locked` centraliza a saída; `leave_transition` e `disconnect` usam o mesmo
  caminho (nada de duas regras diferentes para o mesmo evento).
- `_purge_player_references(low_id)` remove, em todas as salas, convites de que o
  jogador é remetente ou destinatário e pedidos de entrada que ele fez.
- `_drop_invites_of(room, low_id)` remove os convites ligados ao jogador na sala.
- `accept_invite` / `_take_invite` / `decline_invite_from` descartam convite cujo
  remetente não é mais membro da sala (estado inválido) em vez de aplicá-lo.
- `clear_offline_invites(player)` remove convites marcados como `INVITE_OFFLINE`
  destinados a quem acabou de logar, e avisa a sala (chamado no login).
- `stream_for(room, low_id)` devolve apenas os eventos posteriores à entrada daquele
  membro (`stream_from`), com `STREAM_LIMIT` de 64 entradas e poda automática; o
  evento de saída antigo nunca volta para quem reentra.
- `_member_for_join` reconstrói o membro com o `Player` da sessão atual (obtido do
  registro de clientes); se a sessão não existe mais, o pedido é apenas descartado.
- `_new_member`/`_attach_member` registram `stream_from` no momento da entrada.

`Logic/GameRoomGateway.py`
- `broadcast_data_and_stream` monta o `TeamStreamMessage` por destinatário usando
  `GameRoomService.stream_for`, em vez de reenviar o mesmo histórico completo a todos.

`main.py`
- `ClientThread._release_game_room()` trata o resultado da desconexão: atualiza a sala
  para os que ficaram, envia `TeamLeftMessage` (24125) com motivo de dissolução aos
  liberados e reajusta a presença deles para o menu.

`Packets/Messages/Client/Login/LoginMessage.py`
- `_resume_room` limpa convites offline antes de tentar retomar a sala.

## Testes

Novo arquivo `tests/test_room_crash_invite_regression.py` (10 casos, com sockets
reais e cliente falante do protocolo):

- sair, receber novo convite e aceitar entra na sala sem repetir eventos antigos;
- três ciclos seguidos de sair/convidar/aceitar, sempre com o stream apenas do evento
  de entrada;
- convidado que cai é removido da sala, do SQLite e da presença, e o anfitrião recebe
  os eventos atualizados;
- convidado que cai pode ser convidado e entrar de novo depois de relogar;
- anfitrião que cai dissolve a equipe, libera o convidado e envia 24125;
- convite deixado por anfitrião que saiu é descartado, sem efeito ao aceitar;
- pedido de entrada de jogador que caiu é descartado;
- sessão substituída não remove o membro da sessão atual;
- convite offline é removido quando o destinatário loga;
- stream limitado a 64 entradas e offsets por membro preservados.

Testes ajustados para o novo comportamento (o anterior descrevia o bug):
`tests/test_gamerooms.py` (dois casos de desconexão), `tests/test_gameroom_packets.py`
(stream de quem entra depois) e `tests/test_room_battle.py` (stream por membro).

Suíte completa: **476 testes, 538 subtestes, todos passando** no servidor original e
**477 testes, 567 subtestes** na versão sem o conjunto V18.

Também foi validado com o servidor real (`python3 main.py`) e clientes de protocolo:
criar sala, convidar, aceitar, sair, reconvidar, aceitar, derrubar a conexão do
convidado, reconvidar e entrar de novo - sem exceções no log do servidor.
