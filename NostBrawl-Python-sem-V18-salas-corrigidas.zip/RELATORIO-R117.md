# NostBrawl R117 — correção dos erros reproduzidos no log

## Ação imediata

**Não usar a R116.** A alteração do primeiro campo dos eventos na R116 foi uma regressão e é revertida integralmente nesta revisão. A R117 restaura o comportamento da home da R115 e corrige também a seleção de skin/brawler rejeitada no novo log.

O aceite visual do crash antigo continua dependendo de teste no APK/dispositivo; testes server-side não são apresentados como prova de renderização.

## 1. Showdown identificado como BountyHunter e ausência do 23456

### Evidência do log

O cliente enviou 14110 com:

- mapa 2, slot 2;
- modo resolvido pelo CSV como `BountyHunter`;
- resultado 9, rank 9 e 10 participantes;
- rejeição antes de qualquer `BattleResultMessage` 23456.

Na rotação dessa data, o slot 2 é Showdown no mapa 13 (`Survival1`, `BattleRoyale`). O mapa 2 é `Wanted4`, de `BountyHunter`.

### Causa

A R116 substituiu indevidamente `map_id` por `slot` no primeiro VInt de cada evento da home. Para o slot 2, o cliente passou a receber/usar o mapa 2, embora o DataRef continuasse indicando o mapa 13. Isso combinou a navegação do evento Showdown com um mapa de BountyHunter e produziu o resultado incompatível rejeitado pelo servidor.

### Correção

`OwnHomeDataMessage.py` voltou a enviar:

```text
map_id, slot, 0, timer, tokens, DataRef(15, map_id), status, ...
```

Nenhuma validação do BattleEnd foi enfraquecida. O resultado 9 continua inválido para BountyHunter e válido para Showdown; com o mapa 13 restaurado, o fluxo chega ao 23456.

## 2. Comando 506 rejeitado ao trocar skin e brawler

### Evidência do log

O mesmo `EndClientTurn` continha:

- 506: `DataRef(29,14)` — skin 14;
- 525: `DataRef(16,8)` — brawler 8.

O CSV confirma que a skin 14 pertence ao brawler 8. O servidor validava a skin contra o brawler anterior antes de processar o 525 e respondia `Skin e brawler não correspondem`.

### Correção

`LogicSelectSkinCommand.py` agora deriva o brawler da própria skin válida. Assim, o 506 seleciona o par correto e o 525 seguinte confirma a mesma seleção.

Permanecem obrigatórios:

- skin existente no CSV;
- brawler desbloqueado;
- skin possuída pela conta;
- gravação transacional e persistente.

Não houve desativação de validação nem concessão de skin/brawler.

## 3. Demais mensagens do log

- 201 e 203 são ecos de operações já contabilizadas; não são recompensas ignoradas.
- 514 trata a confirmação da notificação de skin e pode gerar `LogicSkinDataCommand`.
- 522 remove a tag de novo brawler.
- KeepAlive, PlayerStatus e ClientCapabilities não indicam falha nesse fluxo.

Essas mensagens não foram suprimidas e seus fluxos não foram alterados.

## Alterações em relação à R116

- `Packets/Messages/Server/Home/OwnHomeDataMessage.py`: reversão de uma linha, `slot` → `map_id`.
- `Packets/Commands/Client/LogicSelectSkinCommand.py`: seleção pelo brawler dono da skin, com todas as validações preservadas.
- `main.py`: banner operacional atualizado para `NostBrawl R117 V13`, permitindo confirmar a revisão no console.
- `tests/test_battle_end.py`: regressão integrada home/slot 2/mapa 13/Showdown/rank 9/10 participantes/23456.
- `tests/test_box_trophy_road.py`: payload real 506+525 da skin 14/brawler 8, persistência e bloqueio com brawler bloqueado.
- `tests/test_own_home_data_wire.py` e fixture: expectativa de mapa restaurada.
- `RELATORIO-R117.md`: este relatório.

`config.json`, banco, criptografia, SCID, BattleEnd, recompensas, economia, loja, rotação e demais funcionalidades permanecem inalterados.

## Controle negativo contra a R116

Os dois novos testes foram executados contra o código de produção da R116 e falharam exatamente como no relato:

- home: `(mapa usado=2, DataRef=13)` em vez de `(13,13)`;
- seleção: `(brawler=8, skin=0)` em vez de `(8,14)`.

Na R117, os mesmos testes passam.

## Resultados

| Verificação | Resultado |
|---|---|
| Testes focados de BattleEnd, comandos, home e protocolo | **129/129 OK** |
| Suíte completa | **389/389 OK**, 16,102 s |
| Showdown do slot 2 | mapa 13, `BattleRoyale`, rank/resultado 9, 10 participantes, resposta 23456 |
| Seleção real 506+525 | brawler 8/skin 14 persistidos; brawler bloqueado continua rejeitado |
| Fluxos integrados | **66/66 OK**; 61 mapas habilitados, 8 desabilitados, cinco eventos; replay e retorno à home verificados |
| Adversarial | 6 casos válidos, 622 truncamentos, 24 sufixos, 1200 mutações, 1000 entradas aleatórias, 8 mapas desabilitados, 6 cabeçalhos inválidos e 1 oversize; nenhuma falha inesperada |
| Processo | partidas consecutivas, replay imediato/após reinício, nova instância legítima e apresentação única aprovados |
| Ranqueado | cinco eventos com 24124, relogin, KeepAlive e zero pacotes malformados |
| Conta real em cópia | `status=ok`; mapas/home coerentes; banco original inalterado |
| Configuração de produção | inalterada pelos testes |

As validações anteriores de 700 tokens/dia, dobrador, fichas estrelas por evento/dia, idempotência, atomicidade, concorrência, falhas de gravação e persistência foram reexecutadas pela suíte.

## Limitação restante

A R117 corrige os erros novos demonstrados pelo log. Não há ADB/logcat ou renderização do APK neste ambiente, portanto **não se declara comprovado visualmente o desaparecimento do crash antigo ao voltar à home**. O teste de aceite deve verificar Showdown, Solo/3v3, partidas consecutivas, retorno ao menu e nova partida. Se ainda houver crash, será necessário o logcat do instante da falha para identificar a exceção nativa sem novas suposições.

## Preservação

- R115 e R116 não foram sobrescritas; a R116 fica preservada apenas como histórico e não deve ser implantada.
- O banco fornecido permaneceu somente leitura, com SHA-256 `5729c0764bae116f0e8f8c0d180c7e67060ffb81a4b85a46d5098a38d73d3577`.
- A entrega é um servidor completo, sem credenciais adicionadas e sem caches.
