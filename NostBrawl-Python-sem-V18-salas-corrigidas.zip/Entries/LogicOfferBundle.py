from Entries.LogicOfferItem import LogicOfferItem


class LogicOfferBundle:
    @staticmethod
    def encode(writer, offer, now):
        items = offer.get("items", [])
        if not 1 <= len(items) <= 3:
            raise ValueError("An offer requires between one and three items")
        writer.v(len(items))
        for item in items:
            LogicOfferItem.encode(writer, item)
        price = int(offer["price"])
        original_price = int(offer.get("originalPrice", price))
        writer.v(int(offer["currency"]))
        writer.v(price)
        writer.v(max(0, int(offer["expiresAt"]) - int(now)))
        writer.v(1 if offer.get("seen", False) else 0)
        writer.v(100)
        writer.boolean(bool(offer.get("purchased", False)))
        writer.v(0)
        writer.boolean(bool(offer.get("daily", False)))
        writer.v(original_price if original_price > price else 0)
        writer.s(str(offer.get("title", "")))
