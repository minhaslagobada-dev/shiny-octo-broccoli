# NostBrawl R110

Servidor completo V13 **13.283.1**, derivado da R109. A entrega contém somente o servidor; não inclui APK, patch nativo, dependências ou caches. R106, R107, R108 e R109 permanecem preservadas.

## Correções desta revisão

### BattleEnd 14110

- Solo e Duo agora exigem coerência entre o rank inicial e o rank final decodificados; fora de Showdown, o rank deve ser zero.
- `submitted_result` deve corresponder à equipe do único participante local. Nenhum participante local é criado para completar um pacote inválido.
- As oito locations marcadas como desabilitadas nos CSVs V13 são rejeitadas.
- Permanecem ativas as validações de quantidade, personagem, skin, equipe, flag local, tamanho de nome e ausência de bytes residuais.
- O fixture TCP antigo que enviava resultado fabricado `16` e rank `1` fora de Showdown foi corrigido para resultado e rank zero. Nenhuma validação foi enfraquecida para aceitar esse fixture.

### Contagem nativa de participantes

A LIB R101 ARM64, SHA-256 `ccba455df76597e1d0ff081a07bf5e0537ad555229ad1166588d66d75ebff4ae`, contém a função ativa `0xfce50`, também alcançada pela conversão de location em `0x159928`. A jump table foi decodificada diretamente. O caller `0x1009b8` lê o modo em `location+0xe8`, chama `0xfce50`, dimensiona um array com o retorno e grava essa quantidade no cabeçalho do array. Há ainda callers em `0x12aae8` e `0x2e43c4`.

| Modo nativo | Participantes |
| --- | ---: |
| CoinRush, BossFight, BountyHunter, LaserBall, AttackDefend e demais modos no ramo padrão | 6 |
| BattleRoyale Solo `6` | 10 |
| Survival `7` | 6 |
| Raid `8` | 3 |
| BattleRoyaleTeam Duo `9` | 10 |

BossFight já estava com seis e foi preservado. Survival estava incorretamente herdado com três; foi corrigido para seis de forma consistente em `GameRoomService`, `BattleParticipants`, StartLoading/replay e na validação do BattleEnd. Raid permanece com três. O verificador ponta a ponta agora falha se qualquer fluxo divergir dessa tabela.

A evidência ARM64 e os callers estão preservados em `sources/R107-battleend-native/r110-native-player-counts.asm` e `r110-native-player-counts.json`.

### Reader e entradas adversariais

`Utils/Reader.py::_read_exact` rejeita comprimento negativo ou maior que os bytes restantes antes de chamar `read(length)`. Isso impede alocações enormes causadas por mutations no comprimento de strings nativas. Não foi adicionado tratamento genérico de exceção para ocultar erro ou manter conexões inválidas.

## Escopo preservado

- Correções R109 de `mapID,mapSlot`, home, TeamCreate, variações e resposta `23456`.
- Perfil, Leaderboard, Gameroom, poder/skin, recompensas, replay e retorno à home.
- Criptografia, autenticação, LIB R101 e configuração existente.
- Início offline e `OnPlay` fora da sala; nenhum matchmaking ou batalha online foi adicionado.
- Nenhum patch nativo foi necessário e nenhuma funcionalidade não relacionada foi removida.

## Verificação

- Suíte integral na árvore: **345/345 testes aprovados**.
- Fluxos ponta a ponta na R110: **66/66**, cobrindo 61 locations habilitadas e cinco eventos; StartLoading, VisionUpdate, BattleEnd, resposta, recompensas, replay sem duplicação e retorno à home.
- Survival foi verificado com seis participantes nos mapas `27`, `29`, `39` e `68`; BossFight com seis e Raid com três.
- Fuzz adversarial: seis casos válidos, 622 truncamentos, 24 sufixos residuais, 1.200 mutations, 1.000 entradas aleatórias, oito mapas desabilitados, seis cabeçalhos inválidos e um payload oversize.
- Resultado do fuzz: `unexpectedExceptions=[]` e `failures=[]`. Das 1.200 mutations, 257 continuaram estruturalmente válidas e passaram por todas as validações; as demais foram rejeitadas.
- A entrega é extraída do ZIP e submetida novamente à suíte integral antes de ser apresentada.

Os relatórios ficam em `sources/R109-verification/end-to-end-report.json` e `adversarial-report.json`.

## Aceite real pendente

**A R110 não foi executada no APK neste ambiente.** Continua sem existir a captura bruta do pacote real de 124 bytes nem o resultado do teste no dispositivo. Os testes comprovam a implementação e as regressões do servidor, mas não substituem o aceite real. Por isso, não se declara que o erro original do APK esteja resolvido sem esse teste.
