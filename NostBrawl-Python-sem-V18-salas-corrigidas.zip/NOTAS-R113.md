# NostBrawl R113 — notas técnicas

## Escopo e aceite

A R113 preserva integralmente o ledger transacional, os UUIDs, as recompensas idempotentes e os estados persistentes de eventos da R112. As alterações desta revisão tratam a seleção de eventos 14362 e as versões nativas dos headers de BattleResult/home.

**A falha de seleção de eventos foi reproduzida e corrigida na origem. O crash visual após a partida ainda depende de aceite no APK:** as versões dos headers foram alinhadas à LIB R101, mas os testes de socket não emulam renderização e o log fornecido não contém uma nova sequência BattleEnd. Nenhum patch nativo foi aplicado.

## 1. TeamSetRankedLocationMessage 14362

### Causa raiz

Na LIB ARM64 R101, o getter é `0x4d9b58`, o encoder `0x29c53c` e o decoder `0x32dbe0`. Os dois campos são VInts. O construtor parametrizado `0x38fe74` e seus callers `0x1f50fc`, `0x1f5250` e `0x36e3b8` estabelecem a ordem `(map_id, slot)`.

O servidor tratava o primeiro VInt como slot e descartava o segundo. IDs de mapa fora dos slots causavam `Slot de evento inexistente`, resposta 24124 parcial e encerramento por `malformed packet`; quando o ID cabia no intervalo, podia selecionar o evento errado.

### Correção

- O decoder preserva `map_id` e `slot` na ordem nativa e continua exigindo o fim exato do payload.
- `GameRoomService.set_ranked_location` recebe os dois campos, resolve o slot pela rotação existente e exige que o mapa corresponda ao evento antes de alterar a sala.
- Slot zero, slot inexistente, mapa divergente, truncamento e trailing continuam sendo rejeitados. `EventRotation.resolve_slot` e o comando 503 não foram enfraquecidos nem alterados.

## 2. Versões dos headers de retorno

A entrada `getMessageVersion` das vtables R101 foi conferida contra mensagens já consistentes: Leaderboard 13, PlayerProfile 9 e LoginOk 1. A R113 define:

- `BattleResultMessage` 23456: versão **27**, da função nativa `0xb4fc0`;
- `OwnHomeDataMessage` 24101: versão **9**, da função nativa `0x1fa3a4`.

Os payloads, recompensas, home, transições e demais versões de mensagens não foram alterados. A correção do crash visual não é declarada sem teste no dispositivo.

## Arquivos alterados na R113

- `Packets/Messages/Client/Gameroom/TeamSetRankedLocationMessage.py`;
- `Logic/GameRoomService.py`;
- `Packets/Messages/Server/Battle/BattleResultMessage.py`;
- `Packets/Messages/Server/Home/OwnHomeDataMessage.py`;
- `main.py`, somente o identificador;
- `tests/test_ranked_location.py` e `tests/test_native_message_versions.py`, adicionados;
- `NOTAS-R113.md`, com o histórico R112 preservado abaixo.

## Verificação R113

- 37/37 testes focados de eventos, salas, batalha e headers;
- 368/368 testes na regressão completa;
- 66/66 fluxos integrados, incluindo Solo, Duo, 3v3, home e recompensas;
- adversarial sem falhas ou aceites inesperados;
- dois processos reais: replay imediato e após reinício idênticos, nova instância com nova recompensa e KeepAlive preservado;
- TCP real: criação de sala, seleção dos cinco eventos `[12,1]`, `[13,2]`, `[4,3]`, `[50,4]`, `[37,5]`, 24124 com mapa/slot corretos, relogin retomando o último evento e zero `malformed packet`;
- headers completos verificados para 23456/27 e 24101/9.

Os testes de transporte usam harness sem criptografia; o `config.json` entregue mantém criptografia e SCID ativados. O aceite visual no APK permanece pendente.

---

# NostBrawl R112 — notas técnicas

## Escopo e estado do aceite

Esta revisão preserva a R111 e concentra as alterações em dois defeitos reproduzidos: recompensas repetidas de BattleEnd e perda do estado de “NOVO EVENTO”. Também foram auditados a sequência BattleEnd → home, o framing de envio, o duplo login e os layouts nativos R101.

**Recompensas e eventos têm correção de origem e testes persistentes aprovados. O crash visual intermitente não é declarado resolvido:** o log disponível termina em EOF sem exceção nativa e não contém o plaintext necessário para atribuir o fechamento a 23456, 24101 ou à renderização. Nenhum patch nativo especulativo foi aplicado.

## 1. Recompensas duplicadas

### Causa raiz

A R111 correlacionava resultados pelo conteúdo e por histórico em `progression`, sem um UUID persistente por ciclo de partida. A marca de resultado e os saldos não formavam uma única transação canônica. Assim:

- repetir um resultado fora do histórico disponível podia aplicar a recompensa novamente;
- duas sessões podiam calcular sobre cópias diferentes e sobrescrever ou repetir atualizações;
- desconexão e reinício não tinham um registro permanente e recuperável do resultado já concluído.

A reprodução da R111 confirmou tanto a nova concessão após perda do histórico quanto a perda de atualização em processamento concorrente.

### Correção

- Foi criada a tabela SQLite `battle_reward_ledger`, com chave `(player_id, battle_id)`, índice de conteúdo e uma única instância corrente por conta.
- `OnPlay` e a transição para `ready` abrem ou recuperam um ciclo com UUID. Repetir `ready` enquanto o ciclo está aberto reutiliza o mesmo UUID; um novo ciclo depois do resultado distingue duas partidas idênticas.
- O hash SHA-256 do payload e o modo continuam sendo validados para correlacionar retransmissões. Resultados concluídos antigos permanecem recuperáveis, sem limite de 20 entradas ou expiração por tempo.
- Recompensa, estado relacional da conta e conclusão do ledger compartilham `BEGIN IMMEDIATE` e o mesmo commit SQLite.
- O cálculo usa uma cópia canônica carregada do banco dentro da transação. A memória da sessão só é atualizada depois do commit.
- Um replay lê `rewards_json`, devolve o resultado persistido e sincroniza a sessão com o estado canônico, sem conceder recursos novamente.
- Falha antes do commit desfaz saldo e conclusão; desconexão depois do commit permite recuperar o mesmo resultado no relogin.

A proteção vale para partidas registradas pela R112. Resultados anteriores à migração não possuem UUID/ledger retroativo e não foram convertidos a partir de um histórico incompleto.

## 2. “NOVO EVENTO” em toda inicialização

### Causa raiz

A R111 codificava o status dos eventos na home como o literal `1`. O comando 503 não consumia o sexto VInt do layout R101 e não separava visualização de coleta; não existia estado visualizado persistente por data e evento. Consequentemente, a home voltava a anunciar como novo algo já visualizado, e estados que não eram coleta podiam seguir o caminho de recompensa.

### Correção

- O 503 agora consome os quatro VInts base, o índice e o estado, conforme o decoder R101.
- O comando aceita slots 1–5 e estados 1–3. Slot 0 continua disponível apenas no alias interno já usado pelo GameRoom.
- Somente o estado 2 executa a coleta transacional. Estado 3 persiste visualização sem tokens; estado 1 não concede tokens.
- `eventStates` foi incorporado ao `progression` relacional já existente, sem banco ou cache paralelo.
- A home codifica o status persistido, sem inserir, remover ou reordenar campos.
- O fingerprint inclui data, mapa, modo, modificador principal, lista completa de modificadores e tokens. Virada de dia ou atualização real volta a status 1; um modificador secundário adicionado também é detectado.
- O histórico de coletas por data é preservado quando um evento é atualizado, evitando transformar atualização visual em recompensa duplicada.

## 3. BattleEnd, home e crash intermitente

### Evidências verificadas

- O fluxo real em TCP executou login, OnPlay, 14110, 23456, replay, 14109, 24101, 503, PlayerStatus e KeepAlive sem traceback e sem EOF inesperado.
- `Writer.send()` mantém encode/encrypt/sendall sob o lock do jogador; os envios por timer e por low ID também usam o lock correspondente.
- O registro de sockets não deixa o socket antigo remover o novo no duplo login. A existência de objetos `Player` separados reforça o uso do estado canônico do banco.
- O decoder R101 de 23456 corresponde aos campos enviados. O bloco final de milestones é opcional: o servidor envia o booleano falso, e o decoder não espera bytes desse objeto nesse caso.
- O layout V12 de milestones não foi copiado para a V13/R101.
- A home mantém os cinco VInts de evento antes do DataReference; nenhum sexto VInt foi inserido na home.

### Limitação restante

EOF no servidor registra fechamento do socket, não uma causa de crash no APK. Os testes de socket não executam a renderização nem o código nativo do dispositivo. Sem um log do cliente/tombstone da ocorrência, não há evidência para escolher um patch de memória, inserir milestones ou alterar a ordem das mensagens. O aceite desse sintoma continua dependente do APK.

## Arquivos alterados ou adicionados

### Banco e recompensas

- `Database/DatabaseManager.py`: schema v4, ledger, carga canônica na conexão existente e validação de colunas antes da consulta.
- `Logic/BattleInstances.py`: novo serviço de UUID, ciclo corrente e recuperação de resultados.
- `Logic/BattleRewardsManager.py`: cópia canônica, replay persistido e transação única.
- `Logic/Rewards.py`: escrita transacional na conexão existente e finalização pós-commit.
- `Packets/Messages/Client/Battle/AskForBattleEndMessage.py`: integração do UUID ao processamento do resultado.
- `Packets/Messages/Client/Battle/OnPlay.py`: abertura/recuperação do ciclo.
- `Packets/Messages/Client/Gameroom/TeamSetMemberReadyMessage.py`: integração do ciclo ao ready.
- `Packets/Messages/Client/Home/GoHomeFromOfflinePractiseMessage.py`: marcação do retorno à home.

### Eventos

- `Logic/EventRotation.py`: estados persistentes, coleta por data e fingerprint completo.
- `Packets/Commands/Client/LogicNewEventCommand.py`: índice/estado do 503 e validação pela rotação.
- `Packets/Messages/Server/Home/OwnHomeDataMessage.py`: status persistido na codificação já existente.

### Revisão e testes

- `main.py`: identificador de inicialização R112.
- `tests/test_battle_ledger.py`: oito testes de ledger, concorrência, falhas, reinício e migração.
- `tests/test_event_state.py`: sete testes de 503, persistência, home, virada de dia e atualizações.
- `tests/test_event_rotation.py`: coletas diretas ajustadas para o estado 2.
- `NOTAS-R112.md`: este relatório.

`Utils/Writer.py`, `Logic/BattleResultPayload.py`, os demais fluxos e o `config.json` não foram alterados pela R112.

## Resultados executados

- Regressão completa na staging reconstruída: **363/363 testes aprovados**.
- Testes focados de BattleEnd, ledger, eventos e recompensas: **52/52 aprovados**.
- Fluxos individuais e integrados: **66/66**, cobrindo 61 localizações habilitadas e 5 slots de evento, replay e retorno à home.
- Adversariais: **6 casos válidos, 622 truncamentos, 24 casos com trailing, 1.200 mutações, 1.000 entradas aleatórias, 8 mapas desabilitados, 6 headers inválidos e 1 entrada oversize**; `unexpectedExceptions=[]` e `failures=[]`.
- Processo real em duas execuções com o mesmo banco temporário:
  - replay imediato devolveu os mesmos 139 bytes de 23456 e manteve uma linha no ledger;
  - encerramento e novo processo preservaram conta, evento visualizado, recursos e resultado;
  - replay depois do reinício não alterou recursos nem ledger;
  - novo OnPlay com o mesmo conteúdo criou outro UUID e outra linha no ledger;
  - recursos passaram de 1005/1019/1 para 1011/1039/2 somente na nova partida;
  - PlayerStatus e KeepAlive depois da home mantiveram a sessão.
- Eventos: visualização persistiu entre processos; virada de dia voltou a status 1; coleta do novo dia ocorreu uma vez; atualização de modificador secundário voltou a status 1.

O teste de processo usou transporte raw somente no harness para permitir inspeção dos payloads. O `config.json` entregue permanece byte a byte igual ao da R111, com criptografia e SCID ativados. Não houve validação de renderização em APK/dispositivo nesta etapa.
