from contextlib import nullcontext

from Database.DatabaseManager import DataBase
from Utils.Config import Config

packet_settings = Config.GetValue()


class Writer:
    def __init__(self, client, endian: str = 'big'):
        self.client = client
        self.endian = endian
        self.buffer = b''
        self.native_v13 = False
        self._bit_index = 0

    def enable_native_v13(self):
        """Use the V13 ChecksumEncoder signed VInt and packed booleans."""
        self.native_v13 = True
        self._bit_index = 0
        return self

    def _align_native(self):
        self._bit_index = 0

    @staticmethod
    def _native_vint_bytes(value):
        value = int(value)
        if not -0x80000000 <= value <= 0x7FFFFFFF:
            raise ValueError("V13 VInt outside the signed 32-bit range")
        if -63 <= value <= 63:
            size = 1
        elif -8191 <= value <= 8191:
            size = 2
        elif -1048575 <= value <= 1048575:
            size = 3
        elif -134217727 <= value <= 134217727:
            size = 4
        else:
            size = 5

        unsigned = value & 0xFFFFFFFF
        first = unsigned & 0x3F
        if value < 0:
            first |= 0x40
        if size > 1:
            first |= 0x80
        encoded = bytearray([first])
        for group in range(1, size - 1):
            byte = (unsigned >> (6 + (group - 1) * 7)) & 0x7F
            encoded.append(byte | 0x80)
        if size > 1:
            if size == 5:
                encoded.append((unsigned >> 27) & 0x0F)
            else:
                encoded.append(
                    (unsigned >> (6 + (size - 2) * 7)) & 0x7F
                )
        return bytes(encoded)

    def size(self):
        return len(self.buffer)
    
    def getRaw(self):
        return self.buffer

    def writeBytes(self, data):
        if self.native_v13:
            self._align_native()
        self.buffer += data

    def writeInt(self, data, length=4):
        if self.native_v13:
            self._align_native()
        value = int(data)
        if value < 0:
                                                                       
                                                           
            value = (1 << (length * 8)) + value
        self.buffer += value.to_bytes(length, 'big', signed=False)

    def writeUInteger(self, integer: int, length: int = 1):
        if self.native_v13:
            self._align_native()
        self.buffer += integer.to_bytes(length, self.endian, signed=False)

    def writeArrayVint(self, data):
        for x in data:
            self.writeVint(x)

    def writeUInt8(self, integer: int):
        self.writeUInteger(integer)

    def writeLong(self, high, low):
        if self.native_v13:
            self._align_native()
        self.buffer += high.to_bytes(4, 'big') + low.to_bytes(4, 'big')

    def writeBoolean(self, boolean: bool):
        if self.native_v13:
            if self._bit_index == 0:
                self.buffer += b'\x00'
            if boolean:
                self.buffer = (
                    self.buffer[:-1]
                    + bytes([self.buffer[-1] | (1 << self._bit_index)])
                )
            self._bit_index = (self._bit_index + 1) & 7
            return
        if boolean:
            self.writeUInt8(1)
        else:
            self.writeUInt8(0)

    def writeHexa(self, data):
        if data:
            if self.native_v13:
                self._align_native()
            if data.startswith('0x'):
                data = data[2:]

            self.buffer += bytes.fromhex(''.join(data.split()).replace('-', ''))

    def _encode_payload(self):
        self.buffer = b''
        self._bit_index = 0
        self.encode()
        return self.buffer

    def _send_payload(self, client, crypter, raw_packet):
        packet = crypter.encrypt(self.id, raw_packet) if crypter else raw_packet
        header = self.id.to_bytes(2, 'big', signed=True)
        header += len(packet).to_bytes(3, 'big')
        header += getattr(self, 'version', 0).to_bytes(2, 'big')
                                                                             
                                             
        client.sendall(header + packet)
        return len(packet)

    def _log_sent(self, packet_length):
        if packet_settings["ShowPacketsInLog"] and self.id != 24109:
            print(
                f"Server | {self.__class__.__name__} sent! "
                f"Id: {self.id}. Payload length: {packet_length}"
            )

    def _can_deliver(self, low_id):
        return True

    def send(self):
        player = getattr(self, 'player', None)
        lock = getattr(player, 'send_lock', None) or nullcontext()
        with lock:
            if not self._can_deliver(getattr(player, 'low_id', 0)):
                return False
            raw_packet = self._encode_payload()
            crypter = getattr(player, 'crypto', None)
            packet_length = self._send_payload(self.client, crypter, raw_packet)
            self._log_sent(packet_length)

    def sendToAll(self):
        if self.player.club_low_id != 0:
            self.encode()
            packet = self.buffer
            self.buffer = self.id.to_bytes(2, 'big', signed=True)
            self.writeInt(len(packet), 3)
            if hasattr(self, 'version'):
                self.writeInt16(self.version)
            else:
                self.writeInt16(0)
            self.buffer += packet + b'\xff\xff\x00\x00\x00\x00\x00'
            for Client in range(self.player.ClientDict["ClientCounts"]):
                for client_id, value in self.player.ClientDict["Clients"].items():
                    DataBase.loadOtherAccount(self, int(client_id))
                    if self.ClubID == self.player.club_low_id:
                        self.player.ClientDict["Clients"][str(client_id)]["SocketInfo"].send(self.buffer)
                break
            if packet_settings["ShowPacketsInLog"] == True:
                print(f"Server | {self.__class__.__name__} was sended! Id: {self.id}. Length: {len(self.buffer)}")

    def sendToOthers(self):
        self.encode()
        packet = self.buffer
        self.buffer = self.id.to_bytes(2, 'big', signed=True)
        self.writeInt(len(packet), 3)
        if hasattr(self, 'version'):
            self.writeInt16(self.version)
        else:
            self.writeInt16(0)
        self.buffer += packet + b'\xff\xff\x00\x00\x00\x00\x00'
        for Client in range(self.player.ClientDict["ClientCounts"]):
            for client_id, value in self.player.ClientDict["Clients"].items():
                DataBase.loadOtherAccount(self, int(client_id))
                if client_id != self.player.low_id and self.ClubID == self.player.club_low_id:
                    self.player.ClientDict["Clients"][str(client_id)]["SocketInfo"].send(self.buffer)
            break
        if packet_settings["ShowPacketsInLog"] == True:
            print(f"Server | {self.__class__.__name__} was sended! Id: {self.id}. Length: {len(self.buffer)}")

    def sendWithLowID(self, low_id):
        registry = getattr(self.player, 'ClientDict', {})
        clients = registry.get('Clients', {})
        key = str(low_id)
        recipient = clients.get(key)
        if recipient is None:
            return False

        lock = recipient.get('Lock') or nullcontext()
        with lock:
            with registry.get('RegistryLock') or nullcontext():
                if clients.get(key) is not recipient:
                    return False
            if not self._can_deliver(low_id):
                return False
            raw_packet = self._encode_payload()
            try:
                packet_length = self._send_payload(
                    recipient['SocketInfo'], recipient.get('Crypto'), raw_packet
                )
            except OSError:
                return False
        self._log_sent(packet_length)
        return True

    def writeVint(self, data, rotate: bool = True):
        if self.native_v13:
            self._align_native()
            self.buffer += self._native_vint_bytes(data)
            return

        final = b''
        if data == 0:
            self.writeByte(0)
        else:
            data = (data << 1) ^ (data >> 31)
            while data:
                b = data & 0x7f

                if data >= 0x80:
                    b |= 0x80
                if rotate:
                    rotate = False
                    lsb = b & 0x1
                    msb = (b & 0x80) >> 7
                    b >>= 1
                    b = b & ~0xC0
                    b = b | (msb << 7) | (lsb << 6)

                final += b.to_bytes(1, 'big')
                data >>= 7
        self.buffer += final

    def writeString(self, string: str = None):
        if string is None:
            self.writeInt((2 ** 32) - 1)
        else:
            encoded = string.encode('utf-8')
            self.writeInt(len(encoded))
            self.buffer += encoded

    def writeCompressedString(self, value):
        from SCIDClient.Protocol import encode_compressed_string
        if self.native_v13:
            self._align_native()
        self.buffer += encode_compressed_string(value)

    def writeIntLittleEndian(self, data, length=4):
        if self.native_v13:
            self._align_native()
        self.buffer += int(data).to_bytes(length, "little", signed=False)

    def writeByte(self, data):
        self.writeInt(data, 1)

    def writeInt16(self, data):
        self.writeInt(data, 2)

    def writeScId(self, x, y):
        self.writeVint(x)
        if not self.native_v13 or x != 0:
            self.writeVint(y)