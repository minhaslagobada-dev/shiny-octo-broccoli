import copy
import json


class Config:
    DEFAULT_SETTINGS = {
        "ServerIP": "0.0.0.0",
        "ServerPort": 9339,
        "MaxPacketSize": 1048576,
        "ClientMajor": 13,
        "ClientMinor": 283,
        "ClientBuild": 1,
        "Region": "BR",
        "Database": {
            "Path": "Database/players.sqlite",
        },
        "SCID": {
            "Enabled": True,
            "RemoteUrl": "",
            "RemoteApiKey": "",
            "RemoteTimeoutSeconds": 10,
        },
        "Crypto": {
            "Enabled": True,
            "ServerPublicKey": "EB7C3639CA77E5BD6D5A7AF9FCFBF94AA9BBC5C5819CBBF2859AE60DE6CCD041",
            "ClientPrivateKey": "BB14D6FD2B7C9823EAEDB4338CB7237F61E422D23C4977F74ADA052702C0C62D",
        },
        "Gems": 999,
        "Gold": 100,
        "Tickets": 0,
        "Starpoints": 999999,
        "BrawlBoxTokens": 999,
        "BigBoxTokens": 0,
        "ExperiencePoints": 0,
        "Trophies": 999,
        "ShowPacketsInLog": True,
        "SendLobbyInfo": False,
        "BrawlersBox": True,
        "SkinsBox": False,
        "UniqueSkinsBox": True,
        "StarShelly": False,
        "WizardBarley": False,
        "ThemeID": 0,
        "SupportedContentCreator": "",
        "Maintenance": False,
        "MaintenanceTime": 3600,
        "SeasonDuration": "14d",
        "Patch": False,
        "PatchUrl": "",
        "UpdateUrl": "",
        "CoinEvent": False,
        "TokenEvent": False,
        "MapModifiers": {
            "1": False,
            "2": False,
            "3": False,
            "4": False,
            "5": False,
        },
        "BrawlerTrophies": 0,
        "BrawlerTrophiesForRank": 0,
        "BrawlerPowerLevel": 1,
        "BrawlerUpgradePoints": 0,
        "UnlockedBrawlersOption": "Off",
        "UnlockedBrawler": [{"shelly": 1}],
    }

    def create_config():
        with open("config.json", "w", encoding="utf-8") as config_file:
            json.dump(Config.DEFAULT_SETTINGS, config_file, indent=2)
            config_file.write("\n")

    def GetValue():
        with open("config.json", "r", encoding="utf-8") as config_file:
            user_settings = json.load(config_file)

                                                                               
        settings = copy.deepcopy(Config.DEFAULT_SETTINGS)
        settings.update(user_settings)
        if "SCID" in user_settings:
            scid = copy.deepcopy(Config.DEFAULT_SETTINGS["SCID"])
            scid.update(user_settings["SCID"])
            settings["SCID"] = scid
        return settings
