from contextlib import nullcontext
import time


class PresenceService:
    _clients = None

    @classmethod
    def bind_clients(cls, clients):
        cls._clients = clients

    @classmethod
    def status(cls, low_id, persisted=0, clients=None):
        registry = cls._clients if clients is None else clients
        if registry is None:
            try:
                return int(persisted or 0)
            except (TypeError, ValueError):
                return 0
        recipient = registry.get("Clients", {}).get(str(int(low_id)))
        if recipient is None:
            return 0
        try:
            return int(recipient.get("Status", 0) or 0)
        except (TypeError, ValueError):
            return 0

    @staticmethod
    def elapsed(status, last_activity_at, now=None):
        if int(status) not in (0, 6):
            return 0
        if last_activity_at is None:
            return -1
        now = int(time.time()) if now is None else int(now)
        return min(0x7fffffff, max(0, now - int(last_activity_at)))

    @classmethod
    def record_activity(cls, player, client):
        registry = getattr(player, "ClientDict", None) or cls._clients
        lock = registry.get("RegistryLock") if registry is not None else None
        with lock or nullcontext():
            recipient = None if registry is None else registry.get("Clients", {}).get(
                str(int(getattr(player, "low_id", 0) or 0))
            )
            if recipient is None or recipient.get("SocketInfo") is not client:
                return False
            now = int(time.time())
            if recipient.get("LastActivity") != now:
                from Database.DatabaseManager import DataBase
                DataBase.record_activity(player, now)
                recipient["LastActivity"] = now
            player.last_activity_at = now
            return True

    @classmethod
    def set_status(cls, player, status, client=None, persist=False):
        status = int(status)
        registry = getattr(player, "ClientDict", None) or cls._clients
        lock = registry.get("RegistryLock") if registry is not None else None
        with lock or nullcontext():
            recipient = None if registry is None else registry.get("Clients", {}).get(
                str(int(getattr(player, "low_id", 0) or 0))
            )
            if client is not None and registry is not None and (
                recipient is None or recipient.get("SocketInfo") is not client
            ):
                return False
            if persist:
                from Database.DatabaseManager import DataBase
                now = int(time.time())
                if not DataBase.update_presence(player, status, now):
                    raise ValueError("Conta não encontrada ao atualizar presença")
                player.last_activity_at = now
                if recipient is not None:
                    recipient["LastActivity"] = now
            player.online = status
            if recipient is not None:
                if int(recipient.get("Status", 0) or 0) != status:
                    recipient["StatusSince"] = int(time.time())
                recipient["Status"] = status
            return True

    @staticmethod
    def social_peers(account_id):
        from Database.DatabaseManager import DataBase

        account_id = int(account_id)
        with DataBase._connection() as connection:
            rows = connection.execute(
                "SELECT friend_id FROM friend_relations WHERE owner_id = ? AND state = 4 "
                "UNION SELECT other.player_id FROM club_members own "
                "JOIN club_members other ON own.club_id = other.club_id "
                "WHERE own.player_id = ? AND other.player_id <> ?",
                (account_id, account_id, account_id),
            ).fetchall()
        return sorted(int(row[0]) for row in rows)

    @staticmethod
    def _related(subject_id, recipient_id):
        from Database.DatabaseManager import DataBase

        with DataBase._connection() as connection:
            row = connection.execute(
                "SELECT 1 FROM friend_relations WHERE owner_id = ? AND friend_id = ? AND state = 4 "
                "UNION SELECT 1 FROM club_members a JOIN club_members b ON a.club_id = b.club_id "
                "WHERE a.player_id = ? AND b.player_id = ? LIMIT 1",
                (recipient_id, subject_id, recipient_id, subject_id),
            ).fetchone()
        return row is not None

    @classmethod
    def sync_subject(cls, sender, subject_id, recipient_id):
        from Packets.Messages.Server.Friend.FriendOnlineStatusEntryMessage import FriendOnlineStatusEntryMessage

        subject_id, recipient_id = int(subject_id), int(recipient_id)
        if subject_id <= 0 or recipient_id <= 0 or subject_id == recipient_id:
            return False
        registry = getattr(sender, "ClientDict", None) or cls._clients
        if registry is None:
            return False
        clients = registry.get("Clients", {})
        recipient = clients.get(str(recipient_id))
        if recipient is None:
            return False
        lock = recipient.get("Lock") or nullcontext()
        with lock:
            registry_lock = registry.get("RegistryLock") or nullcontext()
            with registry_lock:
                if clients.get(str(recipient_id)) is not recipient:
                    return False
                subject = clients.get(str(subject_id))
                status = int(subject.get("Status", 0) or 0) if subject else 0
                since = int(subject.get("StatusSince", time.time())) if subject else 0
            permitted = cls._related(subject_id, recipient_id)
            eligible = 0 <= status < 12 and bool((1 << status) & 0xfbe)
            remove = FriendOnlineStatusEntryMessage(None, sender, subject_id)
            try:
                length = remove._send_payload(recipient["SocketInfo"], recipient.get("Crypto"), remove._encode_payload())
                remove._log_sent(length)
                if permitted and eligible:
                    elapsed = min(0x7fffffff, max(0, int(time.time()) - since))
                    update = FriendOnlineStatusEntryMessage(None, sender, subject_id, status, elapsed)
                    length = update._send_payload(recipient["SocketInfo"], recipient.get("Crypto"), update._encode_payload())
                    update._log_sent(length)
            except OSError:
                return False
        return True

    @classmethod
    def sync_view(cls, player):
        owner = int(getattr(player, "low_id", 0) or 0)
        return sum(cls.sync_subject(player, subject, owner) for subject in cls.social_peers(owner))

    @classmethod
    def sync_pair(cls, player, other_id):
        owner, other_id = int(getattr(player, "low_id", 0) or 0), int(other_id)
        return (cls.sync_subject(player, other_id, owner), cls.sync_subject(player, owner, other_id))

    @classmethod
    def publish(cls, player):
        from Logic.ClubService import ClubService
        from Logic.FriendService import FriendService

        owner = int(getattr(player, "low_id", 0) or 0)
        return {
            "friends": FriendService.push_presence(player),
            "club": ClubService.push_presence(player),
            "social_status": sum(cls.sync_subject(player, owner, peer) for peer in cls.social_peers(owner)),
        }
