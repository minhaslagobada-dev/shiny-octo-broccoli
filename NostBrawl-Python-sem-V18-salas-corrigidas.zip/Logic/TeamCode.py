class TeamCode:
    PREFIX = "X"
    ALPHABET = "QWERTYUPASDFGHJKLZCVBNM23456789"
    MAX_LOW_ID = 0x7FFFFFFF
    MAX_VALUE = (MAX_LOW_ID << 8) | 0xFF

    @classmethod
    def to_code(cls, high_id, low_id):
        try:
            high_id = int(high_id)
            low_id = int(low_id)
        except (TypeError, ValueError):
            raise ValueError("Código de equipe inválido") from None
        if not 0 <= high_id < 256 or not 0 <= low_id <= cls.MAX_LOW_ID:
            raise ValueError("Código de equipe inválido")
        value = (low_id << 8) | high_id
        encoded = ""
        base = len(cls.ALPHABET)
        while value:
            value, index = divmod(value, base)
            encoded = cls.ALPHABET[index] + encoded
        return cls.PREFIX + encoded

    @classmethod
    def to_id(cls, code):
        if not isinstance(code, str) or not 1 <= len(code) < 14:
            raise ValueError("Código de equipe inválido")
        if not code.startswith(cls.PREFIX):
            raise ValueError("Código de equipe inválido")
        value = 0
        base = len(cls.ALPHABET)
        for character in code[1:]:
            index = cls.ALPHABET.find(character)
            if index < 0:
                raise ValueError("Código de equipe inválido")
            value = value * base + index
            if value > cls.MAX_VALUE:
                raise ValueError("Código de equipe inválido")
        high_id = value & 0xFF
        low_id = value >> 8
        return high_id, low_id
