import copy
import hashlib
import json
import random
import threading
import time
from datetime import datetime, timedelta, timezone

from Entries.LogicOfferBundle import LogicOfferBundle
from Files.CsvLogic.Cards import Cards
from Files.CsvLogic.Characters import Characters
from Files.CsvLogic.Skins import Skins
from Logic.BoxInventory import BoxInventory
from Logic.BoxService import apply_box_opening
from Logic.RewardDelivery import RewardDelivery
from Logic.Rewards import MAX_POWER_POINTS, RewardError, RewardTransaction
from Logic.ShopCatalog import ShopCatalog
from Utils.Config import Config


class ShopService:
    STATE_KEY = "shop"
    STATE_VERSION = 7
    COMBINED_BOX_OFFERS = frozenset({"gems_big_mega"})
    MAX_DAILY_POWER_OFFERS = 5
    STAR_POWER_DAILY_CHANCE = 5
    STAR_POWER_PRICE = 2000
    WEEKEND_TICKET_AMOUNT = 2
    WEEKEND_TICKET_STATE_KEY = "weekendTickets"
    WEEKEND_TICKET_HISTORY = 16
    _weekend_ticket_lock = threading.RLock()
    RETIRED_OFFER_KEYS = frozenset({
        "coins", "token_doubler", "mega_box", "resource_bundle",
        "box_bundle", "daily_bundle",
    })

    @staticmethod
    def _timestamp(now=None):
        return int(time.time() if now is None else now)

    @staticmethod
    def _day(now):
        return datetime.fromtimestamp(now, timezone.utc).date().isoformat()

    @staticmethod
    def _next_day(now):
        current = datetime.fromtimestamp(now, timezone.utc)
        following = current.date() + timedelta(days=1)
        return int(datetime.combine(
            following, datetime.min.time(), timezone.utc
        ).timestamp())

    @staticmethod
    def _weekend_key(now):
        current = datetime.fromtimestamp(now)
        if current.weekday() < 5:
            return None
        saturday = current.date() - timedelta(days=current.weekday() - 5)
        return saturday.isoformat()

    @classmethod
    def sync_weekend_tickets(cls, player, now=None):
        now = cls._timestamp(now)
        weekend = cls._weekend_key(now)
        if weekend is None:
            return False
        try:
            persistent = int(getattr(player, "low_id", 0) or 0) > 0
        except (TypeError, ValueError):
            persistent = False
        token = getattr(player, "token", None)
        if (
            not persistent
            or not isinstance(token, str)
            or not token
            or token == "None"
        ):
            return False
        with cls._weekend_ticket_lock:
            progression = getattr(player, "progression", {})
            stored = (
                progression.get(cls.WEEKEND_TICKET_STATE_KEY, {})
                if isinstance(progression, dict)
                else {}
            )
            claims = (
                stored.get("claims", {})
                if isinstance(stored, dict)
                else {}
            )
            if not isinstance(claims, dict):
                claims = {}
            claims = {
                str(key): True
                for key, value in claims.items()
                if value is True
            }
            if claims.get(weekend) is True:
                return False
            retained = sorted(claims)[-cls.WEEKEND_TICKET_HISTORY + 1:]
            claims = {key: True for key in retained}
            claims[weekend] = True
            transaction = RewardTransaction(player)
            transaction.add_reward("tickets", cls.WEEKEND_TICKET_AMOUNT)
            transaction.set_progression_value(cls.WEEKEND_TICKET_STATE_KEY, {
                "version": 1,
                "claims": claims,
            })
            transaction.commit()
            return True

    @staticmethod
    def _is_state(value):
        return (
            isinstance(value, dict)
            and "version" in value
            and "day" in value
            and isinstance(value.get("offers"), list)
            and isinstance(value.get("billing"), dict)
        )

    @classmethod
    def _stored_state(cls, player):
        progression = getattr(player, "progression", {})
        if not isinstance(progression, dict):
            return {}
        state = progression.get(cls.STATE_KEY, {})
        if isinstance(state, dict) and state:
            return copy.deepcopy(state)
        previous = [
            value for key, value in progression.items()
            if key != cls.STATE_KEY and cls._is_state(value)
        ]
        if len(previous) == 1:
            return copy.deepcopy(previous[0])
        return copy.deepcopy(state) if isinstance(state, dict) else {}

    @staticmethod
    def _billing_state(state):
        billing = state.get("billing", {})
        if not isinstance(billing, dict):
            billing = {}
        transactions = billing.get("transactions", {})
        bundles = billing.get("bundles", {})
        return {
            "transactions": copy.deepcopy(transactions) if isinstance(transactions, dict) else {},
            "bundles": copy.deepcopy(bundles) if isinstance(bundles, dict) else {},
        }

    @classmethod
    def _power_target(cls, player, now, amount=1):
        states = getattr(player, "BrawlersUnlockedState", {})
        points = getattr(player, "brawlers_upgradium", {})
        unlocked = [
            brawler for brawler in Characters.get_brawlers_id()
            if cls._mapping_value(states, brawler) == 1
        ]
        eligible = [
            brawler for brawler in unlocked
            if cls._mapping_value(points, brawler) + amount <= MAX_POWER_POINTS
        ]
        candidates = eligible or unlocked or [0]
        seed = f"{int(getattr(player, 'low_id', 0) or 0)}:{cls._day(now)}:power".encode()
        return candidates[hashlib.sha256(seed).digest()[0] % len(candidates)]

    @staticmethod
    def _daily_offer(definition, expires, items, key=None):
        return {
            "key": key or definition["key"],
            "items": copy.deepcopy(items),
            "currency": definition["currency"],
            "price": definition["price"],
            "originalPrice": definition["originalPrice"],
            "display": definition["display"],
            "expiresAt": expires,
            "seen": False,
            "purchased": False,
            "title": str(definition.get("title", "") or ""),
            "daily": not bool(definition["display"]),
        }

    @classmethod
    def _unlocked_brawlers(cls, player):
        states = getattr(player, "BrawlersUnlockedState", {})
        return [
            brawler for brawler in Characters.get_brawlers_id()
            if cls._mapping_value(states, brawler) == 1
        ]

    @classmethod
    def _daily_brawlers(cls, player, now):
        unlocked = cls._unlocked_brawlers(player)
        identity = f"{getattr(player, 'low_id', 0)}:{cls._day(now)}:power"
        ranked = sorted(
            unlocked,
            key=lambda brawler: hashlib.sha256(
                f"{identity}:{brawler}".encode()
            ).digest(),
        )
        return ranked[:cls.MAX_DAILY_POWER_OFFERS]

    @classmethod
    def _eligible_star_power(cls, player, now, brawler):
        if Cards.get_brawler_star_power(brawler) <= 0:
            return False
        levels = getattr(player, "Brawler_level", {})
        powers = getattr(player, "Brawler_starPower", {})
        if cls._mapping_value(levels, brawler) != 8:
            return False
        if cls._mapping_value(powers, brawler) != 0:
            return False
        identity = f"{getattr(player, 'low_id', 0)}:{cls._day(now)}:star-power:{brawler}"
        roll = int.from_bytes(hashlib.sha256(identity.encode()).digest()[:8], "big")
        threshold = ((1 << 64) * cls.STAR_POWER_DAILY_CHANCE) // 100
        return roll < threshold

    @staticmethod
    def _offer_identity(offer):
        key = str(offer.get("key", ""))
        if key == "power_points":
            kind = key
        elif key.startswith("star_power"):
            kind = "star_power"
        else:
            return key, None
        items = offer.get("items")
        target = None
        if isinstance(items, list) and len(items) == 1 and isinstance(items[0], dict):
            raw_target = items[0].get("target")
            if isinstance(raw_target, (list, tuple)) and len(raw_target) == 2:
                target = raw_target[1]
        return kind, target

    @classmethod
    def _inherit_daily_flags(cls, offers, previous, now):
        if previous.get("day") != cls._day(now):
            return
        previous_offers = previous.get("offers")
        if not isinstance(previous_offers, list):
            return
        identities = {}
        for offer in previous_offers:
            if isinstance(offer, dict):
                identities.setdefault(cls._offer_identity(offer), offer)
        for offer in offers:
            old = identities.get(cls._offer_identity(offer))
            if old is not None:
                offer["purchased"] = old.get("purchased") is True
                offer["seen"] = old.get("seen") is True

    @staticmethod
    def _claimed_state(state):
        claimed = state.get("claimed", {})
        result = {
            str(key): True for key, value in claimed.items() if value is True
        } if isinstance(claimed, dict) else {}
        offers = state.get("offers", [])
        if isinstance(offers, list):
            for offer in offers:
                if (
                    isinstance(offer, dict)
                    and offer.get("oneTime") is True
                    and offer.get("purchased") is True
                ):
                    result[str(offer.get("key", ""))] = True
        return result

    @classmethod
    def _generate(cls, player, now, previous=None):
        config = ShopCatalog.daily_definitions()
        templates = {definition["key"]: definition for definition in config["daily"]}
        expires = cls._next_day(now)
        free = templates["free_box"]
        power = templates["power_points"]
        offers = [cls._daily_offer(free, expires, free["items"])]
        star_powers = []
        for brawler in cls._daily_brawlers(player, now):
            power_items = copy.deepcopy(power["items"])
            power_items[0]["target"] = [16, brawler]
            offers.append(cls._daily_offer(power, expires, power_items))
        for brawler in cls._unlocked_brawlers(player):
            if not cls._eligible_star_power(player, now, brawler):
                continue
            definition = {
                "currency": 1,
                "price": cls.STAR_POWER_PRICE,
                "originalPrice": cls.STAR_POWER_PRICE,
                "display": 0,
                "title": "",
            }
            star_items = [{
                "offerId": 5,
                "amount": 1,
                "value": 0,
                "target": [16, brawler],
            }]
            star_powers.append(cls._daily_offer(
                definition,
                expires,
                star_items,
                f"star_power_{brawler}",
            ))
        offers.extend(star_powers)
        claimed = cls._claimed_state(previous or {})
        for definition in config.get("once", []):
            if claimed.get(definition["key"]):
                continue
            offer = cls._daily_offer(definition, expires, definition["items"])
            offer["oneTime"] = True
            offers.append(offer)
        if isinstance(previous, dict):
            cls._inherit_daily_flags(offers, previous, now)
        return {
            "version": cls.STATE_VERSION,
            "day": cls._day(now),
            "offers": offers,
            "claimed": claimed,
            "billing": cls._billing_state(previous or {}),
        }

    @classmethod
    def _migrate_state(cls, player, state, now):
        offers = state.get("offers", [])
        if not isinstance(offers, list):
            return False
        retained = [
            offer for offer in offers
            if not isinstance(offer, dict)
            or offer.get("key") not in cls.RETIRED_OFFER_KEYS
        ]
        changed = len(retained) != len(offers)
        offers = retained
        state["offers"] = offers
        for offer in offers:
            if not isinstance(offer, dict):
                continue
            items = offer.get("items", [])
            if not isinstance(items, list):
                continue
            for item in items:
                if not isinstance(item, dict):
                    continue
                try:
                    if int(item.get("offerId", -1)) == 0 and int(item.get("value", 0)) == 0:
                        item["value"] = 1
                        changed = True
                except (TypeError, ValueError):
                    continue
            if offer.get("key") == "power_points":
                try:
                    item = items[0]
                    target = item.get("target")
                    needs_migration = (
                        len(items) != 1
                        or int(item.get("offerId", -1)) != 8
                        or int(item.get("value", -1)) != 0
                        or not isinstance(target, (list, tuple))
                        or len(target) != 2
                        or int(target[0]) != 16
                    )
                except (IndexError, TypeError, ValueError):
                    needs_migration = True
                if needs_migration:
                    definition = next(
                        item for item in ShopCatalog.daily_definitions()["daily"]
                        if item["key"] == "power_points"
                    )
                    for field in ("items", "currency", "price", "originalPrice", "display"):
                        offer[field] = copy.deepcopy(definition[field])
                    offer["items"][0]["target"] = [16, cls._power_target(
                        player, now, int(offer["items"][0]["amount"])
                    )]
                    changed = True
            display = offer.get("display")
            if display in (0, 1):
                daily = not bool(display)
                if offer.get("daily") != daily:
                    offer["daily"] = daily
                    changed = True
            for field in ("reroll", "claim"):
                if field in offer:
                    del offer[field]
                    changed = True
        return changed

    @classmethod
    def _valid_offer(cls, offer):
        if not isinstance(offer, dict):
            return False
        try:
            ShopCatalog.validate_definition(offer)
            if int(offer.get("expiresAt", 0)) < 0:
                return False
        except (KeyError, TypeError, ValueError):
            return False
        return True

    @classmethod
    def _append_stored_offers(cls, player, state, now):
        offers = state["offers"]
        stored_types = (
            (11, 10, "stored_mega_box"),
            (12, 14, "stored_big_box"),
        )
        for box_type, offer_id, key in stored_types:
            if any(offer.get("storedBox") == box_type for offer in offers):
                continue
            if BoxInventory.count(player, box_type) < 1:
                continue
            offers.append({
                "key": key,
                "items": [{
                    "offerId": offer_id,
                    "amount": 1,
                    "value": 0,
                    "target": None,
                }],
                "currency": 0,
                "price": 0,
                "originalPrice": 0,
                "display": 0,
                "expiresAt": cls._next_day(now),
                "seen": False,
                "purchased": False,
                "title": "",
                "daily": False,
                "storedBox": box_type,
            })

    @classmethod
    def get_state(cls, player, now=None):
        now = cls._timestamp(now)
        cls.sync_weekend_tickets(player, now)
        progression = getattr(player, "progression", {})
        canonical = progression.get(cls.STATE_KEY) if isinstance(progression, dict) else None
        has_previous = isinstance(progression, dict) and any(
            key != cls.STATE_KEY and cls._is_state(value)
            for key, value in progression.items()
        )
        needs_relocation = (
            not isinstance(canonical, dict) or not canonical or has_previous
        )
        state = cls._stored_state(player)
        previous = copy.deepcopy(state)
        migrated = cls._migrate_state(player, state, now)
        offers = state.get("offers", [])
        valid = (
            state.get("version") == cls.STATE_VERSION
            and state.get("day") == cls._day(now)
            and isinstance(offers, list)
            and bool(offers)
            and all(cls._valid_offer(offer) for offer in offers)
        )
        if not valid:
            state = cls._generate(player, now, previous)
            cls._save_state(player, state)
        else:
            active = [offer for offer in offers if int(offer["expiresAt"]) > now]
            if len(active) != len(offers):
                state["offers"] = active
                if not active:
                    state = cls._generate(player, now, state)
                cls._save_state(player, state)
            elif migrated or needs_relocation:
                cls._save_state(player, state)
        state["billing"] = cls._billing_state(state)
        cls._append_stored_offers(player, state, now)
        return state

    @classmethod
    def _save_state(cls, player, state, transaction=None):
        owns_transaction = transaction is None
        transaction = transaction or RewardTransaction(player)
        for key, value in list(transaction.progression.items()):
            if key != cls.STATE_KEY and cls._is_state(value):
                del transaction.progression[key]
        persistent_state = copy.deepcopy(state)
        persistent_state["offers"] = [
            offer for offer in persistent_state.get("offers", [])
            if not offer.get("storedBox")
        ]
        transaction.set_progression_value(cls.STATE_KEY, persistent_state)
        if owns_transaction:
            transaction.commit()
        return state

    @staticmethod
    def _diagnostic_offer(index, offer, now):
        price = int(offer["price"])
        original_price = int(offer.get("originalPrice", price))
        return {
            "index": index,
            "key": offer.get("key", ""),
            "items": offer.get("items", []),
            "currency": int(offer["currency"]),
            "cost": price,
            "expiresAt": int(offer["expiresAt"]),
            "timer": max(0, int(offer["expiresAt"]) - int(now)),
            "newTag": 1 if offer.get("seen", False) else 0,
            "percentage": 100,
            "purchased": bool(offer.get("purchased", False)),
            "auxiliary": 0,
            "daily": bool(offer.get("daily", False)),
            "originalCost": original_price if original_price > price else 0,
            "title": str(offer.get("title", "")),
        }

    @classmethod
    def _log_home_offers(cls, player, state, now):
        if not Config.GetValue().get("ShowPacketsInLog", False):
            return
        offers = state["offers"]
        account = int(getattr(player, "low_id", 0) or 0)
        print(
            f"Server | ShopState account={account} day={state.get('day', '')} "
            f"now={now} count={len(offers)}"
        )
        for index, offer in enumerate(offers):
            payload = cls._diagnostic_offer(index, offer, now)
            print(
                "Server | ShopOffer "
                + json.dumps(payload, sort_keys=True, separators=(",", ":"))
            )

    @classmethod
    def encode_home(cls, writer, player, now=None):
        now = cls._timestamp(now)
        state = cls.get_state(player, now)
        offers = state["offers"]
        cls._log_home_offers(player, state, now)
        writer.v(len(offers))
        for offer in offers:
            LogicOfferBundle.encode(writer, offer, now)

    @classmethod
    def clear_tickers(cls, player, now=None):
        state = cls.get_state(player, now)
        changed = False
        for offer in state["offers"]:
            if not offer.get("seen", False):
                offer["seen"] = True
                changed = True
        if changed:
            cls._save_state(player, state)
        return {"cleared": changed, "count": len(state["offers"])}

    @staticmethod
    def _mapping_value(mapping, key, default=0):
        if not isinstance(mapping, dict):
            return default
        try:
            return int(mapping.get(str(key), mapping.get(key, default)) or 0)
        except (TypeError, ValueError):
            return default

    @classmethod
    def _locked_by_rarity(cls, player, rarity):
        states = getattr(player, "BrawlersUnlockedState", {})
        result = []
        for brawler in Characters.get_brawlers_id():
            if cls._mapping_value(states, brawler) == 1:
                continue
            card = Cards.get_brawler_unlock_by_character(brawler)
            if Cards.get_brawler_rarity(card) == rarity:
                result.append(brawler)
        return result

    @classmethod
    def _selected_brawler(cls, item, selected_brawler):
        if selected_brawler:
            return int(selected_brawler)
        target = item.get("target")
        if target and int(target[0]) == 16:
            return int(target[1])
        raise RewardError("Selecione um brawler para essa oferta")

    @staticmethod
    def _opened_box_result(
        details, box_type, box_count, reward_units=None, initial=None
    ):
        result = {
            "boxID": box_type,
            "boxType": box_type,
            "boxCount": box_count,
            "rewards": [detail["amount"] for detail in details],
            "rewardNames": [detail["name"] for detail in details],
            "rewardsTargetBrawler": [
                detail.get("target", 0) for detail in details
            ],
            "rewardDetails": copy.deepcopy(details),
            "trophyRoad": 0,
        }
        if reward_units is not None:
            result["rewardUnits"] = reward_units
            result["unitCount"] = len(reward_units)
        if initial is not None:
            result["initial"] = int(initial)
        return result

    @classmethod
    def _combined_box_results(cls, opened_boxes, extra_details=None):
        details = []
        reward_units = []
        expected_units = 0
        for result in opened_boxes:
            expected_units += int(result["boxCount"])
            details.extend(copy.deepcopy(result["rewardDetails"]))
            units = result.get("rewardUnits")
            if units is None:
                if int(result["boxCount"]) != 1:
                    raise RewardError("Unidades da caixa ausentes")
                units = [cls._opened_box_result(
                    result["rewardDetails"], result["boxType"], 1
                )]
            reward_units.extend(copy.deepcopy(units))
        extra_details = copy.deepcopy(extra_details or [])
        if extra_details:
            if not reward_units:
                raise RewardError("Recompensa sem caixa para apresentação")
            first = reward_units[0]
            first_details = extra_details + first["rewardDetails"]
            reward_units[0] = cls._opened_box_result(
                first_details, first["boxType"], 1
            )
            details = extra_details + details
        detail_count = sum(
            len(unit["rewardDetails"]) for unit in reward_units
        )
        if (
            len(reward_units) != expected_units
            or detail_count != len(details)
            or any(int(unit["boxCount"]) != 1 for unit in reward_units)
        ):
            raise RewardError("Unidades ou drops das caixas divergentes")
        return cls._opened_box_result(
            details,
            opened_boxes[0]["boxType"],
            len(reward_units),
            reward_units=reward_units,
            initial=len(reward_units),
        )

    @classmethod
    def _deliver_item(
        cls, transaction, item, selected_brawler, rng, open_box=False,
        allow_unlocked=False,
    ):
        item = ShopCatalog.validate_item(item)
        offer_id = item["offerId"]
        amount = item["amount"]
        value = item["value"]
        target = item.get("target") or [0, 0]
        player = transaction.player
        if offer_id == 0 or (offer_id in ShopCatalog.BOX_TYPES and open_box):
            box_type = ShopCatalog.BOX_TYPES[offer_id]
            start = len(transaction.reward_details)
            reward_units = []
            for _ in range(amount):
                unit_start = len(transaction.reward_details)
                apply_box_opening(
                    transaction, box_type, rng, box_count=1
                )
                unit_details = transaction.reward_details[unit_start:]
                reward_units.append(cls._opened_box_result(
                    unit_details, box_type, 1
                ))
            details = transaction.reward_details[start:]
            return {
                "openedBox": cls._opened_box_result(
                    details,
                    box_type,
                    amount,
                    reward_units=reward_units if amount > 1 else None,
                    initial=amount if amount > 1 else None,
                )
            }
        if offer_id in ShopCatalog.BOX_TYPES:
            box_type = ShopCatalog.BOX_TYPES[offer_id]
            BoxInventory.add(transaction, box_type, amount)
            return {"boxType": box_type, "amount": amount}
        if offer_id == 1:
            name, reward_amount, reward_target = "Coins", amount, 0
        elif offer_id == 16:
            name, reward_amount, reward_target = "gems", amount, 0
        elif offer_id == 7:
            if value != 0:
                raise RewardError("Essa variante de ticket não pertence à loja")
            name, reward_amount, reward_target = "tickets", amount, 0
        elif offer_id == 9:
            name, reward_amount, reward_target = "tokens_doubler", amount, 0
        elif offer_id == 8:
            if int(target[0]) != 16:
                raise RewardError("Brawler dos power points inválido")
            reward_target = int(target[1])
            name, reward_amount = "UpgradePoints", amount
        elif offer_id == 12:
            reward_target = cls._selected_brawler(item, selected_brawler)
            name, reward_amount = "UpgradePoints", amount
        elif offer_id == 5:
            if int(target[0]) != 16:
                raise RewardError("Brawler da star power inválido")
            reward_target = int(target[1])
            powers = getattr(player, "Brawler_starPower", {})
            if cls._mapping_value(powers, reward_target):
                raise RewardError("Star power já desbloqueada")
            reward_amount = Cards.get_brawler_star_power(reward_target)
            name = "StarPower"
        elif offer_id == 3:
            if int(target[0]) != 16:
                raise RewardError("Brawler da oferta inválido")
            reward_target = int(target[1])
            states = getattr(player, "BrawlersUnlockedState", {})
            if (
                not allow_unlocked
                and cls._mapping_value(states, reward_target) == 1
            ):
                raise RewardError("Brawler já desbloqueado")
            name, reward_amount = "Brawler", reward_target
        elif offer_id == 2:
            choices = cls._locked_by_rarity(player, value)
            if not choices:
                raise RewardError("Nenhum brawler disponível nessa raridade")
            name, reward_amount, reward_target = "Brawler", rng.choice(choices), 0
        elif offer_id == 4:
            skin = int(target[1] or value)
            if int(target[0]) not in (0, 29) or skin not in Skins.get_skins_id():
                raise RewardError("Skin inválida")
            brawler = Skins.getBrawler(skin)
            states = getattr(player, "BrawlersUnlockedState", {})
            unlocked = cls._mapping_value(states, brawler) == 1
            if Skins.getIsDefaultSkin(skin):
                if unlocked:
                    raise RewardError("Brawler já desbloqueado")
                name, reward_amount, reward_target = "Brawler", brawler, 0
            else:
                if not unlocked:
                    raise RewardError("A skin exige um brawler desbloqueado")
                name, reward_amount, reward_target = "Skin", skin, brawler
        else:
            raise RewardError(f"Oferta {offer_id} não suportada")
        start = len(transaction.reward_details)
        transaction.add_reward(name, reward_amount, reward_target, exact=True)
        details = transaction.reward_details[start:]
        if len(details) != 1 or details[0]["amount"] != reward_amount:
            raise RewardError("Quantidade de recompensa divergente")
        display = RewardDelivery.display(details[0])
        if offer_id == 12:
            display["type"] = 9
            display["brawler"] = reward_target
        return {
            "display": display,
            "rewardDetail": copy.deepcopy(details[0]),
        }

    @classmethod
    def purchase(cls, player, offer_index, selected_brawler=0, now=None, rng=random):
        now = cls._timestamp(now)
        try:
            offer_index = int(offer_index)
            selected_brawler = int(selected_brawler or 0)
        except (TypeError, ValueError):
            raise RewardError("Oferta inválida") from None
        state = cls.get_state(player, now)
        if not 0 <= offer_index < len(state["offers"]):
            raise RewardError("Oferta inválida")
        offer = state["offers"][offer_index]
        if int(offer["expiresAt"]) <= now:
            raise RewardError("Oferta expirada")
        if offer.get("purchased", False):
            raise RewardError("Oferta já comprada")
        if offer.get("storedBox"):
            stored_box = int(offer["storedBox"])
            if stored_box not in (11, 12):
                raise RewardError("Caixa armazenada inválida")
            transaction = RewardTransaction(player)
            BoxInventory.consume(transaction, stored_box, 1)
            apply_box_opening(transaction, stored_box, rng)
            transaction.commit()
            result = transaction.result(stored_box, stored_box)
            result.update({
                "offerIndex": offer_index,
                "offerKey": offer["key"],
                "boxCount": 1,
                "price": 0,
                "currency": None,
                "storedBoxes": BoxInventory.count(player, stored_box),
                "openingSource": "storedOffer",
            })
            result["responses"] = [{"kind": "box", "result": dict(result)}]
            return result
        transaction = RewardTransaction(player)
        currency = ShopCatalog.CURRENCIES.get(int(offer["currency"]))
        if currency is None:
            raise RewardError("Moeda da oferta inválida")
        price = int(offer["price"])
        if price:
            transaction.charge(currency, price)
        rewards = []
        offered_details = []
        stored_boxes = []
        opened_boxes = []
        mixed_box_bundle = (
            offer.get("oneTime") is True
            and offer["key"] in cls.COMBINED_BOX_OFFERS
        )
        for item in offer["items"]:
            defer_box = (
                offer.get("oneTime") is True
                and not mixed_box_bundle
                and bool(opened_boxes)
                and item["offerId"] in ShopCatalog.BOX_TYPES
            )
            delivered = cls._deliver_item(
                transaction,
                item,
                selected_brawler,
                rng,
                open_box=offer.get("oneTime") is True and not defer_box,
                allow_unlocked=offer["key"] == "the_big_three",
            )
            if "openedBox" in delivered:
                opened_boxes.append(delivered["openedBox"])
            elif "boxType" in delivered:
                stored_boxes.append(delivered)
            else:
                rewards.append(delivered["display"])
                if mixed_box_bundle:
                    offered_details.append(delivered["rewardDetail"])
        combined_box = None
        if mixed_box_bundle and opened_boxes:
            combined_box = cls._combined_box_results(
                opened_boxes, offered_details
            )
            if combined_box["rewardDetails"] != transaction.reward_details:
                raise RewardError("Recompensas da oferta divergentes")
        offer["purchased"] = True
        if offer.get("oneTime") is True:
            claimed = cls._claimed_state(state)
            claimed[str(offer["key"])] = True
            state["claimed"] = claimed
        cls._save_state(player, state, transaction)
        transaction.commit()
        inventory_embedded = (
            offer.get("oneTime") is True
            and len(opened_boxes) == 1
            and len(stored_boxes) == 1
        )
        responses = RewardDelivery.responses(
            [] if combined_box is not None else rewards,
            [] if inventory_embedded else stored_boxes,
        )
        if combined_box is not None:
            responses.append({"kind": "box", "result": combined_box})
        else:
            responses.extend(
                {"kind": "box", "result": result} for result in opened_boxes
            )
        return {
            "offerIndex": offer_index,
            "offerKey": offer["key"],
            "price": price,
            "currency": currency,
            "rewards": rewards,
            "storedBoxes": stored_boxes,
            "openedBoxes": opened_boxes,
            "responses": responses,
        }
