"""Bridge transactional battle rewards into the Nost V13 result encoder."""

from types import SimpleNamespace

from Logic.BattleRewardsManager import BattleRewardsManager


def apply_battle_result_rewards(player, game_mode, battle_id=None, now=None):
    base_result = int(getattr(player, "result", 16) or 0)
    battle_result = int(getattr(player, "battle_result", 0) or 0)
    brawler = int(getattr(player, "brawler_id", 0) or 0)
    fields = {
        "GameMode": game_mode,
        "MapID": int(getattr(player, "map_id", 0) or 0),
        "MapSlot": int(getattr(player, "locationID", 0) or 0),
        "Rank": int(getattr(player, "rank", 1) or 0),
        "Victory": battle_result,
        "result": base_result,
        "Heroes": [{
            "IsPlayer": True,
            "Brawler": {"ID": [16, brawler]},
        }],
    }
    rewards = BattleRewardsManager(player).process_rewards(
        fields, battle_id=battle_id, now=now
    )
    return SimpleNamespace(
        brawler_trophies=rewards["brawler_trophies"],
        brawler_trophies_for_rank=rewards["brawler_trophies_for_rank"],
        token=rewards["tokens_gain"],
        gainedtrophies=rewards["trophies_gain"],
        trophies=rewards["trophies_gain"],
        doubledtokens=rewards["doubled_tokens"],
        remainingtokens=rewards["remaining_tokens"],
        totaltokens=rewards["total_tokens"],
        experience=rewards["experience"],
        mvpexperience=rewards["star_player_exp"],
        result=rewards["result"],
        starplayer=rewards["starplayer"],
        rewards=rewards,
    )
