"""Compra de skins pela tabela oficial V13 (CSV de skins)."""

from Files.CsvLogic.Skins import Skins
from Logic.Rewards import RewardError, RewardTransaction


class SkinPurchase:
    @staticmethod
    def price_for(skin):
        skin = int(skin)
        return int(Skins.getSkinPrice(skin))

    @classmethod
    def purchase(cls, player, skin, brawler):
        try:
            skin = int(skin)
            brawler = int(brawler)
        except (TypeError, ValueError):
            raise RewardError("Skin inválida") from None

        if skin not in Skins.get_skins_id():
            raise RewardError("Skin inválida")
        actual_brawler = Skins.getBrawler(skin)
        if brawler != actual_brawler:
            raise RewardError("Skin e brawler não correspondem")

        states = getattr(player, "BrawlersUnlockedState", {})
        unlocked = states.get(str(brawler), states.get(brawler, 0)) == 1
        is_default = Skins.getIsDefaultSkin(skin)
        owned = getattr(player, "UnlockedSkins", {}).get("Skins", [])
        price = 0 if is_default else cls.price_for(skin)

        transaction = RewardTransaction(player)
        if is_default:
            if unlocked:
                raise RewardError("Brawler já desbloqueado")
            transaction.add_reward("Brawler", brawler)
        else:
            if not unlocked:
                raise RewardError("A skin exige um brawler desbloqueado")
            if skin in owned:
                raise RewardError("Skin já desbloqueada")
            transaction.charge("gems", price)
            transaction.add_reward("Skin", skin, brawler)

        if is_default:
            transaction.set_value("skin_id", "skinID", skin)
            transaction.set_value("brawler_id", "brawlerID", brawler)
        transaction.commit()
        result = transaction.result(100, 100)
        result.update({
            "skin": skin,
            "brawler": brawler,
            "price": price,
            "isDefaultSkin": is_default,
        })
        return result
