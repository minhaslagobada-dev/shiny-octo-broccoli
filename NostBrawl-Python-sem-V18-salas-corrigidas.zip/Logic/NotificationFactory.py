import copy
import time

from Files.CsvLogic.Skins import Skins
from Utils.Config import Config


class NotificationFactory:
    SKIN_REWARD_TYPE = 94
    SEASON_END_TYPE = 99
    SKIN_GLOBAL_ID = 29000000
    STAR_SHELLY_SKIN_ID = 52
    STAR_SHELLY_TEXT = (
        "You have unlocked a new skin! Thank you for playing Brawl Stars in 2018"
    )
    WIZARD_BARLEY_SKIN_ID = 59
    WIZARD_BARLEY_TEXT = (
        "You have unlocked a new skin! Thank you for registering your Supercell ID"
    )
    SEASON_UNKNOWN_BEFORE = (0, 9000)
    SEASON_UNKNOWN_AFTER = (9000, 0)
    SEASON_BOX_TYPES = (10, 11, 12)

    @staticmethod
    def _integer(value, default=0):
        try:
            return int(value)
        except (TypeError, ValueError):
            return default

    @classmethod
    def _nonnegative(cls, value, default=0):
        return max(0, cls._integer(value, default))

    @classmethod
    def _type(cls, notification):
        return cls._integer(
            notification.get("Type", notification.get("ID", notification.get("type", 0)))
        )

    @staticmethod
    def _read(notification):
        return bool(notification.get("Read", notification.get("nrd", False)))

    @classmethod
    def _ordered(cls, notifications):
        if isinstance(notifications, dict):
            def order(key):
                try:
                    return 0, int(key), str(key)
                except (TypeError, ValueError):
                    return 1, 0, str(key)

            values = [notifications[key] for key in sorted(notifications, key=order)]
        elif isinstance(notifications, (list, tuple)):
            values = list(notifications)
        else:
            return []
        return [value for value in values if isinstance(value, dict)]

    @classmethod
    def _skin_id(cls, notification):
        if "SkinID" in notification:
            return cls._integer(notification.get("SkinID"), -1)
        skin_id = cls._integer(notification.get("sd"), -1)
        if skin_id >= cls.SKIN_GLOBAL_ID:
            skin_id -= cls.SKIN_GLOBAL_ID
        return skin_id

    @classmethod
    def _entries(cls, notifications):
        entries = []
        for value in cls._ordered(notifications):
            if cls._type(value) != cls.SKIN_REWARD_TYPE:
                continue
            skin_id = cls._skin_id(value)
            if skin_id < 0:
                continue
            entries.append((value, skin_id))
        return entries

    @classmethod
    def has_scid_connection(cls, player):
        account = getattr(player, "scid_account", None)
        low_id = cls._integer(getattr(player, "low_id", 0))
        return bool(
            account is not None
            and low_id > 0
            and cls._integer(getattr(account, "game_low_id", 0)) == low_id
        )

    @classmethod
    def _is_wizard_barley(cls, notification):
        return (
            cls._type(notification) == cls.SKIN_REWARD_TYPE
            and cls._skin_id(notification) == cls.WIZARD_BARLEY_SKIN_ID
        )

    @classmethod
    def home_notifications(cls, player):
        notifications = getattr(player, "Notifications", {})
        if cls.has_scid_connection(player):
            return notifications
        if isinstance(notifications, dict):
            return {
                key: value
                for key, value in notifications.items()
                if not isinstance(value, dict) or not cls._is_wizard_barley(value)
            }
        if isinstance(notifications, (list, tuple)):
            values = [
                value
                for value in notifications
                if not isinstance(value, dict) or not cls._is_wizard_barley(value)
            ]
            return tuple(values) if isinstance(notifications, tuple) else values
        return notifications

    @classmethod
    def _season_block(cls, notification, nested_name):
        nested = notification.get(nested_name, {})
        if not isinstance(nested, dict):
            nested = {}
        legacy_trophies = {
            "Best": ("bestBrawlerTrophies", "BestBrawlerTrophies"),
            "Total": ("totalTrophies", "TotalTrophies"),
        }[nested_name]
        legacy_prefix = "bestBrawler" if nested_name == "Best" else "totalTrophies"
        return {
            "Trophies": cls._nonnegative(
                nested.get(
                    "Trophies",
                    notification.get(legacy_trophies[0], notification.get(legacy_trophies[1], 0)),
                )
            ),
            "Points": cls._nonnegative(
                nested.get("Points", notification.get(legacy_prefix + "Points", 0))
            ),
            "Coins": cls._nonnegative(
                nested.get("Coins", notification.get(legacy_prefix + "Coins", 0))
            ),
            "Bonus": cls._nonnegative(
                nested.get("Bonus", notification.get(legacy_prefix + "Bonus", 0))
            ),
        }

    @classmethod
    def _season_details(cls, notification):
        return {
            "Best": cls._season_block(notification, "Best"),
            "Total": cls._season_block(notification, "Total"),
            "BestBrawler": cls._nonnegative(
                notification.get("BestBrawler", notification.get("bestBrawler", 0))
            ),
        }

    @classmethod
    def _season_boxes(cls, notification):
        raw = notification.get("Boxes", notification.get("boxes", []))
        entries = []
        if isinstance(raw, dict):
            raw = [{"Type": key, "Count": value} for key, value in raw.items()]
        if not isinstance(raw, (list, tuple)):
            raise ValueError("Caixas da notificação de temporada inválidas")
        for entry in raw:
            if isinstance(entry, dict):
                box_type = entry.get("Type", entry.get("boxType"))
                count = entry.get("Count", entry.get("amount", 0))
            elif isinstance(entry, (list, tuple)) and len(entry) == 2:
                box_type, count = entry
            else:
                raise ValueError("Caixa da notificação de temporada inválida")
            box_type = cls._integer(box_type, -1)
            count = cls._integer(count, -1)
            if box_type not in cls.SEASON_BOX_TYPES or count <= 0:
                raise ValueError("Caixa da notificação de temporada inválida")
            entries.append({"Type": box_type, "Count": count})
        return entries

    @classmethod
    def encode_season(cls, writer, notification):
        details = cls._season_details(notification)
        write = getattr(writer, "v", None)
        if write is None:
            write = writer.writeVint
        for block_name in ("Best", "Total"):
            block = details[block_name]
            for field in ("Trophies", "Points", "Coins", "Bonus"):
                write(block[field])
        for value in cls.SEASON_UNKNOWN_BEFORE:
            write(value)
        write(16)
        write(details["BestBrawler"])
        for value in cls.SEASON_UNKNOWN_AFTER:
            write(value)

    @classmethod
    def encode(cls, writer, notifications, now=None):
        settings = Config.GetValue()
        hidden_skins = set()
        if settings.get("StarShelly", False):
            hidden_skins.add(cls.STAR_SHELLY_SKIN_ID)
        if settings.get("WizardBarley", False):
            hidden_skins.add(cls.WIZARD_BARLEY_SKIN_ID)

        entries = []
        for notification in cls._ordered(notifications):
            if cls._read(notification):
                continue
            notification_type = cls._type(notification)
            if notification_type == cls.SKIN_REWARD_TYPE:
                skin_id = cls._skin_id(notification)
                if skin_id < 0 or skin_id in hidden_skins:
                    continue
                entries.append((notification_type, notification))
            elif notification_type == cls.SEASON_END_TYPE:
                entries.append((notification_type, notification))

        writer.v(len(entries))
        for notification_type, notification in entries:
            writer.v(notification_type)
            if notification_type == cls.SKIN_REWARD_TYPE:
                writer.v(cls.SKIN_GLOBAL_ID + cls._skin_id(notification))
            else:
                cls.encode_season(writer, notification)

    @classmethod
    def _prepare_notification(cls, player, notification_type):
        current = getattr(player, "Notifications", {})
        if not isinstance(current, dict):
            current = {}
        notifications = copy.deepcopy(current)
        numeric_keys = [cls._integer(key, -1) for key in notifications]
        next_key = str(max(numeric_keys + [-1]) + 1)
        indices = [
            cls._integer(value.get("Index", 0))
            for value in notifications.values()
            if isinstance(value, dict)
        ]
        notification = {
            "Type": notification_type,
            "Index": max(indices + [0]) + 1,
            "Read": False,
            "Time": time.time(),
        }
        notifications[next_key] = notification
        return notifications, notification

    @classmethod
    def _prepare_skin(cls, player, skin_id, text):
        skin_id = cls._integer(skin_id, -1)
        Skins.getSkinPrice(skin_id)
        notifications, notification = cls._prepare_notification(
            player, cls.SKIN_REWARD_TYPE
        )
        notification["Text"] = str(text)
        notification["SkinID"] = skin_id
        return notifications, notification

    @classmethod
    def _prepare_season(cls, player, details, now=None):
        notifications, notification = cls._prepare_notification(
            player, cls.SEASON_END_TYPE
        )
        if now is not None:
            notification["Time"] = int(now)
        notification["Seen"] = False
        notification.update(copy.deepcopy(details))
        return notifications, notification

    @classmethod
    def add_skin(cls, player, skin_id, text="Voucher gift"):
        notifications, notification = cls._prepare_skin(player, skin_id, text)
        from Database.DatabaseManager import DataBase
        low_id = cls._integer(getattr(player, "low_id", 0))
        if low_id <= 0 or not DataBase._update_value(
            "lowID", low_id, "Notifications", notifications
        ):
            raise RuntimeError("Não foi possível persistir a notificação")
        player.Notifications = notifications
        return copy.deepcopy(notification)

    @classmethod
    def ensure_skin(cls, player, skin_id, text):
        skin_id = cls._integer(skin_id, -1)
        for _, existing_skin in cls._entries(getattr(player, "Notifications", {})):
            if existing_skin == skin_id:
                return False
        cls.add_skin(player, skin_id, text)
        return True

    @classmethod
    def ensure_star_shelly(cls, player):
        return cls.ensure_skin(player, cls.STAR_SHELLY_SKIN_ID, cls.STAR_SHELLY_TEXT)

    @classmethod
    def ensure_wizard_barley(cls, player):
        from Logic.Rewards import RewardTransaction
        brawler_id = Skins.getBrawler(cls.WIZARD_BARLEY_SKIN_ID)
        states = getattr(player, "BrawlersUnlockedState", {})
        unlocked = isinstance(states, dict) and states.get(
            str(brawler_id), states.get(brawler_id, 0)
        ) == 1
        has_notification = any(
            skin_id == cls.WIZARD_BARLEY_SKIN_ID
            for _, skin_id in cls._entries(getattr(player, "Notifications", {}))
        )
        if unlocked and has_notification:
            return False
        transaction = RewardTransaction(player)
        if not unlocked:
            transaction.add_reward("Brawler", brawler_id)
        if not has_notification:
            notifications, _ = cls._prepare_skin(
                player, cls.WIZARD_BARLEY_SKIN_ID, cls.WIZARD_BARLEY_TEXT
            )
            transaction.set_value("Notifications", "Notifications", notifications)
        transaction.commit()
        return True

    @classmethod
    def next_pending_type(cls, player):
        for notification in cls._ordered(cls.home_notifications(player)):
            if cls._read(notification):
                continue
            notification_type = cls._type(notification)
            if notification_type in (cls.SKIN_REWARD_TYPE, cls.SEASON_END_TYPE):
                return notification_type
        return None

    @classmethod
    def claim_next_skin(cls, player):
        current = cls.home_notifications(player)
        if not isinstance(current, dict):
            raise ValueError("Notificação não encontrada")
        pending = [
            (notification, skin_id)
            for notification, skin_id in cls._entries(current)
            if not cls._read(notification)
        ]
        if not pending:
            raise ValueError("Notificação não encontrada")
        notification_index = cls._integer(pending[0][0].get("Index"), -1)
        if notification_index <= 0:
            raise ValueError("Notificação sem índice válido")
        return cls.claim_skin(player, notification_index)

    @classmethod
    def claim_next_season(cls, player):
        for notification in cls._ordered(getattr(player, "Notifications", {})):
            if cls._type(notification) == cls.SEASON_END_TYPE and not cls._read(notification):
                notification_index = cls._integer(notification.get("Index"), -1)
                if notification_index <= 0:
                    raise ValueError("Notificação sem índice válido")
                return cls.claim_season(player, notification_index)
        raise ValueError("Notificação de temporada não encontrada")

    @classmethod
    def notification_type_at_index(cls, player, notification_index):
        notification_index = cls._integer(notification_index, -1)
        for notification in cls._ordered(getattr(player, "Notifications", {})):
            if cls._integer(notification.get("Index"), -1) == notification_index:
                if cls._is_wizard_barley(notification) and not cls.has_scid_connection(player):
                    raise ValueError("Notificação não encontrada")
                return cls._type(notification)
        raise ValueError("Notificação não encontrada")

    @classmethod
    def mark_season_seen(cls, player, notification_index):
        from Logic.Rewards import RewardTransaction
        notification_index = cls._integer(notification_index, -1)
        current = getattr(player, "Notifications", {})
        if not isinstance(current, dict):
            raise ValueError("Notificação não encontrada")
        notifications = copy.deepcopy(current)
        for notification in notifications.values():
            if not isinstance(notification, dict):
                continue
            if cls._integer(notification.get("Index"), -1) != notification_index:
                continue
            if cls._type(notification) != cls.SEASON_END_TYPE:
                raise ValueError("A notificação não pertence à temporada")
            if cls._read(notification):
                raise ValueError("Notificação já resgatada")
            notification["Seen"] = True
            transaction = RewardTransaction(player)
            transaction.set_value("Notifications", "Notifications", notifications)
            transaction.commit()
            return {
                "type": cls.SEASON_END_TYPE,
                "index": notification_index,
                "seen": True,
                "claimed": False,
            }
        raise ValueError("Notificação não encontrada")

    @classmethod
    def claim_season(cls, player, notification_index):
        from Logic.BoxInventory import BoxInventory
        from Logic.Rewards import RewardTransaction
        notification_index = cls._integer(notification_index, -1)
        current = getattr(player, "Notifications", {})
        if not isinstance(current, dict):
            raise ValueError("Notificação não encontrada")
        notifications = copy.deepcopy(current)
        for notification in notifications.values():
            if not isinstance(notification, dict):
                continue
            if cls._integer(notification.get("Index"), -1) != notification_index:
                continue
            if cls._type(notification) != cls.SEASON_END_TYPE:
                raise ValueError("A notificação não pertence à temporada")
            if cls._read(notification):
                raise ValueError("Notificação já resgatada")

            details = cls._season_details(notification)
            boxes = cls._season_boxes(notification)
            token_amount = sum(
                details[block][field]
                for block in ("Best", "Total")
                for field in ("Coins", "Bonus")
            )
            transaction = RewardTransaction(player)
            if token_amount:
                balance = int(transaction._value("brawl_boxes", 0) or 0)
                transaction.set_value(
                    "brawl_boxes", "brawlBoxes", balance + token_amount
                )
            resources = {5000001: token_amount, 5000009: 0}
            for box in boxes:
                BoxInventory.add(transaction, box["Type"], box["Count"])
                if box["Type"] == 10:
                    resources[5000001] += box["Count"] * 100
                elif box["Type"] == 12:
                    resources[5000009] += box["Count"] * 10

            notification["Seen"] = True
            notification["Read"] = True
            notification["ClaimedAt"] = time.time()
            transaction.set_value("Notifications", "Notifications", notifications)
            transaction.commit()
            return {
                "type": cls.SEASON_END_TYPE,
                "index": notification_index,
                "tokens": token_amount,
                "boxes": boxes,
                "resources": resources,
                "bestBrawler": details["BestBrawler"],
                "claimed": True,
            }
        raise ValueError("Notificação não encontrada")

    @classmethod
    def claim_skin(cls, player, notification_index):
        from Logic.Rewards import RewardTransaction
        notification_index = cls._integer(notification_index, -1)
        current = getattr(player, "Notifications", {})
        if not isinstance(current, dict):
            raise ValueError("Notificação não encontrada")
        notifications = copy.deepcopy(current)
        for notification in notifications.values():
            if not isinstance(notification, dict):
                continue
            if cls._integer(notification.get("Index"), -1) != notification_index:
                continue
            entries = cls._entries([notification])
            if not entries:
                raise ValueError("A notificação não é uma recompensa de skin")
            skin_id = entries[0][1]
            if skin_id == cls.WIZARD_BARLEY_SKIN_ID and not cls.has_scid_connection(player):
                raise ValueError("Notificação não encontrada")
            if cls._read(notification):
                raise ValueError("Notificação já resgatada")
            brawler_id = Skins.getBrawler(skin_id)
            owned = getattr(player, "UnlockedSkins", {}).get("Skins", [])
            already_owned = skin_id in owned
            is_wizard_barley = skin_id == cls.WIZARD_BARLEY_SKIN_ID
            states = getattr(player, "BrawlersUnlockedState", {})
            brawler_unlocked = states.get(
                str(brawler_id), states.get(brawler_id, 0)
            ) == 1
            transaction = RewardTransaction(player)
            if is_wizard_barley and not brawler_unlocked:
                transaction.add_reward("Brawler", brawler_id)
            if not already_owned:
                if is_wizard_barley:
                    transaction.add_reward("Skin", skin_id)
                else:
                    unlocked_skins = copy.deepcopy(
                        getattr(player, "UnlockedSkins", {"Skins": []})
                    )
                    unlocked_skins.setdefault("Skins", []).append(skin_id)
                    transaction.set_value("UnlockedSkins", "UnlockedSkins", unlocked_skins)
            notification["Read"] = True
            transaction.set_value("Notifications", "Notifications", notifications)
            transaction.commit()
            return {
                "skin": skin_id,
                "brawler": brawler_id,
                "brawlerReward": brawler_id if is_wizard_barley else None,
                "index": notification_index,
                "alreadyOwned": already_owned,
            }
        raise ValueError("Notificação não encontrada")
