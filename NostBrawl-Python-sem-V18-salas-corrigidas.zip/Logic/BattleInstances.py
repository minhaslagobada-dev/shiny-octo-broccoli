import time
import uuid

from Database.DatabaseManager import DataBase


class BattleInstanceError(ValueError):
    pass


class BattleInstanceService:
    @staticmethod
    def _player_id(player):
        try:
            low_id = int(getattr(player, "low_id", 0) or 0)
        except (TypeError, ValueError):
            raise BattleInstanceError("Conta inválida para identificar a partida") from None
        if low_id <= 0 or not getattr(player, "token", ""):
            raise BattleInstanceError("Conta não autenticada para identificar a partida")
        return low_id

    @staticmethod
    def _current(connection, low_id):
        return connection.execute(
            "SELECT battle_id, payload_hash, game_mode, rewards_json "
            "FROM battle_reward_ledger WHERE player_id = ? AND is_current = 1",
            (low_id,),
        ).fetchone()

    @staticmethod
    def _completed(connection, low_id, payload_hash, game_mode):
        return connection.execute(
            "SELECT battle_id FROM battle_reward_ledger "
            "WHERE player_id = ? AND payload_hash = ? AND game_mode = ? "
            "AND rewards_json IS NOT NULL "
            "ORDER BY completed_at DESC, created_at DESC LIMIT 1",
            (low_id, payload_hash, game_mode),
        ).fetchone()

    @staticmethod
    def _insert(connection, low_id, payload_hash="", game_mode=-1):
        battle_id = uuid.uuid4().hex
        now = int(time.time())
        connection.execute(
            "UPDATE battle_reward_ledger SET is_current = 0, updated_at = ? "
            "WHERE player_id = ? AND is_current = 1",
            (now, low_id),
        )
        connection.execute(
            "INSERT INTO battle_reward_ledger ("
            "player_id, battle_id, payload_hash, game_mode, is_current, "
            "created_at, updated_at"
            ") VALUES (?, ?, ?, ?, 1, ?, ?)",
            (low_id, battle_id, payload_hash, int(game_mode), now, now),
        )
        return battle_id

    @classmethod
    def begin(cls, player):
        if not getattr(player, "token", ""):
            return None
        low_id = cls._player_id(player)
        with DataBase._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            current = cls._current(connection, low_id)
            if current is not None and current[3] is None:
                battle_id = current[0]
            else:
                battle_id = cls._insert(connection, low_id)
        player.battle_instance_id = battle_id
        return battle_id

    @classmethod
    def resolve_result(cls, player, payload_hash, game_mode):
        low_id = cls._player_id(player)
        if not isinstance(payload_hash, str) or len(payload_hash) != 64:
            raise BattleInstanceError("Identidade de conteúdo BattleEnd inválida")
        try:
            game_mode = int(game_mode)
        except (TypeError, ValueError):
            raise BattleInstanceError("Modo BattleEnd inválido") from None

        with DataBase._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            current = cls._current(connection, low_id)
            if current is None:
                completed = cls._completed(
                    connection, low_id, payload_hash, game_mode
                )
                battle_id = completed[0] if completed else cls._insert(
                    connection, low_id, payload_hash, game_mode
                )
            elif current[3] is not None:
                if current[1] == payload_hash and int(current[2]) == game_mode:
                    battle_id = current[0]
                else:
                    completed = cls._completed(
                        connection, low_id, payload_hash, game_mode
                    )
                    battle_id = completed[0] if completed else cls._insert(
                        connection, low_id, payload_hash, game_mode
                    )
            elif not current[1]:
                battle_id = current[0]
                now = int(time.time())
                connection.execute(
                    "UPDATE battle_reward_ledger SET payload_hash = ?, "
                    "game_mode = ?, updated_at = ? "
                    "WHERE player_id = ? AND battle_id = ?",
                    (payload_hash, game_mode, now, low_id, battle_id),
                )
            elif current[1] == payload_hash and int(current[2]) == game_mode:
                battle_id = current[0]
            else:
                completed = cls._completed(
                    connection, low_id, payload_hash, game_mode
                )
                if completed is None:
                    raise BattleInstanceError(
                        "Resultado divergente para a instância de partida aberta"
                    )
                battle_id = completed[0]
        player.battle_instance_id = battle_id
        return battle_id

    @classmethod
    def mark_home(cls, player):
        if not getattr(player, "token", ""):
            return
        low_id = cls._player_id(player)
        with DataBase._connection() as connection:
            connection.execute(
                "UPDATE battle_reward_ledger SET home_seen = 1, updated_at = ? "
                "WHERE player_id = ? AND is_current = 1",
                (int(time.time()), low_id),
            )
