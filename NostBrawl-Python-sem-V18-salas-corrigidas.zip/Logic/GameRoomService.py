import copy
import threading
import time

from Database.DatabaseManager import DataBase
from Files.CsvLogic.Skins import Skins
from Logic.EventRotation import EventError, EventRotation
from Logic.FriendService import FriendService


class GameRoomFullError(ValueError):
    pass


class GameRoomInviteError(ValueError):
    NO_FRIEND = 24
    REJECTED = 26
    BLOCKED = 27
    OFFLINE = 28
    ALREADY_IN_TEAM = 29

    def __init__(self, code):
        self.code = int(code)
        super().__init__(f"Convite de equipe recusado ({self.code})")


class GameRoomService:
    _entries = {}
    _next_room_id = 1
    _next_request_key = 1
    _lock = threading.RLock()
    INVITE_MUTE_SECONDS = 600
    INVITE_MUTES_KEY = "mutedTeamInviters"
    STREAM_LIMIT = 64
    INVITE_PENDING = 1
    INVITE_DECLINED = 2
    INVITE_OFFLINE = 3
    TEAM_PRESENCE = 3
    HOME_PRESENCE = 2
    DISBAND_REASON = 3

    @staticmethod
    def _now():
        return int(time.time())

    @classmethod
    def init(cls):
        with cls._lock:
            cls._entries = {}
            cls._next_room_id = 1
            cls._next_request_key = 1

    @classmethod
    def count(cls):
        with cls._lock:
            return len(cls._entries)

    @staticmethod
    def _account_id(player):
        try:
            low_id = int(getattr(player, "low_id", 0) or 0)
        except (TypeError, ValueError):
            low_id = 0
        if low_id <= 0:
            raise ValueError("Conta inválida para GameRoom")
        return low_id

    @staticmethod
    def _mapping_value(mapping, key, default=0):
        if not isinstance(mapping, dict):
            return default
        try:
            return int(mapping.get(str(key), mapping.get(key, default)) or 0)
        except (TypeError, ValueError):
            return default

    @staticmethod
    def _capacity(map_id):
        try:
            location = EventRotation.locations()[int(map_id)]
        except (IndexError, TypeError, ValueError):
            return 6
        if location["game_mode"] in {"BattleRoyale", "BattleRoyaleTeam"}:
            return 10
        if location["game_mode"] == "Survival":
            return 6
        if location["game_mode"] == "Raid":
            return 3
        return 6

    @staticmethod
    def _location(map_id):
        try:
            map_id = int(map_id)
        except (TypeError, ValueError):
            raise ValueError("Mapa inválido") from None
        locations = EventRotation.locations()
        if not 0 <= map_id < len(locations) or not locations[map_id]["enabled"]:
            raise ValueError("Mapa não habilitado")
        return locations[map_id]

    @classmethod
    def _map_for_create(cls, player, slot, requested_map):
        try:
            slot = int(slot)
            requested_map = int(requested_map)
        except (TypeError, ValueError):
            raise ValueError("Slot ou mapa inválido") from None
        if 1 <= slot <= len(EventRotation.SLOT_POOLS):
            event = EventRotation.resolve_slot(player, slot)
            return int(event["map_id"]), slot
        if requested_map == -64:
            event = EventRotation.resolve_slot(player, 0)
            return int(event["map_id"]), 0
        return int(cls._location(requested_map)["id"]), 0

    @classmethod
    def _selected_skin(cls, player, brawler):
        selected = getattr(player, "brawlers_skins", {})
        stored = isinstance(selected, dict) and (
            str(brawler) in selected or brawler in selected
        )
        if stored:
            skin = cls._mapping_value(selected, brawler, 0)
        elif int(getattr(player, "brawler_id", 0) or 0) == brawler:
            skin = int(getattr(player, "skin_id", 0) or 0)
        else:
            skin = 0
        return Skins.resolve_skin(brawler, skin)

    @classmethod
    def _new_member(cls, player, owner):
        low_id = cls._account_id(player)
        brawler = int(getattr(player, "brawler_id", 0) or 0)
        return {
            "low_id": low_id,
            "high_id": int(getattr(player, "high_id", 0) or 0),
            "host": bool(owner),
            "ready": False,
            "team": 0,
            "status": 3,
            "brawler_id": brawler,
            "skin_id": cls._selected_skin(player, brawler),
            "trophies": cls._mapping_value(
                getattr(player, "brawlers_trophies", {}), brawler
            ),
            "highest_trophies": cls._mapping_value(
                getattr(player, "brawlers_trophies", {}), brawler
            ),
            "power_level": cls._mapping_value(
                getattr(player, "Brawler_level", {}), brawler, 0
            ),
            "name": str(getattr(player, "name", "") or ""),
            "profile_icon": int(getattr(player, "profile_icon", 0) or 0),
            "name_color": int(getattr(player, "name_color", 0) or 0),
            "stream_from": 0,
            "_player": player,
        }

    @staticmethod
    def _public_member(member):
        return {
            key: copy.deepcopy(value)
            for key, value in member.items()
            if not key.startswith("_") and key != "stream_from"
        }

    @staticmethod
    def _public_invite(invite):
        return {
            "room_id": int(invite["room_id"]),
            "sender_id": int(invite["sender_id"]),
            "recipient_id": int(invite["recipient_id"]),
            "name": str(invite["name"]),
            "invite_type": int(invite["invite_type"]),
            "status": int(invite.get("status", GameRoomService.INVITE_PENDING)),
            "entry": copy.deepcopy(invite.get("entry")),
        }

    @staticmethod
    def _public_request(request):
        return {
            "key": int(request["key"]),
            "recipient_id": int(request["recipient_id"]),
            "requester_id": int(request["requester_id"]),
            "entry": copy.deepcopy(request.get("entry")),
        }

    @classmethod
    def _snapshot(cls, room):
        if room is None:
            return None
        members = [cls._public_member(member) for member in room["members"]]
        owner = next((member["low_id"] for member in members if member["host"]), 0)
        return {
            "id": int(room["id"]),
            "type": int(room["type"]),
            "map_id": int(room["map_id"]),
            "slot_index": int(room["slot_index"]),
            "map_slot": int(room.get("map_slot", 0)),
            "practice": bool(room["practice"]),
            "advertise_band": bool(room.get("advertise_band", False)),
            "advertise_friends": bool(room.get("advertise_friends", True)),
            "capacity": cls._capacity(room["map_id"]),
            "owner_id": owner,
            "player_count": len(members),
            "members": members,
            "invites": [
                cls._public_invite(invite) for invite in room.get("invites", [])
            ],
            "join_requests": [
                cls._public_request(item)
                for item in room.get("join_requests", [])
            ],
        }

    @staticmethod
    def _member(room, low_id):
        return next(
            (member for member in room["members"] if member["low_id"] == low_id),
            None,
        )

    @classmethod
    def _remove_member(cls, room, low_id):
        member = cls._member(room, low_id)
        if member is None:
            return False
        room["members"].remove(member)
        if not room["members"]:
            cls._entries.pop(room["id"], None)
            return True
        if not any(item["host"] for item in room["members"]):
            room["members"][0]["host"] = True
        for item in room["members"]:
            item["ready"] = False
        cls._prune_stream(room)
        return True

    @classmethod
    def _prune_stream(cls, room):
        members = room.get("members") or []
        if not members:
            room["stream"][:] = []
            return
        floor = min(int(member.get("stream_from", 0) or 0) for member in members)
        if floor > 0:
            room["stream"][:] = [
                entry for entry in room["stream"] if int(entry["id"]) > floor
            ]
        if len(room["stream"]) <= cls.STREAM_LIMIT:
            return
        excess = len(room["stream"]) - cls.STREAM_LIMIT
        new_floor = int(room["stream"][excess]["id"]) - 1
        room["stream"][:] = room["stream"][excess:]
        for member in members:
            if int(member.get("stream_from", 0) or 0) < new_floor:
                member["stream_from"] = new_floor

    @staticmethod
    def _session_player(sample, low_id):
        clients = getattr(sample, "ClientDict", None)
        if not isinstance(clients, dict):
            return None
        entry = clients.get("Clients", {}).get(str(int(low_id)))
        if not entry:
            return None
        player = entry.get("Player")
        if player is None or int(getattr(player, "low_id", 0) or 0) != int(low_id):
            return None
        return player

    @classmethod
    def _member_for_join(cls, request, requester_id):
        member = request.get("member")
        sample = request.get("player") or (member or {}).get("_player")
        player = cls._session_player(sample, requester_id) if sample is not None else None
        if player is None:
            player = (member or {}).get("_player")
        if player is None:
            return None
        request["player"] = player
        if member is None:
            member = cls._new_member(player, False)
            request["member"] = member
        member["_player"] = player
        return member

    @classmethod
    def _attach_member(cls, room, member, event=102):
        member["stream_from"] = int(room["entry_counter"])
        room["members"].append(member)
        cls._append_event(room, event, member)
        return member

    @classmethod
    def _drop_invites_of(cls, room, low_id):
        low_id = int(low_id)
        invites = room.get("invites", [])
        kept = [
            invite for invite in invites
            if low_id not in (int(invite["sender_id"]), int(invite["recipient_id"]))
        ]
        removed = len(kept) != len(invites)
        invites[:] = kept
        return removed

    @classmethod
    def _purge_player_references(cls, low_id):
        low_id = int(low_id)
        affected = []
        for room in cls._entries.values():
            changed = cls._drop_invites_of(room, low_id)
            requests = room.get("join_requests", [])
            pending = [
                request for request in requests
                if int(request["requester_id"]) == low_id
            ]
            if pending:
                requests[:] = [
                    request for request in requests
                    if int(request["requester_id"]) != low_id
                ]
                changed = True
            if changed:
                affected.append(cls._snapshot(room))
        return affected

    @classmethod
    def stream_for(cls, room, low_id):
        if room is None:
            return []
        room_id = int(room["id"]) if isinstance(room, dict) else int(room)
        with cls._lock:
            internal = cls._room(room_id)
            if internal is None:
                return []
            member = cls._member(internal, int(low_id)) if low_id else None
            after = (
                int(member.get("stream_from", 0) or 0)
                if member is not None else 0
            )
            return copy.deepcopy([
                entry for entry in internal.get("stream", [])
                if int(entry["id"]) > after
            ])

    @classmethod
    def _room(cls, room_id):
        try:
            return cls._entries.get(int(room_id))
        except (TypeError, ValueError):
            return None

    @classmethod
    def _room_for_player(cls, player):
        low_id = cls._account_id(player)
        try:
            room_id = int(getattr(player, "room_id", 0) or 0)
        except (TypeError, ValueError):
            room_id = 0
        room = cls._room(room_id) if room_id > 0 else None
        if room is not None and cls._member(room, low_id) is not None:
            return room
        return next(
            (
                candidate for candidate in cls._entries.values()
                if cls._member(candidate, low_id) is not None
            ),
            None,
        )

    @classmethod
    def _set_room_id(cls, player, room_id):
        low_id = cls._account_id(player)
        room_id = int(room_id)
        previous = int(getattr(player, "room_id", 0) or 0)
        token = getattr(player, "token", "")
        if previous != room_id and token not in (None, "", "None"):
            if not DataBase._update_value("lowID", low_id, "roomID", room_id):
                raise ValueError("Conta não encontrada ao atualizar equipe")
        player.room_id = room_id

    @classmethod
    def _bind_player(cls, player, room):
        cls._set_room_id(player, int(room["id"]) if room is not None else 0)
        if room is not None:
            player.map_id = int(room["map_id"])
            player.slot_index = int(room["slot_index"])

    @staticmethod
    def _clear_room_id(low_id):
        if not DataBase._update_value("lowID", int(low_id), "roomID", 0):
            raise ValueError("Conta não encontrada ao sair da equipe")

    @classmethod
    def sync_presence(cls, player, status):
        from Logic.PresenceService import PresenceService

        if player is None:
            return False
        if not PresenceService.set_status(player, int(status)):
            return False
        PresenceService.publish(player)
        return True

    @classmethod
    def _bind_room_members(cls, room, map_id, slot_index):
        participants = [
            member.get("_player") for member in room["members"]
            if member.get("_player") is not None
        ]
        room_id = int(room["id"])
        map_id = int(map_id)
        slot_index = int(slot_index)
        updates = []
        for participant in participants:
            low_id = cls._account_id(participant)
            previous = int(getattr(participant, "room_id", 0) or 0)
            token = getattr(participant, "token", "")
            if previous != room_id and token not in (None, "", "None"):
                updates.append(low_id)
        if updates:
            with DataBase._connection() as connection:
                connection.execute("BEGIN IMMEDIATE")
                for low_id in updates:
                    cursor = connection.execute(
                        "UPDATE players SET roomID = ? WHERE lowID = ?",
                        (room_id, low_id),
                    )
                    if cursor.rowcount != 1:
                        raise ValueError("Conta não encontrada ao atualizar equipe")
        for participant in participants:
            participant.room_id = room_id
            participant.map_id = map_id
            participant.slot_index = slot_index

    @classmethod
    def _append_event(cls, room, event, actor, target=None, swap_names=False):
        target = target or actor
        room["entry_counter"] += 1
        entry = {
            "kind": 4,
            "event": int(event),
            "id": int(room["entry_counter"]),
            "room_id": int(room["id"]),
            "player_id": int(actor["low_id"]),
            "player_name": str(target["name"] if swap_names else actor["name"]),
            "player_role": 0,
            "target_id": int(target["low_id"]),
            "target_name": str(actor["name"] if swap_names else target["name"]),
            "created_at": int(time.time()),
        }
        room["stream"].append(entry)
        cls._prune_stream(room)
        return entry

    @classmethod
    def get(cls, room_id):
        with cls._lock:
            return cls._snapshot(cls._room(room_id))

    @classmethod
    def get_room_id(cls, room_id):
        return cls.get(room_id)

    @classmethod
    def get_rooms(cls):
        with cls._lock:
            return [cls._snapshot(room) for room in cls._entries.values()]

    @classmethod
    def for_player(cls, player):
        low_id = cls._account_id(player)
        with cls._lock:
            room = cls._room_for_player(player)
            if room is None:
                cls._bind_player(player, None)
                return None
            member = cls._member(room, low_id)
            cls._bind_player(player, room)
            if member is not None:
                member["_player"] = player
            return cls._snapshot(room)

    @classmethod
    def clear_offline_invites(cls, player, clients=None):
        low_id = cls._account_id(player)
        registry = clients if clients is not None else getattr(player, "ClientDict", None)
        removed = []
        with cls._lock:
            for room in cls._entries.values():
                invites = room.get("invites", [])
                doomed = [
                    invite for invite in invites
                    if int(invite["recipient_id"]) == low_id
                    and int(invite.get("status", cls.INVITE_PENDING))
                    == cls.INVITE_OFFLINE
                ]
                if not doomed:
                    continue
                for invite in doomed:
                    invites.remove(invite)
                removed.append(cls._snapshot(room))
        if registry is not None:
            for snapshot in removed:
                cls._notify_room(snapshot)
        return removed

    @classmethod
    def _notify_room(cls, snapshot):
        from Logic.GameRoomGateway import GameRoomGateway

        if snapshot is None:
            return
        GameRoomGateway.broadcast_data(None, snapshot)

    @classmethod
    def resume(cls, player):
        room = cls.for_player(player)
        if room is None:
            return None
        room = cls.set_status(player, 3)
        if room is not None:
            cls.sync_presence(player, cls.TEAM_PRESENCE)
        return room

    @classmethod
    def disconnect(cls, player):
        result = {
            "room": None, "departed": False, "disbanded": [], "host": False,
        }
        low_id = cls._account_id(player)
        with cls._lock:
            room = cls._room_for_player(player)
            if room is not None:
                member = cls._member(room, low_id)
                if member is not None and member.get("_player") is player:
                    result = cls._exit_locked(player, room, member)
            cls._purge_player_references(low_id)
            return result

    @classmethod
    def create_transition(cls, player, slot=0, requested_map=0, room_type=0, practice=False):
        low_id = cls._account_id(player)
        map_id, slot = cls._map_for_create(player, slot, requested_map)
        with cls._lock:
            current = cls._room_for_player(player)
            room_id = cls._next_room_id
            room = {
                "id": room_id,
                "type": int(room_type),
                "practice": bool(practice),
                "advertise_band": False,
                "advertise_friends": True,
                "map_id": map_id,
                "slot_index": int(slot),
                "map_slot": int(slot),
                "members": [cls._new_member(player, True)],
                "invites": [],
                "join_requests": [],
                "stream": [],
                "entry_counter": 0,
            }
            cls._append_event(room, 101, room["members"][0])
            cls._bind_player(player, room)
            previous = None
            if current is not None:
                previous_member = cls._member(current, low_id)
                cls._append_event(current, 103, previous_member)
                cls._remove_member(current, low_id)
                if current["members"]:
                    previous = cls._snapshot(current)
            cls._entries[room_id] = room
            cls._next_room_id += 1
            return cls._snapshot(room), previous, current is not None

    @classmethod
    def create(cls, player, slot=0, requested_map=0, room_type=0, practice=False):
        room, _, _ = cls.create_transition(player, slot, requested_map, room_type, practice)
        return room

    @classmethod
    def request_join_transition(cls, player, room_id):
        low_id = cls._account_id(player)
        with cls._lock:
            target = cls._room(room_id)
            if target is None:
                return None, None, False
            previous = None
            departed = False
            current = cls._room_for_player(player)
            if current is not None and current["id"] == target["id"]:
                cls._bind_player(player, target)
                return cls._snapshot(target), None, False
            if len(target["members"]) >= cls._capacity(target["map_id"]):
                raise GameRoomFullError("Equipe cheia")
            member = cls._new_member(player, False)
            cls._bind_player(player, target)
            if current is not None:
                previous_member = cls._member(current, low_id)
                cls._append_event(current, 103, previous_member)
                cls._remove_member(current, low_id)
                departed = True
                if current["members"]:
                    previous = cls._snapshot(current)
            target["invites"][:] = [
                invite for invite in target["invites"]
                if int(invite["recipient_id"]) != low_id
            ]
            cls._attach_member(target, member)
            return cls._snapshot(target), previous, departed

    @classmethod
    def request_join(cls, player, room_id):
        room, _, _ = cls.request_join_transition(player, room_id)
        return room

    @classmethod
    def join(cls, player, room_id):
        return cls.request_join(player, room_id)

    @classmethod
    def _find_request(cls, low_id, key):
        for room in cls._entries.values():
            for item in room.get("join_requests", []):
                if int(item["key"]) == key and int(item["recipient_id"]) == low_id:
                    return room, item
        return None, None

    @classmethod
    def _requests_from(cls, player):
        low_id = cls._account_id(player)
        with cls._lock:
            affected = []
            for room in cls._entries.values():
                requests = room.get("join_requests", [])
                removed = [
                    item for item in requests
                    if int(item["requester_id"]) == low_id
                ]
                if not removed:
                    continue
                requests[:] = [
                    item for item in requests
                    if int(item["requester_id"]) != low_id
                ]
                affected.append(
                    (
                        cls._snapshot(room),
                        [cls._public_request(item) for item in removed],
                    )
                )
            return affected

    @classmethod
    def request_join_request(cls, player, recipient_id, room_id):
        low_id = cls._account_id(player)
        try:
            recipient_id = int(recipient_id)
            room_id = int(room_id)
        except (TypeError, ValueError):
            return None, None
        with cls._lock:
            room = cls._room(room_id)
            if room is None:
                return None, None
            if cls._member(room, recipient_id) is None:
                return None, None
            if cls._member(room, low_id) is not None:
                return None, None
            pending = [
                item for item in room.setdefault("join_requests", [])
                if int(item["requester_id"]) != low_id
            ]
            if (
                len(room["members"]) + len(room["invites"]) + len(pending)
                >= cls._capacity(room["map_id"])
            ):
                raise GameRoomFullError("Equipe cheia")
            with DataBase._connection() as connection:
                progression = DataBase._read_state(
                    connection, recipient_id, "progression"
                )
                mutes = progression.get(cls.INVITE_MUTES_KEY, {})
                if not isinstance(mutes, dict):
                    raise ValueError("Silenciamentos de convites inválidos")
                if int(mutes.get(str(low_id), 0) or 0) > cls._now():
                    return None, None
                entry = FriendService._entry(connection, recipient_id, low_id)
            if entry is None:
                return None, None
            pending = [
                item for item in pending
                if int(item["recipient_id"]) != recipient_id
            ]
            request = {
                "player": player,
                "key": int(cls._next_request_key),
                "room_id": int(room["id"]),
                "recipient_id": recipient_id,
                "requester_id": low_id,
                "entry": entry,
                "member": cls._new_member(player, False),
            }
            cls._next_request_key += 1
            pending.append(request)
            room["join_requests"][:] = pending
            return cls._snapshot(room), cls._public_request(request)

    @classmethod
    def cancel_join_requests(cls, player):
        return cls._requests_from(player)

    @classmethod
    def respond_join_request(cls, player, key, accepted, mute_requester=False):
        low_id = cls._account_id(player)
        try:
            key = int(key)
        except (TypeError, ValueError):
            return None
        accepted = bool(accepted)
        with cls._lock:
            room, request = cls._find_request(low_id, key)
            if room is None:
                return None
            mutes = None
            if mute_requester:
                mutes = cls._mute_inviter(player, int(request["requester_id"]))
            room["join_requests"].remove(request)
            outcome = {
                "room": None,
                "previous": None,
                "request": cls._public_request(request),
                "accepted": accepted,
                "joined": False,
                "mutes": mutes,
            }
            if not accepted:
                outcome["room"] = cls._snapshot(room)
                return outcome
            requester_id = int(request["requester_id"])
            member = cls._member(room, requester_id)
            if member is None:
                if len(room["members"]) >= cls._capacity(room["map_id"]):
                    room["join_requests"].append(request)
                    raise GameRoomFullError("Equipe cheia")
                current = next(
                    (
                        candidate for candidate in cls._entries.values()
                        if candidate["id"] != room["id"]
                        and cls._member(candidate, requester_id) is not None
                    ),
                    None,
                )
                member = cls._member_for_join(request, requester_id)
                if member is None:
                    outcome["room"] = cls._snapshot(room)
                    return outcome
                if current is not None:
                    previous_member = cls._member(current, requester_id)
                    cls._append_event(current, 103, previous_member)
                    cls._remove_member(current, requester_id)
                    if current["members"]:
                        outcome["previous"] = cls._snapshot(current)
                cls._attach_member(room, member)
                if not DataBase._update_value(
                    "lowID", requester_id, "roomID", int(room["id"])
                ):
                    room["members"].remove(member)
                    room["stream"].pop()
                    room["join_requests"].append(request)
                    raise ValueError("Conta não encontrada ao entrar na equipe")
                requester = member.get("_player")
                if requester is not None:
                    requester.room_id = int(room["id"])
                    requester.map_id = int(room["map_id"])
                    requester.slot_index = int(room["slot_index"])
                outcome["joined"] = True
            outcome["room"] = cls._snapshot(room)
            return outcome

    @classmethod
    def _exit_locked(cls, player, room, member):
        low_id = cls._account_id(player)
        result = {"room": None, "departed": False, "disbanded": [], "host": False}
        host = bool(member["host"])
        cls._bind_player(player, None)
        cls._append_event(room, 103, member)
        cls._drop_invites_of(room, low_id)
        if host and len(room["members"]) > 1:
            remaining = [
                item for item in room["members"] if item is not member
            ]
            room["members"].remove(member)
            cls._entries.pop(room["id"], None)
            for item in remaining:
                participant = item.get("_player")
                if participant is not None:
                    cls._set_room_id(participant, 0)
                else:
                    cls._clear_room_id(item["low_id"])
                item["stream_from"] = 0
            room["members"][:] = []
            room["stream"][:] = []
            result["departed"] = True
            result["host"] = True
            result["disbanded"] = remaining
            return result
        cls._remove_member(room, low_id)
        result["departed"] = True
        result["host"] = host
        if room["members"]:
            result["room"] = cls._snapshot(room)
        return result

    @classmethod
    def leave_transition(cls, player):
        low_id = cls._account_id(player)
        with cls._lock:
            result = {"room": None, "departed": False, "disbanded": [], "host": False}
            room = cls._room_for_player(player)
            if room is None:
                cls._bind_player(player, None)
                cls._purge_player_references(low_id)
                return result
            member = cls._member(room, low_id)
            if member is None:
                cls._bind_player(player, None)
                cls._purge_player_references(low_id)
                return result
            result = cls._exit_locked(player, room, member)
            cls._purge_player_references(low_id)
            return result

    @classmethod
    def leave(cls, player):
        result = cls.leave_transition(player)
        return result["room"], result["departed"]

    @classmethod
    def kick_transition(cls, player, target_id):
        result = {"room": None, "target_id": 0, "target": None}
        cls._account_id(player)
        try:
            target_id = int(target_id)
        except (TypeError, ValueError):
            return result
        with cls._lock:
            room = cls._room_for_player(player)
            if room is None:
                return result
            actor = cls._member(room, int(player.low_id))
            target = cls._member(room, target_id)
            if actor is None or not actor["host"] or target is None:
                return result
            target_player = target.get("_player")
            if target_player is not None:
                cls._bind_player(target_player, None)
            cls._append_event(room, 104, actor, target, swap_names=True)
            cls._remove_member(room, target_id)
            result["room"] = cls._snapshot(room) if room["members"] else None
            result["target_id"] = target_id
            result["target"] = target_player
            return result

    @classmethod
    def kick(cls, player, target_id):
        result = cls.kick_transition(player, target_id)
        return result["room"], result["target_id"]

    @classmethod
    def set_ranked_location(cls, player, map_id, slot):
        try:
            map_id = int(map_id)
            slot = int(slot)
        except (TypeError, ValueError):
            raise ValueError("Mapa ou slot de evento inválido") from None
        with cls._lock:
            room = cls._room_for_player(player)
            if room is None:
                return None
            event = EventRotation.resolve_slot(player, slot)
            if int(event["slot"]) != slot:
                raise EventError("Slot de evento inexistente")
            if int(event["map_id"]) != map_id:
                raise ValueError("Mapa divergente para o slot do evento")
            cls._bind_room_members(room, event["map_id"], event["slot"])
            room["slot_index"] = int(event["slot"])
            room["map_slot"] = int(event["slot"])
            room["map_id"] = int(event["map_id"])
            room["type"] = 0
            return cls._snapshot(room)

    @classmethod
    def set_location(cls, player, map_id):
        with cls._lock:
            room = cls._room_for_player(player)
            if room is None:
                return None
            location = cls._location(map_id)
            cls._bind_room_members(room, location["id"], 0)
            room["map_id"] = int(location["id"])
            room["slot_index"] = 0
            room["map_slot"] = 0
            room["type"] = 1
            return cls._snapshot(room)

    @classmethod
    def toggle_practice(cls, player):
        with cls._lock:
            room = cls._room_for_player(player)
            if room is None:
                return None
            room["practice"] = not bool(room["practice"])
            return cls._snapshot(room)

    @classmethod
    def toggle_advertise_band(cls, player):
        with cls._lock:
            room = cls._room_for_player(player)
            if room is None:
                return None
            room["advertise_band"] = not bool(
                room.get("advertise_band", False)
            )
            return cls._snapshot(room)

    @classmethod
    def set_ready(cls, player, ready):
        low_id = cls._account_id(player)
        with cls._lock:
            room = cls._room_for_player(player)
            if room is None:
                return None
            member = cls._member(room, low_id)
            if member is not None:
                member["ready"] = bool(ready)
            return cls._snapshot(room)

    @classmethod
    def begin_battle(cls, player):
        cls._account_id(player)
        with cls._lock:
            room = cls._room_for_player(player)
            if room is None or room.get("battle_started", False):
                return None
            room["battle_started"] = True
            participants = []
            for member in room["members"]:
                member["ready"] = False
                if member["status"] != 0:
                    member["status"] = 5
                participant = member.get("_player")
                if participant is not None:
                    participants.append(participant)
            return cls._snapshot(room), participants

    @classmethod
    def set_status(cls, player, status):
        low_id = cls._account_id(player)
        with cls._lock:
            room = cls._room_for_player(player)
            if room is None:
                return None
            member = cls._member(room, low_id)
            if member is not None:
                member["status"] = int(status)
                member["_player"] = player
            return cls._snapshot(room)

    @classmethod
    def set_teams(cls, player, targets, team):
        with cls._lock:
            room = cls._room_for_player(player)
            if room is None or not targets:
                return None
            members = []
            for high_id, target_id in targets:
                member = cls._member(room, int(target_id))
                if member is not None and int(member["high_id"]) == int(high_id):
                    members.append(member)
            if not members:
                return None
            side = 1 if int(team) >= 3 else 0
            for member in members:
                member["team"] = side
            return cls._snapshot(room)

    @classmethod
    def set_member_settings(cls, player, brawler_id=0, skin_id=0):
        low_id = cls._account_id(player)
        brawler = int(brawler_id)
        with cls._lock:
            room = cls._room_for_player(player)
            if room is None:
                return None
            member = cls._member(room, low_id)
            if member is None:
                return cls._snapshot(room)
            member["_player"] = player
            member["brawler_id"] = brawler
            member["skin_id"] = int(skin_id)
            member["trophies"] = cls._mapping_value(
                getattr(player, "brawlers_trophies", {}), brawler
            )
            member["highest_trophies"] = cls._mapping_value(
                getattr(player, "brawlers_trophies", {}), brawler
            )
            member["power_level"] = cls._mapping_value(
                getattr(player, "Brawler_level", {}), brawler, 0
            )
            return cls._snapshot(room)

    @classmethod
    def pending_invites(cls, room):
        return [
            invite for invite in room.get("invites", [])
            if int(invite.get("status", cls.INVITE_PENDING)) == cls.INVITE_PENDING
        ]

    @classmethod
    def _room_for_account(cls, low_id):
        for room in cls._entries.values():
            if cls._member(room, int(low_id)) is not None:
                return room
        return None

    @classmethod
    def _invite_room(cls, recipient_id, sender_id):
        found = []
        for room in cls._entries.values():
            for invite in cls.pending_invites(room):
                if int(invite["recipient_id"]) != int(recipient_id):
                    continue
                if int(invite["sender_id"]) != int(sender_id):
                    continue
                found.append(room)
                break
        return found[-1] if found else None

    @classmethod
    def _invite_of(cls, room, recipient_id, sender_id):
        for invite in cls.pending_invites(room):
            if int(invite["recipient_id"]) != int(recipient_id):
                continue
            if int(invite["sender_id"]) != int(sender_id):
                continue
            return invite
        return None

    @classmethod
    def invite(cls, player, recipient_id, invite_type=0):
        sender_id = cls._account_id(player)
        recipient_id = int(recipient_id)
        with cls._lock:
            room = cls._room_for_player(player)
            if room is None or recipient_id == sender_id:
                return None, None
            if cls._member(room, recipient_id) is not None:
                raise GameRoomInviteError(GameRoomInviteError.ALREADY_IN_TEAM)
            if any(
                int(invite["recipient_id"]) == recipient_id
                for invite in cls.pending_invites(room)
            ):
                return None, None
            if len(room["members"]) + len(cls.pending_invites(room)) >= cls._capacity(
                room["map_id"]
            ):
                raise GameRoomFullError("Equipe cheia")
            if cls._room_for_account(recipient_id) is not None:
                raise GameRoomInviteError(GameRoomInviteError.ALREADY_IN_TEAM)
            with DataBase._connection() as connection:
                account = connection.execute(
                    "SELECT name, DoNotDistrub FROM players WHERE lowID = ?",
                    (recipient_id,),
                ).fetchone()
                if account is None:
                    raise GameRoomInviteError(GameRoomInviteError.NO_FRIEND)
                progression = DataBase._read_state(connection, recipient_id, "progression")
                mutes = progression.get(cls.INVITE_MUTES_KEY, {})
                if not isinstance(mutes, dict):
                    raise ValueError("Silenciamentos de convites inválidos")
                until = int(mutes.get(str(sender_id), 0) or 0)
                if int(account[1] or 0) == 1 or until > cls._now():
                    raise GameRoomInviteError(GameRoomInviteError.BLOCKED)
                entry = FriendService._entry(
                    connection, recipient_id, sender_id
                )
            if entry is None:
                raise GameRoomInviteError(GameRoomInviteError.NO_FRIEND)
            room["invites"][:] = [
                invite for invite in room.get("invites", [])
                if int(invite["recipient_id"]) != recipient_id
            ]
            invite = {
                "room_id": int(room["id"]),
                "sender_id": sender_id,
                "recipient_id": recipient_id,
                "name": str(account[0] or ""),
                "invite_type": int(invite_type),
                "status": cls.INVITE_PENDING,
                "entry": entry,
            }
            room["invites"].append(invite)
            return cls._snapshot(room), cls._public_invite(invite)

    @classmethod
    def mark_invite(cls, player, recipient_id, status):
        sender_id = cls._account_id(player)
        with cls._lock:
            room = cls._room_for_player(player)
            if room is None:
                return None, None
            for invite in room.get("invites", []):
                if int(invite["recipient_id"]) != int(recipient_id):
                    continue
                if int(invite["sender_id"]) != sender_id:
                    continue
                invite["status"] = int(status)
                return cls._snapshot(room), cls._public_invite(invite)
            return None, None

    @classmethod
    def decline_invite_from(cls, player, sender_id, mute_sender=False):
        low_id = cls._account_id(player)
        sender_id = int(sender_id)
        with cls._lock:
            room = cls._invite_room(low_id, sender_id)
            if room is None:
                return None, None
            invite = cls._invite_of(room, low_id, sender_id)
            if invite is None:
                return None, None
            if cls._member(room, sender_id) is None:
                room["invites"].remove(invite)
                return None, None
            if mute_sender:
                cls._mute_inviter(player, sender_id)
            invite["status"] = cls.INVITE_DECLINED
            return cls._snapshot(room), cls._public_invite(invite)

    @classmethod
    def cancel_invite(cls, player, high_id, low_id):
        actor_id = cls._account_id(player)
        try:
            high_id = int(high_id)
            low_id = int(low_id)
        except (TypeError, ValueError):
            return None, None
        if high_id != 0:
            return None, None
        with cls._lock:
            room = cls._room_for_player(player)
            if room is not None:
                for invite in list(room.get("invites", [])):
                    if int(invite["recipient_id"]) != low_id:
                        continue
                    if int(invite["sender_id"]) != actor_id:
                        continue
                    room["invites"].remove(invite)
                    return cls._snapshot(room), cls._public_invite(invite)
                return None, None
            room = cls._invite_room(actor_id, low_id)
            if room is None:
                return None, None
            invite = cls._invite_of(room, actor_id, low_id)
            if invite is None:
                return None, None
            room["invites"].remove(invite)
            return cls._snapshot(room), cls._public_invite(invite)

    @classmethod
    def accept_invite_from(cls, player, sender_id, mute_sender=False):
        low_id = cls._account_id(player)
        sender_id = int(sender_id)
        with cls._lock:
            room = cls._invite_room(low_id, sender_id)
            if room is None:
                return None, None
            return cls.accept_invite(player, int(room["id"]), mute_sender)

    @classmethod
    def _mute_inviter_locked(cls, connection, low_id, sender_id):
        progression = DataBase._read_state(connection, low_id, "progression")
        mutes = progression.get(cls.INVITE_MUTES_KEY, {})
        if not isinstance(mutes, dict):
            raise ValueError("Silenciamentos de convites inválidos")
        now = cls._now()
        mutes = {key: int(value) for key, value in mutes.items() if int(value) > now}
        mutes[str(int(sender_id))] = now + cls.INVITE_MUTE_SECONDS
        progression[cls.INVITE_MUTES_KEY] = mutes
        DataBase._write_state(connection, low_id, "progression", progression)
        return mutes

    @classmethod
    def _mute_inviter(cls, player, sender_id):
        low_id = cls._account_id(player)
        with DataBase._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            account = connection.execute(
                "SELECT token FROM players WHERE lowID = ?", (low_id,)
            ).fetchone()
            if account is None or account[0] != getattr(player, "token", None):
                raise ValueError("Conta não encontrada ao silenciar convite")
            mutes = cls._mute_inviter_locked(connection, low_id, sender_id)
        if not isinstance(getattr(player, "progression", None), dict):
            player.progression = {}
        player.progression[cls.INVITE_MUTES_KEY] = dict(mutes)

    @classmethod
    def _take_invite(cls, player, room_id, mute_sender=False):
        low_id = cls._account_id(player)
        room = cls._room(room_id)
        if room is None:
            return None, None, None
        index = next(
            (
                index for index, invite in enumerate(room.get("invites", []))
                if int(invite["recipient_id"]) == low_id
                and int(invite.get("status", cls.INVITE_PENDING)) == cls.INVITE_PENDING
            ),
            None,
        )
        if index is None:
            return room, None, None
        invite = room["invites"][index]
        if cls._member(room, int(invite["sender_id"])) is None:
            room["invites"].pop(index)
            return room, None, None
        if mute_sender:
            cls._mute_inviter(player, invite["sender_id"])
        room["invites"].pop(index)
        return room, invite, cls._public_invite(invite)

    @classmethod
    def clear_invite(cls, player, room_id, mute_sender=False):
        with cls._lock:
            room, _, invite = cls._take_invite(player, room_id, mute_sender)
            if room is None or invite is None:
                return None, None
            return cls._snapshot(room), invite

    @classmethod
    def accept_invite(cls, player, room_id, mute_sender=False):
        low_id = cls._account_id(player)
        with cls._lock:
            room = cls._room(room_id)
            if room is None:
                return None, None
            raw_invite = next(
                (item for item in cls.pending_invites(room)
                 if int(item["recipient_id"]) == low_id),
                None,
            )
            if raw_invite is None:
                return None, None
            if cls._member(room, int(raw_invite["sender_id"])) is None:
                room["invites"].remove(raw_invite)
                return None, None
            invite = cls._public_invite(raw_invite)
            member = None if cls._member(room, low_id) else cls._new_member(player, False)
            if member is not None and len(room["members"]) >= cls._capacity(room["map_id"]):
                raise GameRoomFullError("Equipe cheia")
            current = cls._room_for_player(player) if member is not None else None
            token = getattr(player, "token", "")
            mutes = None
            if token not in (None, "", "None"):
                with DataBase._connection() as connection:
                    connection.execute("BEGIN IMMEDIATE")
                    account = connection.execute(
                        "SELECT token FROM players WHERE lowID = ?", (low_id,)
                    ).fetchone()
                    if account is None or account[0] != token:
                        raise ValueError("Conta não encontrada ao aceitar convite")
                    if mute_sender:
                        mutes = cls._mute_inviter_locked(connection, low_id, raw_invite["sender_id"])
                    cursor = connection.execute(
                        "UPDATE players SET roomID = ? WHERE lowID = ? AND token = ?",
                        (int(room["id"]), low_id, token),
                    )
                    if cursor.rowcount != 1:
                        raise ValueError("Falha ao persistir entrada na equipe")
            elif mute_sender:
                raise ValueError("Conta não encontrada ao silenciar convite")
            room["invites"].remove(raw_invite)
            if member is not None:
                if current is not None and current["id"] != room["id"]:
                    previous_member = cls._member(current, low_id)
                    cls._append_event(current, 103, previous_member)
                    cls._remove_member(current, low_id)
                cls._attach_member(room, member)
            player.room_id = int(room["id"])
            player.map_id = int(room["map_id"])
            player.slot_index = int(room["slot_index"])
            if mutes is not None:
                if not isinstance(getattr(player, "progression", None), dict):
                    player.progression = {}
                player.progression[cls.INVITE_MUTES_KEY] = dict(mutes)
            return cls._snapshot(room), invite

    @classmethod
    def add_chat(cls, player, text):
        low_id = cls._account_id(player)
        with cls._lock:
            room = cls._room_for_player(player)
            if room is None:
                return None, None
            room["entry_counter"] += 1
            chat = {
                "kind": 2,
                "id": int(room["entry_counter"]),
                "room_id": int(room["id"]),
                "player_id": low_id,
                "player_name": str(getattr(player, "name", "") or ""),
                "player_role": 0,
                "message": str(text or ""),
                "created_at": int(time.time()),
            }
            room["stream"].append(chat)
            cls._prune_stream(room)
            return cls._snapshot(room), copy.deepcopy(chat)

    @classmethod
    def stream(cls, room_id, after_id=0):
        with cls._lock:
            room = cls._room(room_id)
            if room is None:
                return []
            return copy.deepcopy([
                entry for entry in room["stream"]
                if entry["id"] > int(after_id)
            ])

    @classmethod
    def chats(cls, room_id, after_id=0):
        return [
            entry for entry in cls.stream(room_id, after_id)
            if entry["kind"] == 2
        ]
