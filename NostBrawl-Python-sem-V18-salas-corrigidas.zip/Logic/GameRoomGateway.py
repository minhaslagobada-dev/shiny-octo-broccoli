from Packets.Messages.Server.Gameroom.TeamGameroomDataMessage import TeamGameroomDataMessage
from Packets.Messages.Server.Gameroom.TeamGameStartingMessage import TeamGameStartingMessage
from Packets.Messages.Server.Gameroom.TeamLeaveOkMessage import TeamLeaveOkMessage
from Packets.Messages.Server.Gameroom.TeamLeftMessage import TeamLeftMessage
from Packets.Messages.Server.Gameroom.TeamStreamMessage import TeamStreamMessage


class GameRoomGateway:
    @staticmethod
    def _stream_entries(room, low_id):
        from Logic.GameRoomService import GameRoomService

        return GameRoomService.stream_for(room, int(low_id))

    @staticmethod
    def deliver_data(client, player, room):
        if room is not None:
            TeamGameroomDataMessage(client, player, room).send()

    @staticmethod
    def send_data_to(low_id, player, room):
        if room is None:
            return False
        return TeamGameroomDataMessage(
            None, player, room
        ).sendWithLowID(int(low_id))

    @staticmethod
    def broadcast_data(player, room, client=None):
        if room is None:
            return
        current_id = int(getattr(player, "low_id", 0) or 0)
        if client is not None:
            TeamGameroomDataMessage(client, player, room).send()
        for member in room["members"]:
            low_id = int(member["low_id"])
            if client is not None and low_id == current_id:
                continue
            TeamGameroomDataMessage(None, player, room).sendWithLowID(low_id)

    @staticmethod
    def broadcast_data_and_stream(player, room, client=None, stream_first=False):
        if room is None:
            return
        current_id = int(getattr(player, "low_id", 0) or 0)
        if client is not None:
            if stream_first:
                TeamStreamMessage(
                    client, player, room,
                    GameRoomGateway._stream_entries(room, current_id),
                ).send()
                TeamGameroomDataMessage(client, player, room).send()
            else:
                TeamGameroomDataMessage(client, player, room).send()
                TeamStreamMessage(
                    client, player, room,
                    GameRoomGateway._stream_entries(room, current_id),
                ).send()
        for member in room["members"]:
            low_id = int(member["low_id"])
            if client is not None and low_id == current_id:
                continue
            entries = GameRoomGateway._stream_entries(room, low_id)
            if stream_first:
                TeamStreamMessage(None, player, room, entries).sendWithLowID(low_id)
                TeamGameroomDataMessage(None, player, room).sendWithLowID(low_id)
            else:
                TeamGameroomDataMessage(None, player, room).sendWithLowID(low_id)
                TeamStreamMessage(None, player, room, entries).sendWithLowID(low_id)

    @staticmethod
    def send_starting(player, room):
        if room is None:
            return 0
        delivered = 0
        for member in room["members"]:
            message = TeamGameStartingMessage(None, player, room)
            if message.sendWithLowID(int(member["low_id"])):
                delivered += 1
        return delivered

    @staticmethod
    def send_left(player, low_id, reason=0, client=None):
        message = TeamLeftMessage(client, player, reason)
        if client is not None:
            message.send()
        else:
            message.sendWithLowID(low_id)

    @staticmethod
    def send_leave_ok(player, low_id):
        TeamLeaveOkMessage(None, player).sendWithLowID(low_id)
