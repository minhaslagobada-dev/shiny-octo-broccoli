import time
from datetime import datetime

from Database.DatabaseManager import DataBase


class DailyRewardError(ValueError):
    pass


class DailyRewards:
    TOKEN_LIMIT = 700
    TOKEN_REFILL_AMOUNT = 20
    TOKEN_REFILL_INTERVAL = 144 * 60
    STAR_AMOUNT = 1

    @staticmethod
    def _moment(now=None):
        return datetime.now() if now is None else now

    @classmethod
    def _day(cls, now=None):
        return cls._moment(now).date().isoformat()

    @staticmethod
    def _player_id(player):
        try:
            low_id = int(getattr(player, "low_id", 0) or 0)
        except (TypeError, ValueError):
            return 0
        token = getattr(player, "token", None)
        if low_id <= 0 or not isinstance(token, str) or not token or token == "None":
            return 0
        return low_id

    @classmethod
    def _timestamp(cls, now=None):
        return int(cls._moment(now).timestamp())

    @classmethod
    def _ensure_locked(cls, connection, low_id, now=None):
        moment = cls._moment(now)
        timestamp = cls._timestamp(moment)
        account = connection.execute(
            "SELECT battleTokens FROM players WHERE lowID = ?", (low_id,)
        ).fetchone()
        if account is None:
            raise DailyRewardError("Conta não encontrada para os tokens")
        balance = max(0, min(cls.TOKEN_LIMIT, int(account[0] or 0)))
        row = connection.execute(
            "SELECT next_refill_at FROM battle_token_refill WHERE player_id = ?",
            (low_id,),
        ).fetchone()
        if row is None:
            next_at = timestamp + cls.TOKEN_REFILL_INTERVAL if balance < cls.TOKEN_LIMIT else 0
            connection.execute(
                "INSERT INTO battle_token_refill (player_id, next_refill_at) VALUES (?, ?)",
                (low_id, next_at),
            )
        else:
            next_at = int(row[0])
            if balance >= cls.TOKEN_LIMIT:
                next_at = 0
            elif next_at <= 0:
                next_at = timestamp + cls.TOKEN_REFILL_INTERVAL
            elif timestamp >= next_at:
                steps = 1 + (timestamp - next_at) // cls.TOKEN_REFILL_INTERVAL
                balance = min(cls.TOKEN_LIMIT, balance + steps * cls.TOKEN_REFILL_AMOUNT)
                next_at = 0 if balance >= cls.TOKEN_LIMIT else next_at + steps * cls.TOKEN_REFILL_INTERVAL
            connection.execute(
                "UPDATE battle_token_refill SET next_refill_at = ? WHERE player_id = ?",
                (next_at, low_id),
            )
        cursor = connection.execute(
            "UPDATE players SET battleTokens = ? WHERE lowID = ?",
            (balance, low_id),
        )
        if cursor.rowcount != 1:
            raise DailyRewardError("Conta não encontrada para os tokens")
        return {
            "day": cls._day(moment),
            "limit": cls.TOKEN_LIMIT,
            "used": cls.TOKEN_LIMIT - balance,
            "remaining": balance,
            "old_battle_tokens": balance,
            "next_refill_at": next_at,
            "next_refill_in": max(0, next_at - timestamp) if next_at else 0,
        }

    @classmethod
    def sync_player(cls, player, now=None):
        low_id = cls._player_id(player)
        if low_id <= 0:
            remaining = max(
                0, min(cls.TOKEN_LIMIT, int(getattr(player, "battle_tokens", 0) or 0))
            )
            return {
                "day": cls._day(now),
                "limit": cls.TOKEN_LIMIT,
                "used": cls.TOKEN_LIMIT - remaining,
                "remaining": remaining,
                "next_refill_at": 0,
                "next_refill_in": 0,
                "persisted": False,
            }
        with DataBase._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            state = cls._ensure_locked(connection, low_id, now)
        player.battle_tokens = state["remaining"]
        state["persisted"] = True
        return state

    @classmethod
    def consume(cls, connection, low_id, requested, doubler=0, now=None):
        try:
            low_id = int(low_id)
            requested = int(requested)
            doubler = max(0, int(doubler))
        except (TypeError, ValueError):
            raise DailyRewardError("Recompensa diária inválida") from None
        if low_id <= 0 or requested < 0:
            raise DailyRewardError("Recompensa diária inválida")
        moment = cls._moment(now)
        state = cls._ensure_locked(connection, low_id, moment)
        base = min(requested, state["remaining"])
        doubled = min(base, doubler)
        total = base + doubled
        if base:
            state["remaining"] -= base
            state["used"] = cls.TOKEN_LIMIT - state["remaining"]
            if not state["next_refill_at"]:
                state["next_refill_at"] = cls._timestamp(moment) + cls.TOKEN_REFILL_INTERVAL
                state["next_refill_in"] = cls.TOKEN_REFILL_INTERVAL
                connection.execute(
                    "UPDATE battle_token_refill SET next_refill_at = ? WHERE player_id = ?",
                    (state["next_refill_at"], low_id),
                )
            cursor = connection.execute(
                "UPDATE players SET battleTokens = ? WHERE lowID = ?",
                (state["remaining"], low_id),
            )
            if cursor.rowcount != 1:
                raise DailyRewardError("Falha ao atualizar os tokens")
        state.update({
            "requested_tokens": requested,
            "tokens_gain": base,
            "doubled_tokens": doubled,
            "total_tokens": total,
            "remaining_doubler": doubler - doubled,
            "battle_tokens": state["remaining"],
        })
        return state

    @classmethod
    def claim_star(cls, connection, low_id, map_id, battle_id, eligible, now=None):
        if not eligible:
            return False
        try:
            low_id = int(low_id)
            map_id = int(map_id)
        except (TypeError, ValueError):
            raise DailyRewardError("Evento da ficha estrela inválido") from None
        if low_id <= 0 or map_id < 0 or not battle_id:
            raise DailyRewardError("Ficha estrela exige partida e evento persistentes")
        day = cls._day(now)
        existing = connection.execute(
            "SELECT 1 FROM daily_star_rewards "
            "WHERE player_id = ? AND day = ? AND map_id = ?",
            (low_id, day, map_id),
        ).fetchone()
        if existing is not None:
            return False
        connection.execute(
            "INSERT INTO daily_star_rewards ("
            "player_id, day, map_id, amount, battle_id, created_at"
            ") VALUES (?, ?, ?, ?, ?, ?)",
            (low_id, day, map_id, cls.STAR_AMOUNT, str(battle_id), int(time.time())),
        )
        return True
