"""Transactional reward application for the Nost V13/SQLite data layout."""

import copy

from Database.DatabaseManager import DataBase
from Files.CsvLogic.Cards import Cards
from Files.CsvLogic.Characters import Characters
from Files.CsvLogic.Skins import Skins


MAX_POWER_POINTS = DataBase.MAX_POWER_POINTS


class RewardError(ValueError):
    """A purchase or reward cannot be applied without changing the account."""


class RewardTransaction:
    """Build one atomic SQLite update and apply it to memory only on success."""

    def __init__(self, player):
        self.player = player
        self.updates = {}
        self._values = {}
        self.reward_details = []
        progression = getattr(player, "progression", {})
        self.progression = copy.deepcopy(progression) if isinstance(progression, dict) else {}
        self.progression.setdefault(
            "starPoints", int(getattr(player, "star_points", 0) or 0)
        )

    def _value(self, attribute, default=0):
        if attribute in self._values:
            return self._values[attribute]
        return getattr(self.player, attribute, default)

    def _mapping(self, attribute, column):
        if attribute not in self._values:
            value = getattr(self.player, attribute, {})
            self._values[attribute] = copy.deepcopy(value) if isinstance(value, dict) else {}
            self.updates[column] = self._values[attribute]
        return self._values[attribute]

    def generation_player(self):
        player = copy.copy(self.player)
        for attribute, value in self._values.items():
            setattr(player, attribute, copy.deepcopy(value))
        return player

    def set_value(self, attribute, column, value):
        self._values[attribute] = value
        self.updates[column] = value

    def set_progression_value(self, key, value):
        self.progression[key] = value
        self._values["progression"] = self.progression
        self.updates["progression"] = self.progression

    def charge(self, currency, amount):
        try:
            amount = int(amount)
        except (TypeError, ValueError):
            raise RewardError("Preço inválido") from None
        if amount < 0:
            raise RewardError("Preço inválido")

        currencies = {
            "gems": ("gems", "gems"),
            "gold": ("gold", "gold"),
            "brawlBoxes": ("brawl_boxes", "brawlBoxes"),
            "bigBoxes": ("big_boxes", "bigBoxes"),
        }
        if currency in {"starpoints", "starPoints"}:
            balance = int(self._value("star_points", 0) or 0)
            if balance < amount:
                raise RewardError("Star points insuficientes")
            balance -= amount
                                                                         
            self._values["star_points"] = balance
            self.set_progression_value("starPoints", balance)
            return

        if currency not in currencies:
            raise RewardError(f"Moeda não suportada: {currency}")
        attribute, column = currencies[currency]
        balance = int(self._value(attribute, 0) or 0)
        if balance < amount:
            raise RewardError("Saldo insuficiente")
        self.set_value(attribute, column, balance - amount)

    @staticmethod
    def _brawler_id(value):
        try:
            value = int(value)
        except (TypeError, ValueError):
            raise RewardError("Brawler inválido") from None
        if value not in Characters.get_brawlers_id():
            raise RewardError("Brawler inválido")
        return value

    def _is_unlocked(self, brawler_id):
        states = self._values.get(
            "BrawlersUnlockedState",
            getattr(self.player, "BrawlersUnlockedState", {}),
        )
        return states.get(str(brawler_id), states.get(brawler_id, 0)) == 1

    def _unlock_brawler(self, brawler_id):
        states = self._mapping("BrawlersUnlockedState", "UnlockedBrawlers")
        key = str(brawler_id)
        if states.get(key) == 1:
            return
        states[key] = 1
        defaults = (
            ("brawlers_trophies", "brawlersTrophies", 0),
            ("brawlers_trophies_in_rank", "brawlersTrophiesForRank", 0),
            ("brawlers_upgradium", "brawlersUpgradePoints", 0),
            ("Brawler_level", "brawlerPowerLevel", 0),
            ("Brawler_starPower", "brawlerStarPower", 0),
            ("brawlers_skins", "brawlersSkins", 0),
        )
        for attribute, column, default in defaults:
            mapping = self._mapping(attribute, column)
            mapping.setdefault(key, default)
        levels = self._mapping("Brawler_level", "brawlerPowerLevel")
        if int(levels.get(key, 0) or 0) < 0:
            levels[key] = 0
        tags = self.progression.setdefault("brawlerNewTag", {})
        tags[key] = 1
        self.set_progression_value("brawlerNewTag", tags)

    def add_reward(self, name, amount, target=0, exact=False):
        aliases = {
            "Golds": "Coins",
            "gold": "Coins",
            "coins": "Coins",
            "Coins": "Coins",
            "gems": "gems",
            "Gems": "gems",
            "tickets": "tickets",
            "Tickets": "tickets",
            "TokensDoubler": "tokens_doubler",
            "tokenDoublers": "tokens_doubler",
            "tokensdoubler": "tokens_doubler",
            "tokens_doubler": "tokens_doubler",
            "UpgradePoints": "UpgradePoints",
            "Brawler": "Brawler",
            "Skin": "Skin",
            "StarPower": "StarPower",
        }
        if name not in aliases:
            raise RewardError(f"Recompensa não suportada: {name}")
        name = aliases[name]
        try:
            amount = int(amount)
            target = int(target or 0)
        except (TypeError, ValueError):
            raise RewardError("Recompensa inválida") from None
        if amount < 0:
            raise RewardError("Recompensa inválida")

        if name == "Coins":
            self.set_value("gold", "gold", int(self._value("gold", 0)) + amount)
        elif name == "gems":
            self.set_value("gems", "gems", int(self._value("gems", 0)) + amount)
        elif name == "tickets":
            self.set_value("tickets", "tickets", int(self._value("tickets", 0)) + amount)
        elif name == "tokens_doubler":
            self.set_value(
                "tokensdoubler", "tokensdoubler",
                int(self._value("tokensdoubler", 0)) + amount,
            )
        elif name == "UpgradePoints":
            target = self._brawler_id(target)
            if not self._is_unlocked(target):
                raise RewardError("Power points exigem um brawler desbloqueado")
            points = self._mapping("brawlers_upgradium", "brawlersUpgradePoints")
            key = str(target)
            current = max(0, int(points.get(key, 0) or 0))
            remaining = max(0, MAX_POWER_POINTS - current)
            if exact and amount > remaining:
                raise RewardError("O brawler não possui capacidade para todos os power points")
            amount = min(amount, remaining)
            points[key] = current + amount
        elif name == "Brawler":
            amount = self._brawler_id(amount)
            self._unlock_brawler(amount)
        elif name == "StarPower":
            target = self._brawler_id(target)
            if not self._is_unlocked(target):
                raise RewardError("Star power exige um brawler desbloqueado")
            if amount == 0 or Cards.get_brawler_star_power(target) != amount:
                raise RewardError("Star power inválido")
            powers = self._mapping("Brawler_starPower", "brawlerStarPower")
            powers[str(target)] = amount
        elif name == "Skin":
            if amount not in Skins.get_skins_id():
                raise RewardError("Skin inválida")
            target = Skins.getBrawler(amount)
            if not self._is_unlocked(target):
                raise RewardError("A skin exige um brawler desbloqueado")
            skins = self._mapping("UnlockedSkins", "UnlockedSkins")
            owned = skins.setdefault("Skins", [])
            if amount in owned:
                raise RewardError("Skin já desbloqueada")
            owned.append(amount)
        else:                                                   
            raise RewardError(f"Recompensa não suportada: {name}")

        self.reward_details.append({"name": name, "amount": amount, "target": target})
        return amount

    def add_rewards(self, rewards):
        for reward in rewards:
            if isinstance(reward, dict):
                self.add_reward(
                    reward["name"],
                    reward["amount"],
                    reward.get("target", 0),
                    exact=reward.get("exact", False),
                )
            else:
                name, amount, target = reward
                self.add_reward(name, amount, target)

    def commit(self, connection=None):
        for attribute in (
            "gems", "gold", "tickets", "brawl_boxes", "big_boxes",
            "tokensdoubler", "battle_tokens", "star_points",
        ):
            if attribute in self._values and int(self._values[attribute]) < 0:
                raise RewardError(f"Saldo negativo em {attribute}")

        if connection is None:
            if not DataBase.replaceValues(self, self.updates):
                raise RewardError("Conta não encontrada no SQLite")
            self.finalize()
        elif not DataBase._write_values(
            connection, int(getattr(self.player, "low_id", 0) or 0), self.updates
        ):
            raise RewardError("Conta não encontrada no SQLite")
        return self

    def finalize(self, player=None):
        player = self.player if player is None else player
        for attribute, value in self._values.items():
            setattr(player, attribute, value)
        if "progression" in self.updates:
            player.progression = self.progression
            player.tokensAnim = int(self.progression.get("keyReward", 0) or 0)
            player.trophiesAnim = int(self.progression.get("trophyReward", 0) or 0)
            player.bigTokensAnim = int(self.progression.get("starKeyReward", 0) or 0)
        return self

    def result(self, box_id=100, box_type=None, trophy_road=0):
        return {
            "boxID": box_id,
            "boxType": box_id if box_type is None else box_type,
            "rewards": [reward["amount"] for reward in self.reward_details],
            "rewardNames": [reward["name"] for reward in self.reward_details],
            "rewardsTargetBrawler": [reward["target"] for reward in self.reward_details],
            "rewardDetails": copy.deepcopy(self.reward_details),
            "trophyRoad": trophy_road,
        }
