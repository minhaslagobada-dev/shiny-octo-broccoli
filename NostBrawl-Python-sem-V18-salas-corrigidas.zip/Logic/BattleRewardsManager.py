"""Transactional Pro battle rewards in the Nost V13/SQLite data layout."""

import copy
import json
import time

from Database.DatabaseManager import DataBase
from Logic.DailyRewards import DailyRewards
from Logic.EventRotation import EventRotation
from Logic.Milestones import Milestones
from Logic.Rewards import RewardError, RewardTransaction


class BattleRewardsManager:
    SPECIAL_MODES = frozenset({3, 4, 6})

    def __init__(self, player, db=None):
        self.player = player
        self.db = db
        self.milestones = Milestones()

    @staticmethod
    def get_trophy_modifiers(trophies):
        ranges = [
            (0, 29, (0, 0, 6)), (30, 59, (-1, 0, 6)),
            (60, 99, (-2, 0, 6)), (100, 139, (-2, 0, 5)),
            (140, 219, (-3, 0, 5)), (220, 299, (-4, 0, 5)),
            (300, 499, (-5, 0, 5)), (500, 599, (-6, 0, 5)),
            (600, 699, (-7, 0, 4)), (700, 799, (-7, 0, 3)),
            (800, 899, (-8, 0, 3)), (900, float("inf"), (-9, 0, 2)),
        ]
        for low, high, modifiers in ranges:
            if low <= trophies <= high:
                return modifiers
        return (0, 0, 0)

    @staticmethod
    def get_solo_trophy_modifiers(trophies):
        ranges = [
            (0, 29, [8, 7, 6, 5, 5, 4, 3, 2, 1, 0]),
            (30, 59, [8, 7, 6, 4, 3, 2, 0, -1, -2, -4]),
            (60, 99, [8, 7, 5, 4, 3, 1, 0, -2, -3, -4]),
            (100, 139, [7, 6, 5, 3, 2, 1, -1, -2, -3, -4]),
            (140, 219, [7, 6, 4, 3, 2, 0, -1, -3, -4, -5]),
            (220, 299, [7, 6, 4, 3, 1, 0, -2, -3, -4, -5]),
            (300, 499, [7, 6, 4, 2, 1, -1, -2, -4, -6, -7]),
            (500, 599, [6, 5, 3, 2, 0, -2, -3, -4, -6, -7]),
            (600, 699, [5, 4, 3, 1, -1, -2, -3, -4, -6, -7]),
            (700, float("inf"), [5, 3, 2, 1, -1, -2, -4, -5, -6, -7]),
        ]
        for low, high, values in ranges:
            if low <= trophies <= high:
                return values
        return [0] * 10

    @staticmethod
    def get_duo_trophy_modifiers(trophies):
        ranges = [
            (0, 29, [7, 5, 4, 2, 0]), (30, 59, [7, 5, 2, -1, -3]),
            (60, 99, [7, 4, 2, -1, -4]), (100, 139, [6, 4, 1, -1, -4]),
            (140, 219, [6, 4, 1, -2, -5]), (220, 499, [6, 3, 0, -3, -6]),
            (500, 599, [6, 3, 0, -4, -6]), (600, 699, [4, 2, -1, -4, -6]),
            (700, 799, [3, 1, -1, -4, -6]), (800, 899, [3, 1, -2, -5, -7]),
            (900, float("inf"), [2, 0, -3, -5, -7]),
        ]
        for low, high, values in ranges:
            if low <= trophies <= high:
                return values
        return [0] * 5

    @staticmethod
    def _brawler_from_fields(player, fields):
        try:
            return int(fields["Heroes"][0]["Brawler"]["ID"][1])
        except (KeyError, IndexError, TypeError, ValueError):
            return int(getattr(player, "brawler_id", 0))

    @staticmethod
    def _normalize_result(result):
        normalized = copy.deepcopy(result)
        experience = normalized.get("exp_rewards_array", {})
        normalized["exp_rewards_array"] = {
            int(key): int(value) for key, value in experience.items()
        }
        return normalized

    @staticmethod
    def _sync_replayed_state(source, target):
        for attribute in (
            "brawlers_trophies", "brawlers_trophies_in_rank", "trophies",
            "highest_trophies", "player_experience", "tokensdoubler",
            "battle_tokens", "brawl_boxes", "big_boxes", "solo_wins",
            "duo_wins", "ThreeVSThree_wins", "progression", "star_points",
            "tokensAnim", "trophiesAnim", "bigTokensAnim",
        ):
            if hasattr(source, attribute):
                setattr(target, attribute, copy.deepcopy(getattr(source, attribute)))

    def process_rewards(self, fields, battle_id=None, now=None):
        if not battle_id:
            return self._apply_rewards(fields)
        low_id = int(getattr(self.player, "low_id", 0) or 0)
        if low_id <= 0 or not getattr(self.player, "token", ""):
            raise RewardError("Conta não autenticada para recompensa persistente")
        game_mode = int(fields.get("GameMode", 0))
        transaction = None
        replayed = False

        with DataBase._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                "SELECT rewards_json, game_mode FROM battle_reward_ledger "
                "WHERE player_id = ? AND battle_id = ?",
                (low_id, str(battle_id)),
            ).fetchone()
            canonical = copy.copy(self.player)
            if not DataBase._load_account_from_connection(connection, canonical):
                raise RewardError("Conta não encontrada no SQLite")

            if row is not None and row[0] is not None:
                if int(row[1]) != game_mode:
                    raise RewardError("Modo divergente no ledger da partida")
                try:
                    stored = json.loads(row[0])
                except (TypeError, ValueError) as error:
                    raise RewardError("Resultado persistido da partida inválido") from error
                if not isinstance(stored, dict):
                    raise RewardError("Resultado persistido da partida inválido")
                result = self._normalize_result(stored)
                replayed = True
            else:
                if row is None:
                    timestamp = int(time.time())
                    connection.execute(
                        "INSERT INTO battle_reward_ledger ("
                        "player_id, battle_id, game_mode, created_at, updated_at"
                        ") VALUES (?, ?, ?, ?, ?)",
                        (low_id, str(battle_id), game_mode, timestamp, timestamp),
                    )
                elif int(row[1]) not in (-1, game_mode):
                    raise RewardError("Modo divergente no ledger da partida")

                manager = BattleRewardsManager(canonical, db=self.db)
                result = manager._apply_rewards(fields, battle_id, connection, now)
                transaction = manager._pending_transaction
                timestamp = int(time.time())
                cursor = connection.execute(
                    "UPDATE battle_reward_ledger SET rewards_json = ?, "
                    "game_mode = ?, updated_at = ?, completed_at = ? "
                    "WHERE player_id = ? AND battle_id = ?",
                    (
                        json.dumps(result, sort_keys=True, separators=(",", ":")),
                        game_mode, timestamp, timestamp, low_id, str(battle_id),
                    ),
                )
                if cursor.rowcount != 1:
                    raise RewardError("Falha ao concluir o ledger da partida")

        if replayed:
            self._sync_replayed_state(canonical, self.player)
            result["_replayed"] = True
        elif transaction is not None:
            transaction.finalize(self.player)
        return result

    def _apply_rewards(self, fields, battle_id=None, connection=None, now=None):
        self._pending_transaction = None
        player = self.player
        game_mode = int(fields.get("GameMode", 0))
        rank = int(fields.get("Rank", getattr(player, "rank", 1)) or 0)
        victory = int(fields.get("Victory", getattr(player, "battle_result", 0)) or 0)
        base_result = int(fields.get("result", getattr(player, "result", 16)) or 0)
        brawler = self._brawler_from_fields(player, fields)
        key = str(brawler)
        tutorial = int(getattr(player, "tutorial", getattr(player, "tutorialState", 2)))
        is_tutorial_complete = tutorial == 2
        special = game_mode in self.SPECIAL_MODES

        trophies = getattr(player, "brawlers_trophies", {})
        highest = getattr(player, "brawlers_trophies_in_rank", {})
        old_trophies = int(trophies.get(key, 0) or 0)
        old_highest = int(highest.get(key, 0) or 0)
        old_experience = int(getattr(player, "player_experience", 0) or 0)
        old_battle_tokens = max(0, int(getattr(player, "battle_tokens", 0) or 0))

        has_star_key = False
        if game_mode == 2:
            if not 1 <= rank <= 10:
                raise RewardError("Rank solo inválido")
            rank_trophies = self.get_solo_trophy_modifiers(old_trophies)
            reward_index = rank - 1
            exp_rewards = [0, 1, 2, 3, 4, 5, 6, 9, 12, 15]
            token_rewards = [0, 2, 4, 6, 8, 12, 16, 22, 28, 34]
            has_star_key = rank <= 4
        elif game_mode == 5:
            if not 1 <= rank <= 5:
                raise RewardError("Rank duo inválido")
            rank_trophies = self.get_duo_trophy_modifiers(old_trophies)
            reward_index = rank - 1
            exp_rewards = [0, 2, 4, 8, 14]
            token_rewards = [0, 4, 8, 20, 32]
            has_star_key = rank <= 2
        elif special:
            if victory not in (0, 1, 2):
                raise RewardError("Resultado de evento inválido")
            rank_trophies = [0, 0, 0]
            reward_index = victory - 1
            exp_rewards = [0, 0, 0]
            token_rewards = [0, 0, 0]
            has_star_key = True
        else:
            if victory not in (0, 1, 2):
                raise RewardError("Resultado 3v3 inválido")
            rank_trophies = self.get_trophy_modifiers(old_trophies)
            reward_index = victory - 1
            exp_rewards = [4, 6, 8]
            token_rewards = [10, 15, 20]
            has_star_key = victory == 0

        trophies_gain = rank_trophies[reward_index] if is_tutorial_complete else 0
        experience = exp_rewards[reward_index] if is_tutorial_complete else 0
        requested_tokens = token_rewards[reward_index] if is_tutorial_complete else 0

        try:
            is_player = bool(fields["Heroes"][0]["IsPlayer"])
        except (KeyError, IndexError, TypeError):
            is_player = True
        if is_player:
            if special:
                star_player_exp = 0
            else:
                experience += 10 if is_tutorial_complete else 0
                star_player_exp = 10 if is_tutorial_complete else 0
            exp_rewards_array = {0: experience, 8: star_player_exp}
        else:
            star_player_exp = 0
            exp_rewards_array = {0: experience}

        doubler = max(0, int(getattr(player, "tokensdoubler", 0) or 0))
        daily = None
        if connection is not None:
            low_id = int(getattr(player, "low_id", 0) or 0)
            moment = DailyRewards._moment(now)
            daily = DailyRewards.consume(
                connection, low_id, requested_tokens, doubler, moment
            )
            old_battle_tokens = daily["old_battle_tokens"]
            tokens_gain = daily["tokens_gain"]
            doubled_tokens = daily["doubled_tokens"]
            total_tokens = daily["total_tokens"]
            remaining_tokens = daily["remaining_doubler"]
            remaining_battle_tokens = daily["battle_tokens"]
            event = EventRotation.battle_event(
                fields.get("MapID", getattr(player, "map_id", 0)),
                fields.get("MapSlot", getattr(player, "locationID", 0)),
                moment,
            )
            has_star_key = DailyRewards.claim_star(
                connection,
                low_id,
                fields.get("MapID", getattr(player, "map_id", 0)),
                battle_id,
                has_star_key and is_tutorial_complete and event is not None,
                moment,
            )
        else:
            tokens_gain = min(requested_tokens, old_battle_tokens)
            doubled_tokens = min(tokens_gain, doubler)
            remaining_tokens = doubler - doubled_tokens
            total_tokens = tokens_gain + doubled_tokens
            remaining_battle_tokens = old_battle_tokens - tokens_gain
            has_star_key = False

        result_type = base_result
        if has_star_key and (base_result != 0 or special):
            result_type += 1
        if old_battle_tokens <= 0:
            result_type += 4
        if old_experience >= int(getattr(player, "max_experience", 145630)):
            result_type += 2
        if game_mode in (0, 1):
            if victory in (0, 2):
                starplayer = 1 if 0 <= result_type <= 15 else 5
            else:
                starplayer = 1
        else:
            starplayer = 1

        result = {
            "tokens_gain": tokens_gain,
            "requested_tokens": requested_tokens,
            "trophies_gain": trophies_gain,
            "doubled_tokens": doubled_tokens,
            "remaining_tokens": remaining_tokens,
            "total_tokens": total_tokens,
            "exp_rewards_array": exp_rewards_array,
            "brawler_trophies": old_trophies,
            "brawler_trophies_for_rank": old_highest,
            "experience": experience,
            "star_player_exp": star_player_exp,
            "hasStarKey": has_star_key,
            "brawler_id": brawler,
            "milestonesRewardRank": 0,
            "result": result_type,
            "starplayer": starplayer,
            "old_experience": old_experience,
            "old_battle_tokens": old_battle_tokens,
            "battle_tokens": remaining_battle_tokens,
        }
        if daily is not None:
            result["daily_token_day"] = daily["day"]
            result["daily_tokens_used"] = daily["used"]
            result["daily_tokens_remaining"] = daily["remaining"]
        if not is_tutorial_complete:
            return result

        new_brawler_trophies = max(0, old_trophies + trophies_gain)
        trophies_gain = new_brawler_trophies - old_trophies
        result["trophies_gain"] = trophies_gain
        new_total_trophies = max(
            0, int(getattr(player, "trophies", 0) or 0) + trophies_gain
        )
        new_highest = max(old_highest, new_brawler_trophies)
        for milestone in self.milestones.rankTrophies:
            if old_trophies < milestone <= new_brawler_trophies:
                result["milestonesRewardRank"] = 10

        transaction = RewardTransaction(player)
        new_trophies = copy.deepcopy(trophies)
        new_trophies[key] = new_brawler_trophies
        transaction.set_value("brawlers_trophies", "brawlersTrophies", new_trophies)
        new_rank = copy.deepcopy(highest)
        new_rank[key] = new_highest
        transaction.set_value(
            "brawlers_trophies_in_rank", "brawlersTrophiesForRank", new_rank
        )
        transaction.set_value("trophies", "trophies", new_total_trophies)
        transaction.set_value(
            "highest_trophies", "highest_trophies",
            max(int(getattr(player, "highest_trophies", 0) or 0), new_total_trophies),
        )
        transaction.set_value(
            "player_experience", "playerExp", old_experience + experience + star_player_exp,
        )
        transaction.set_value("tokensdoubler", "tokensdoubler", remaining_tokens)
        transaction.set_value("battle_tokens", "battleTokens", remaining_battle_tokens)
        transaction.set_value(
            "brawl_boxes", "brawlBoxes",
            int(getattr(player, "brawl_boxes", 0) or 0) + total_tokens,
        )
        transaction.set_value(
            "big_boxes", "bigBoxes",
            int(getattr(player, "big_boxes", 0) or 0) + (1 if has_star_key else 0),
        )
        if not special:
            if game_mode == 2 and rank == 1:
                transaction.set_value(
                    "solo_wins", "soloWins", int(getattr(player, "solo_wins", 0) or 0) + 1
                )
            elif game_mode == 5 and rank == 1:
                transaction.set_value(
                    "duo_wins", "duoWins", int(getattr(player, "duo_wins", 0) or 0) + 1
                )
            elif game_mode in (0, 1) and victory == 0:
                transaction.set_value(
                    "ThreeVSThree_wins", "TvsTWins",
                    int(getattr(player, "ThreeVSThree_wins", 0) or 0) + 1,
                )
        transaction.set_progression_value("keyReward", total_tokens)
        transaction.set_progression_value("trophyReward", trophies_gain)
        transaction.set_progression_value("starKeyReward", 1 if has_star_key else 0)
        transaction.commit(connection)
        if connection is not None:
            self._pending_transaction = transaction
        return result
