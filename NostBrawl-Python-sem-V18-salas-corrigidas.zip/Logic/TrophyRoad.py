import csv
import random

from Files.CsvLogic.Characters import Characters
from Logic.BoxService import apply_box_opening
from Logic.Rewards import RewardError, RewardTransaction


REWARD_TYPES = {
    1: "coins",
    3: "brawler",
    6: "box",
    7: "tickets",
    9: "tokenDoublers",
    10: "box",
    12: "powerPoints",
    13: "event",
    14: "box",
}
BOX_TYPES = {6: 10, 10: 11, 14: 12}


def _load_rewards():
    rewards = []
    values = []
    with open(
        "GameAssets/csv_logic/milestones.csv", "r", encoding="utf-8-sig", newline=""
    ) as csv_file:
        for row in csv.DictReader(csv_file):
            if row.get("Type") != "6":
                continue
            try:
                primary_type = int(row["PrimaryLvlUpRewardType"])
                reward_type = REWARD_TYPES[primary_type]
                if reward_type == "brawler":
                    value = Characters.get_brawler_id_by_name(
                        row["PrimaryLvlUpRewardHero"]
                    )
                elif reward_type == "box":
                    value = BOX_TYPES[primary_type]
                elif reward_type == "event":
                    value = int(row["PrimaryLvlUpRewardExtraData"] or 0)
                else:
                    value = int(row["PrimaryLvlUpRewardCount"] or 0)
            except (KeyError, TypeError, ValueError) as error:
                raise ValueError(
                    f"Milestone inválido: {row.get('Name', '?')}"
                ) from error
            rewards.append(reward_type)
            values.append(value)
    if not rewards:
        raise ValueError("Nenhum milestone da Trophy Road foi encontrado")
    return rewards, values


REWARDS, REWARD_VALUES = _load_rewards()


def _is_unlocked(player, brawler):
    states = getattr(player, "BrawlersUnlockedState", {})
    if not isinstance(states, dict):
        return False
    return states.get(str(brawler), states.get(brawler, 0)) == 1


def claim(player, brawler_target=0, rng=None):
    try:
        position = int(getattr(player, "trophy_road", 0) or 0)
    except (TypeError, ValueError):
        raise RewardError("Posição da Trophy Road inválida") from None
    if position < 1 or position > len(REWARDS):
        raise RewardError("Trophy Road concluída ou posição inválida")

    rng = rng or random
    reward_type = REWARDS[position - 1]
    value = REWARD_VALUES[position - 1]
    transaction = RewardTransaction(player)
    box_id = 100
    box_type = 100

    if reward_type == "box":
        box_type = apply_box_opening(transaction, value, rng)
        box_id = box_type
    elif reward_type == "event":
        progression = getattr(player, "progression", {})
        unlocked = int(progression.get("unlockedEvents", 0) or 0)
        transaction.set_progression_value("unlockedEvents", unlocked + 1)
    elif reward_type == "brawler":
        if _is_unlocked(player, value):
            reward_type = "box"
            box_type = apply_box_opening(transaction, 10, rng)
            box_id = box_type
        else:
            transaction.add_reward("Brawler", value)
    elif reward_type == "tokenDoublers":
        transaction.add_reward("tokens_doubler", value)
    elif reward_type == "powerPoints":
        transaction.add_reward("UpgradePoints", value, brawler_target, exact=True)
    elif reward_type == "coins":
        transaction.add_reward("Coins", value)
    elif reward_type == "tickets":
        transaction.add_reward("tickets", value)
    else:
        raise RewardError(f"Recompensa da Trophy Road inválida: {reward_type}")

    next_position = position + 1
    transaction.set_value("trophy_road", "leagueReward", next_position)
    transaction.commit()
    result = transaction.result(box_id, box_type, next_position)
    result["rewardType"] = reward_type
    result["claimedPosition"] = position
    return result
