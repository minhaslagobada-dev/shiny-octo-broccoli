import copy
import csv
from datetime import datetime, time, timedelta
from pathlib import Path

from Database.DatabaseManager import DataBase
from Utils.Config import Config


class EventError(ValueError):
    pass


class EventRotation:
    SLOT_POOLS = (
        ("CoinRush", (7, 8, 9, 10, 11, 12, 40, 48)),
        ("BattleRoyale", (13, 14, 15, 16, 32, 43)),
        ("BountyHunter", (0, 4, 22)),
        ("LaserBall", (24, 25, 26, 50, 51)),
        ("BattleRoyaleTeam", (34, 35, 36, 37, 38, 28)),
    )
    CLAIMS_KEY = "eventClaims"
    STATES_KEY = "eventStates"
    CLAIM_HISTORY_DAYS = 64
    TOKEN_WALLET_CAP = 999900
    PROJECT_ROOT = Path(__file__).resolve().parents[1]
    LOCATIONS_PATH = PROJECT_ROOT / "GameAssets" / "csv_logic" / "locations.csv"

    @staticmethod
    def _now(value=None):
        return value if value is not None else datetime.now()

    @staticmethod
    def _location_rows():
        with EventRotation.LOCATIONS_PATH.open(
            encoding="utf-8-sig", newline=""
        ) as source:
            rows = list(csv.DictReader(source))
        if rows and rows[0].get("Name") == "string":
            rows = rows[1:]
        return rows

    @classmethod
    def locations(cls):
        rows = cls._location_rows()
        result = []
        for location_id, row in enumerate(rows):
            disabled = str(row.get("Disabled", "")).strip().lower()
            result.append({
                "id": location_id,
                "name": row.get("Name", ""),
                "game_mode": row.get("GameMode", ""),
                "enabled": disabled not in {"1", "true", "yes"},
            })
        return result

    @classmethod
    def enabled_pools(cls):
        locations = cls.locations()
        pools = []
        for game_mode, candidates in cls.SLOT_POOLS:
            enabled = tuple(
                location_id for location_id in candidates
                if location_id < len(locations)
                and locations[location_id]["enabled"]
                and locations[location_id]["game_mode"] == game_mode
            )
            if not enabled:
                raise EventError("Slot sem mapa habilitado: " + game_mode)
            pools.append((game_mode, enabled))
        return tuple(pools)

    @classmethod
    def enabled_modifiers(cls):
        configured = Config.GetValue().get("MapModifiers", {})
        if not isinstance(configured, dict):
            raise EventError("MapModifiers deve ser um objeto de booleanos")
        result = []
        for modifier in range(1, 6):
            enabled = configured.get(str(modifier), configured.get(modifier, False))
            if not isinstance(enabled, bool):
                raise EventError(
                    "MapModifiers.%s deve ser true ou false" % modifier
                )
            if enabled:
                result.append(modifier)
        return tuple(result)

    @classmethod
    def events(cls, now=None):
        moment = cls._now(now)
        day = moment.date().toordinal()
        modifiers = cls.enabled_modifiers()
        result = []
        for slot, (game_mode, pool) in enumerate(cls.enabled_pools(), 1):
            map_id = pool[(day + slot - 1) % len(pool)]
            result.append({
                "slot": slot,
                "map_id": map_id,
                "game_mode": game_mode,
                "tokens": 10,
                "modifier": modifiers[0] if modifiers else 0,
                "modifiers": modifiers,
                "date": moment.date().isoformat(),
            })
        return result

    @classmethod
    def battle_event(cls, map_id, map_slot=0, now=None):
        try:
            map_id = int(map_id)
            map_slot = int(map_slot)
        except (TypeError, ValueError):
            return None
        if isinstance(now, (int, float)):
            moment = datetime.fromtimestamp(now)
        else:
            moment = cls._now(now)
        locations = cls.locations()
        if not 0 <= map_id < len(locations) or not locations[map_id]["enabled"]:
            return None
        if map_slot == 0:
            return {
                "slot": 0,
                "map_id": map_id,
                "game_mode": locations[map_id]["game_mode"],
                "date": moment.date().isoformat(),
            }
        if not 1 <= map_slot <= len(cls.SLOT_POOLS):
            return None
        event = cls.events(moment)[map_slot - 1]
        if event["map_id"] != map_id:
            return None
        return event

    @classmethod
    def claimed_slots(cls, player, now=None):
        moment = cls._now(now)
        progression = getattr(player, "progression", {})
        if not isinstance(progression, dict):
            return set()
        claims = progression.get(cls.CLAIMS_KEY, {})
        if not isinstance(claims, dict):
            return set()
        values = claims.get(moment.date().isoformat(), [])
        if not isinstance(values, (list, tuple, set)):
            return set()
        result = set()
        for value in values:
            try:
                result.add(int(value))
            except (TypeError, ValueError):
                continue
        return result

    @classmethod
    def _stored_state(cls, progression, event):
        if not isinstance(progression, dict):
            return 1
        states = progression.get(cls.STATES_KEY, {})
        if not isinstance(states, dict):
            return 1
        daily = states.get(event["date"], {})
        if not isinstance(daily, dict):
            return 1
        record = daily.get(str(event["slot"]))
        if not isinstance(record, dict):
            return 1
        if (
            record.get("mapID") != event["map_id"]
            or record.get("gameMode") != event["game_mode"]
            or record.get("modifier") != event["modifier"]
            or record.get("modifiers") != list(event["modifiers"])
            or record.get("tokens") != event["tokens"]
        ):
            return 1
        try:
            state = int(record["state"])
        except (KeyError, TypeError, ValueError):
            return 1
        return state if state in (1, 2, 3) else 1

    @classmethod
    def _store_state(cls, progression, event, state, moment):
        states = progression.get(cls.STATES_KEY, {})
        states = copy.deepcopy(states) if isinstance(states, dict) else {}
        cutoff = moment.date() - timedelta(days=cls.CLAIM_HISTORY_DAYS)
        states = {
            key: value for key, value in states.items()
            if cls._claim_date_after_cutoff(key, cutoff)
        }
        daily = states.get(event["date"], {})
        daily = copy.deepcopy(daily) if isinstance(daily, dict) else {}
        daily[str(event["slot"])] = {
            "state": int(state),
            "mapID": event["map_id"],
            "gameMode": event["game_mode"],
            "modifier": event["modifier"],
            "modifiers": list(event["modifiers"]),
            "tokens": event["tokens"],
        }
        states[event["date"]] = daily
        progression[cls.STATES_KEY] = states

    @classmethod
    def snapshot(cls, player, now=None):
        moment = cls._now(now)
        claimed = cls.claimed_slots(player, moment)
        progression = getattr(player, "progression", {})
        result = []
        for event in cls.events(moment):
            item = copy.deepcopy(event)
            item["claimed"] = item["slot"] in claimed
            item["status"] = cls._stored_state(progression, item)
            result.append(item)
        return result

    @classmethod
    def resolve_slot(cls, player, slot, now=None):
        try:
            slot = int(slot)
        except (TypeError, ValueError):
            raise EventError("Slot de evento inválido") from None
        events = cls.snapshot(player, now)
        if slot == 0:
            return copy.deepcopy(events[0])
        for event in events:
            if event["slot"] == slot:
                return event
        raise EventError("Slot de evento inexistente")

    @classmethod
    def seconds_to_next_day(cls, now=None):
        moment = cls._now(now)
        following = datetime.combine(moment.date() + timedelta(days=1), time.min)
        return max(0, int((following - moment).total_seconds()))

    @classmethod
    def legacy_events(cls, player=None, now=None):
        events = cls.snapshot(player, now) if player is not None else cls.events(now)
        result = {}
        for event in events:
            collected = []
            if event.get("claimed") and player is not None:
                collected = [getattr(player, "low_id", 0)]
            result[str(event["slot"] - 1)] = {
                "ID": event["map_id"],
                "Modifier": event["modifier"],
                "Tokens": event["tokens"],
                "Collected": collected,
            }
        return result

    @classmethod
    def _claim_locked(cls, connection, low_id, event, moment, progression, balance):
        date_key = moment.date().isoformat()
        cutoff = moment.date() - timedelta(days=cls.CLAIM_HISTORY_DAYS)
        claims = progression.get(cls.CLAIMS_KEY, {})
        if not isinstance(claims, dict):
            claims = {}
        claims = {
            key: value for key, value in claims.items()
            if cls._claim_date_after_cutoff(key, cutoff)
        }
        current = claims.get(date_key, [])
        if not isinstance(current, list):
            current = []
        current = {int(value) for value in current if str(value).lstrip("-").isdigit()}
        progression[cls.CLAIMS_KEY] = claims
        if event["slot"] in current:
            return False, balance, 0
        current.add(event["slot"])
        claims[date_key] = sorted(current)
        granted = min(max(0, int(event["tokens"])), max(0, cls.TOKEN_WALLET_CAP - balance))
        balance += granted
        cursor = connection.execute(
            "UPDATE players SET brawlBoxes = ? WHERE lowID = ?",
            (balance, low_id),
        )
        if cursor.rowcount != 1:
            raise EventError("Falha ao persistir a coleta")
        return True, balance, granted

    @classmethod
    def _persist(cls, player, slot, now, state):
        moment = cls._now(now)
        event = cls.resolve_slot(player, slot, moment)
        if state is not None and state not in (1, 2, 3):
            raise EventError("Estado de evento inválido")
        low_id = int(getattr(player, "low_id", 0) or 0)
        if low_id <= 0:
            raise EventError("Conta inválida para atualizar o evento")
        with DataBase._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                "SELECT brawlBoxes FROM players WHERE lowID = ?", (low_id,)
            ).fetchone()
            if row is None:
                raise EventError("Conta não encontrada para atualizar o evento")
            progression = DataBase._read_state(connection, low_id, "progression")
            if not isinstance(progression, dict):
                progression = {}
            else:
                progression = copy.deepcopy(progression)
            if state is not None:
                cls._store_state(progression, event, state, moment)
            claimed = False
            granted = 0
            balance = int(row[0] or 0)
            if state is None or state == 2:
                claimed, balance, granted = cls._claim_locked(
                    connection, low_id, event, moment, progression, balance
                )
            DataBase._write_state(connection, low_id, "progression", progression)
        player.brawl_boxes = balance
        player.progression = progression
        event["claimed"] = event["slot"] in cls.claimed_slots(player, moment)
        event["status"] = cls._stored_state(progression, event)
        result = {
            "claimed": claimed,
            "event": event,
            "balance": balance,
            "granted": granted,
        }
        if state is not None:
            result["state"] = state
        return result

    @classmethod
    def claim(cls, player, slot, now=None):
        return cls._persist(player, slot, now, None)

    @classmethod
    def apply_state(cls, player, slot, state, now=None):
        try:
            slot = int(slot)
            state = int(state)
        except (TypeError, ValueError):
            raise EventError("Slot ou estado de evento inválido") from None
        if slot < 1:
            raise EventError("Slot de evento inexistente")
        return cls._persist(player, slot, now, state)

    @staticmethod
    def _claim_date_after_cutoff(value, cutoff):
        try:
            return datetime.strptime(str(value), "%Y-%m-%d").date() >= cutoff
        except ValueError:
            return False
