import os
import socket
import sys
import tempfile
import time
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

PROJECT_ROOT = Path(__file__).resolve().parents[1]
os.chdir(PROJECT_ROOT)
sys.path.insert(0, str(PROJECT_ROOT))

from Database.DatabaseManager import DataBase
from Logic.FriendService import FriendService
from Logic.GameRoomService import GameRoomService
from Logic.Player import Players
from Logic.PresenceService import PresenceService
from SCIDClient.Game import SCIDGame
from SCIDClient.GameSessions import GAME_SESSIONS
from Utils.Reader import BSMessageReader
from Utils.Writer import Writer
from main import ClientThread, Server
from test_protocol import login_payload, packet, receive_packet


def native_writer():
    return Writer(None).enable_native_v13()


def stream_events(payload):
    reader = BSMessageReader(payload).enable_native_v13()
    reader.read_Vint()
    reader.read_Vint()
    events = []
    for _ in range(reader.read_Vint()):
        kind = reader.read_Vint()
        reader.read_Vint()
        reader.read_Vint()
        reader.read_Vint()
        reader.read_Vint()
        reader.read_string()
        reader.read_Vint()
        reader.read_Vint()
        reader.read_boolean()
        event = None
        if kind == 2:
            reader.read_string()
        elif kind == 4:
            event = reader.read_Vint()
            if reader.read_boolean():
                reader.read_Vint()
                reader.read_Vint()
                reader.read_string()
        events.append(event)
    reader.ensure_end()
    return events


def room_id_of(payload):
    reader = BSMessageReader(payload).enable_native_v13()
    return reader.read_Vint(), reader.read_int()


class RoomCrashInviteTests(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        database = str(Path(temp.name) / 'crash-invite.sqlite')
        resolved = str(Path(database).resolve())
        self.addCleanup(DataBase._initialized_paths.discard, resolved)
        route = patch.object(DataBase, '_database_path', lambda: database)
        route.start()
        self.addCleanup(route.stop)
        scid = patch.object(SCIDGame, 'enabled', return_value=False)
        scid.start()
        self.addCleanup(scid.stop)
        self.server = Server('127.0.0.1', 0)
        self.server.crypto_settings = {'Enabled': False}
        self.addCleanup(self.server.server.close)
        self.addCleanup(PresenceService.bind_clients, None)
        self.addCleanup(GAME_SESSIONS.clear)
        self.addCleanup(GameRoomService.init)
        GameRoomService.init()
        self.players = []
        self.threads = []
        self.peers = []
        self.addCleanup(self.close_sessions)
        for number in self.accounts():
            player = Players(SimpleNamespace())
            player.low_id = number[0]
            player.name = number[1]
            player.token = 'crash-invite-' + str(number[0])
            DataBase.createAccount(SimpleNamespace(player=player))
            self.players.append(player)
        FriendService.add(self.players[0], self.players[1].low_id)
        FriendService.accept(self.players[1], self.players[0].low_id)

    def accounts(self):
        return ((601, 'Anfitriao'), (602, 'Convidado'))

    def close_sessions(self):
        for peer in self.peers:
            try:
                peer.close()
            except OSError:
                pass
        for thread in self.threads:
            thread.join(4)
            if thread.is_alive():
                raise AssertionError('Sessão não terminou')
        for key in list(self.server._season_timers):
            self.server._cancel_season_timer(key)

    def drain(self, peer, seconds=0.4):
        peer.settimeout(seconds)
        found = []
        try:
            while True:
                packet_id, _, payload = receive_packet(peer)
                found.append((packet_id, payload))
        except (TimeoutError, socket.timeout):
            pass
        finally:
            peer.settimeout(5)
        return found

    def login(self, index):
        server_socket, peer = socket.socketpair()
        peer.settimeout(5)
        self.peers.append(peer)
        thread = ClientThread(server_socket, ('test', index), self.server)
        self.threads.append(thread)
        thread.start()
        peer.sendall(packet(10100))
        self.assertEqual(receive_packet(peer)[0], 20100)
        player = self.players[index]
        peer.sendall(packet(10101, login_payload(player.low_id, player.token)))
        self.assertEqual(receive_packet(peer)[0], 20104)
        self.assertEqual(receive_packet(peer)[0], 24101)
        self.assertEqual(receive_packet(peer)[0], 20105)
        self.drain(peer)
        return peer

    def create_team(self, peer):
        writer = native_writer()
        for value in (7, 0, 0):
            writer.writeVint(value)
        writer.writeBoolean(False)
        peer.sendall(packet(14350, writer.buffer))

    def invite(self, peer, target_id):
        writer = native_writer()
        for value in (0, target_id, 0):
            writer.writeVint(value)
        peer.sendall(packet(14370, writer.buffer))

    def respond(self, peer, response_type, inviter_id, mute=False):
        writer = native_writer()
        writer.writeVint(response_type)
        writer.writeInt(0)
        writer.writeInt(inviter_id)
        writer.writeBoolean(mute)
        peer.sendall(packet(14479, writer.buffer))

    def leave(self, peer):
        peer.sendall(packet(14353))

    def team_packets(self, packets):
        return [
            (packet_id, payload) for packet_id, payload in packets
            if packet_id in (24124, 24125, 24129, 24131, 24589)
        ]

    def room_of(self, low_id):
        for room in GameRoomService.get_rooms():
            if any(member['low_id'] == low_id for member in room['members']):
                return room
        return None

    def persisted_room_id(self, low_id):
        with DataBase._connection() as connection:
            row = connection.execute(
                'SELECT roomID FROM players WHERE lowID = ?', (low_id,)
            ).fetchone()
        return None if row is None else int(row[0])

    def join_by_invitation(self):
        host = self.login(0)
        guest = self.login(1)
        self.create_team(host)
        self.drain(host)
        self.invite(host, self.players[1].low_id)
        self.assertEqual(
            [packet_id for packet_id, _ in self.team_packets(self.drain(guest))],
            [24589],
        )
        self.respond(guest, 1, self.players[0].low_id)
        self.drain(guest)
        self.drain(host)
        return host, guest

    def test_leave_then_reinvite_and_accept_joins_without_replaying_old_events(self):
        host, guest = self.join_by_invitation()
        self.leave(guest)
        packets = self.team_packets(self.drain(guest)) + self.team_packets(
            self.drain(host)
        )
        self.assertIn(24125, [packet_id for packet_id, _ in packets])
        self.assertIsNone(self.room_of(self.players[1].low_id))
        self.assertEqual(self.persisted_room_id(self.players[1].low_id), 0)

        self.invite(host, self.players[1].low_id)
        invited = self.team_packets(self.drain(guest))
        self.assertEqual([packet_id for packet_id, _ in invited], [24589])
        self.drain(host)
        self.respond(guest, 1, self.players[0].low_id)
        joined = self.team_packets(self.drain(guest))
        self.assertEqual(
            [packet_id for packet_id, _ in joined], [24124, 24131]
        )
        event_payload = [payload for packet_id, payload in joined if packet_id == 24131][0]
        self.assertEqual(stream_events(event_payload), [102])
        room = self.room_of(self.players[1].low_id)
        self.assertEqual(
            sorted(member['low_id'] for member in room['members']),
            [self.players[0].low_id, self.players[1].low_id],
        )
        self.assertEqual(
            self.persisted_room_id(self.players[1].low_id), room['id']
        )

    def test_repeated_cycles_never_replay_the_previous_leave_event(self):
        host, guest = self.join_by_invitation()
        for cycle in range(3):
            with self.subTest(cycle=cycle):
                self.leave(guest)
                self.drain(guest)
                self.drain(host)
                self.invite(host, self.players[1].low_id)
                self.assertEqual(
                    [packet_id for packet_id, _ in self.team_packets(self.drain(guest))],
                    [24589],
                )
                self.drain(host)
                self.respond(guest, 1, self.players[0].low_id)
                joined = self.team_packets(self.drain(guest))
                self.assertEqual(
                    [packet_id for packet_id, _ in joined], [24124, 24131]
                )
                for packet_id, payload in joined:
                    if packet_id == 24131:
                        self.assertEqual(stream_events(payload), [102])
                self.drain(host)
                self.assertIsNotNone(self.room_of(self.players[1].low_id))

    def test_crashed_guest_is_removed_from_the_room_and_from_presence(self):
        host, guest = self.join_by_invitation()
        room = self.room_of(self.players[1].low_id)
        guest.close()
        deadline = time.time() + 4
        while time.time() < deadline:
            if self.room_of(self.players[1].low_id) is None:
                break
            time.sleep(0.05)
        state = GameRoomService.get(room['id'])
        self.assertEqual(
            [member['low_id'] for member in state['members']],
            [self.players[0].low_id],
        )
        self.assertEqual(self.persisted_room_id(self.players[1].low_id), 0)
        self.assertEqual(PresenceService.status(self.players[1].low_id), 0)
        packets = self.team_packets(self.drain(host))
        self.assertIn(24124, [packet_id for packet_id, _ in packets])
        for packet_id, payload in packets:
            if packet_id == 24131:
                self.assertEqual(stream_events(payload), [101, 102, 103])

    def test_crashed_guest_can_be_invited_and_join_again(self):
        host, guest = self.join_by_invitation()
        guest.close()
        deadline = time.time() + 4
        while time.time() < deadline and self.room_of(self.players[1].low_id):
            time.sleep(0.05)
        self.assertIsNone(self.room_of(self.players[1].low_id))
        self.drain(host)

        guest = self.login(1)
        self.invite(host, self.players[1].low_id)
        invited = self.team_packets(self.drain(guest))
        self.assertEqual([packet_id for packet_id, _ in invited], [24589])
        self.drain(host)
        self.respond(guest, 1, self.players[0].low_id)
        joined = self.team_packets(self.drain(guest))
        self.assertEqual(
            [packet_id for packet_id, _ in joined], [24124, 24131]
        )
        self.assertIsNotNone(self.room_of(self.players[1].low_id))
        self.assertEqual(
            len(self.room_of(self.players[1].low_id)['members']), 2
        )

    def test_crashed_host_disbands_and_frees_the_guest(self):
        host, guest = self.join_by_invitation()
        room = self.room_of(self.players[0].low_id)
        host.close()
        deadline = time.time() + 4
        while time.time() < deadline and GameRoomService.get(room['id']) is not None:
            time.sleep(0.05)
        self.assertIsNone(GameRoomService.get(room['id']))
        self.assertEqual(self.persisted_room_id(self.players[1].low_id), 0)
        packets = self.team_packets(self.drain(guest))
        self.assertIn(24125, [packet_id for packet_id, _ in packets])

    def test_invitation_left_by_a_departed_host_is_discarded(self):
        host, guest = self.join_by_invitation()
        self.leave(host)
        self.drain(host)
        self.drain(guest)
        self.assertIsNone(GameRoomService.get_rooms() or None)
        self.assertIsNone(self.room_of(self.players[1].low_id))

        self.create_team(host)
        self.drain(host)
        self.invite(host, self.players[1].low_id)
        self.assertEqual(
            [packet_id for packet_id, _ in self.team_packets(self.drain(guest))],
            [24589],
        )
        self.drain(host)
        stale_room = self.room_of(self.players[0].low_id)
        self.leave(host)
        self.drain(host)
        self.drain(guest)
        self.assertIsNone(GameRoomService.get(stale_room['id']))
        self.respond(guest, 1, self.players[0].low_id)
        self.assertEqual(self.team_packets(self.drain(guest)), [])
        self.assertIsNone(self.room_of(self.players[1].low_id))
        self.assertEqual(self.persisted_room_id(self.players[1].low_id), 0)

    def test_pending_join_request_of_a_crashed_player_is_discarded(self):
        host = self.login(0)
        guest = self.login(1)
        self.create_team(host)
        self.drain(host)
        room = self.room_of(self.players[0].low_id)
        writer = native_writer()
        writer.writeInt(0)
        writer.writeInt(self.players[0].low_id)
        writer.writeInt(0)
        writer.writeInt(room['id'])
        guest.sendall(packet(14881, writer.buffer))
        deadline = time.time() + 4
        while time.time() < deadline:
            state = GameRoomService.get(room['id'])
            if state and state['join_requests']:
                break
            time.sleep(0.05)
        self.assertTrue(GameRoomService.get(room['id'])['join_requests'])
        guest.close()
        deadline = time.time() + 4
        while time.time() < deadline:
            state = GameRoomService.get(room['id'])
            if state is None or not state['join_requests']:
                break
            time.sleep(0.05)
        state = GameRoomService.get(room['id'])
        self.assertIsNotNone(state)
        self.assertEqual(state['join_requests'], [])

    def test_replaced_session_keeps_the_current_member_in_the_room(self):
        host, guest = self.join_by_invitation()
        room = self.room_of(self.players[1].low_id)
        replacement = self.login(1)
        try:
            guest.sendall(packet(10108))
        except OSError:
            pass
        deadline = time.time() + 4
        while time.time() < deadline:
            state = GameRoomService.get(room['id'])
            if state is None:
                break
            if len(state['members']) == 2:
                break
            time.sleep(0.05)
        self.drain(host)
        state = GameRoomService.get(room['id'])
        self.assertIsNotNone(state)
        self.assertEqual(
            sorted(member['low_id'] for member in state['members']),
            [self.players[0].low_id, self.players[1].low_id],
        )
        current = next(
            member for member in state['members']
            if member['low_id'] == self.players[1].low_id
        )
        self.assertEqual(current['status'], GameRoomService.TEAM_PRESENCE)
        self.assertIsNotNone(
            self.room_of(self.players[1].low_id)
        )
        self.assertNotEqual(replacement, guest)

    def test_offline_invitation_is_dropped_when_the_recipient_logs_in(self):
        host = self.login(0)
        self.create_team(host)
        self.drain(host)
        room = self.room_of(self.players[0].low_id)
        self.invite(host, self.players[1].low_id)
        packets = self.team_packets(self.drain(host))
        self.assertIn(24129, [packet_id for packet_id, _ in packets])
        state = GameRoomService.get(room['id'])
        self.assertEqual(
            [invite['status'] for invite in state['invites']],
            [GameRoomService.INVITE_OFFLINE],
        )
        self.login(1)
        self.assertEqual(GameRoomService.get(room['id'])['invites'], [])
        self.assertIsNone(self.room_of(self.players[1].low_id))


class RoomStreamBoundTests(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        database = str(Path(temp.name) / 'stream-bound.sqlite')
        self.addCleanup(DataBase._initialized_paths.discard, str(Path(database).resolve()))
        route = patch.object(DataBase, '_database_path', lambda: database)
        route.start()
        self.addCleanup(route.stop)
        self.addCleanup(GameRoomService.init)
        GameRoomService.init()

    def make_player(self, low_id):
        player = Players(SimpleNamespace())
        player.low_id = low_id
        player.name = 'Jogador %d' % low_id
        player.token = ''
        player.room_id = 0
        player.brawler_id = 0
        player.skin_id = 0
        return player

    def test_stream_is_bounded_and_keeps_each_member_offset(self):
        owner = self.make_player(801)
        guest = self.make_player(802)
        room = GameRoomService.create(owner, 0, 7, 0, False)
        GameRoomService.join(guest, room['id'])
        guest_entry = max(
            entry['id'] for entry in GameRoomService.stream_for(room, guest.low_id)
        )
        for index in range(120):
            GameRoomService.add_chat(owner, 'mensagem %d' % index)
        self.assertLessEqual(
            len(GameRoomService.stream(room['id'])), GameRoomService.STREAM_LIMIT
        )
        for low_id in (owner.low_id, guest.low_id):
            entries = GameRoomService.stream_for(room, low_id)
            self.assertLessEqual(len(entries), GameRoomService.STREAM_LIMIT)
            ids = [entry['id'] for entry in entries]
            self.assertEqual(ids, sorted(ids))
            if low_id == guest.low_id:
                self.assertTrue(all(entry_id > guest_entry for entry_id in ids))
            self.assertEqual(entries[-1]['message'], 'mensagem 119')


if __name__ == '__main__':
    unittest.main()
