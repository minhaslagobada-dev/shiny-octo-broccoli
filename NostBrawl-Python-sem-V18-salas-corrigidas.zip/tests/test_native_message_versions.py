from Packets.Messages.Server.Home.OwnHomeDataMessage import OwnHomeDataMessage
from tests.test_battle_end import BattleAccountTestCase, CaptureClient, make_battle


class NativeMessageVersionTests(BattleAccountTestCase):
    def test_battle_result_uses_r101_message_version(self):
        _, client, _ = self.process(make_battle())
        packet = client.packets[0]
        self.assertEqual(int.from_bytes(packet[:2], "big", signed=True), 23456)
        self.assertEqual(int.from_bytes(packet[5:7], "big"), 27)

    def test_own_home_data_uses_r101_message_version(self):
        client = CaptureClient()
        OwnHomeDataMessage(client, self.player).send()
        packet = client.packets[0]
        self.assertEqual(int.from_bytes(packet[:2], "big", signed=True), 24101)
        self.assertEqual(int.from_bytes(packet[5:7], "big"), 9)
