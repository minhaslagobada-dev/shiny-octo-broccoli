import os
import socket
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

PROJECT_ROOT = Path(__file__).resolve().parents[1]
os.chdir(PROJECT_ROOT)
sys.path.insert(0, str(PROJECT_ROOT))

from Database.DatabaseManager import DataBase
from Logic.FriendService import FriendService
from Logic.GameRoomService import (
    GameRoomFullError, GameRoomInviteError, GameRoomService,
)
from Files.CsvLogic.Skins import Skins
from Logic.Player import Players
from Logic.PresenceService import PresenceService
from SCIDClient.Game import SCIDGame
from SCIDClient.GameSessions import GAME_SESSIONS
from Packets.Messages.Server.Gameroom.TeamGameroomDataMessage import TeamGameroomDataMessage
from Packets.Messages.Server.Gameroom.TeamInvitationMessage import TeamInvitationMessage
from Utils.Reader import BSMessageReader
from Utils.Writer import Writer
from main import ClientThread, Server
from test_friends import read_friend
from test_protocol import login_payload, packet, receive_packet


def native_writer():
    return Writer(None).enable_native_v13()


class TeamInviteSocketTests(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        database = str(Path(temp.name) / 'invites44.sqlite')
        route = patch.object(DataBase, '_database_path', lambda: database)
        route.start()
        self.addCleanup(route.stop)
        scid = patch.object(SCIDGame, 'enabled', return_value=False)
        scid.start()
        self.addCleanup(scid.stop)
        self.server = Server('127.0.0.1', 0)
        self.server.crypto_settings = {'Enabled': False}
        self.addCleanup(self.server.server.close)
        self.addCleanup(PresenceService.bind_clients, None)
        self.addCleanup(GAME_SESSIONS.clear)
        GameRoomService.init()
        self.addCleanup(GameRoomService.init)
        self.players = []
        self.threads = []
        self.peers = []
        self.addCleanup(self.close_sessions)
        for number in (401, 402):
            player = Players(SimpleNamespace())
            player.low_id = number
            player.name = 'Equipe ' + str(number)
            player.token = 'socket-invite-44-' + str(number)
            DataBase.createAccount(SimpleNamespace(player=player))
            self.players.append(player)
        FriendService.add(self.players[0], 402)
        FriendService.accept(self.players[1], 401)

    def close_sessions(self):
        for peer in self.peers:
            try:
                peer.close()
            except OSError:
                pass
        for thread in self.threads:
            thread.join(4)
            if thread.is_alive():
                raise AssertionError('Sessão não terminou')
        for key in list(self.server._season_timers):
            self.server._cancel_season_timer(key)

    def login(self, index):
        server_socket, peer = socket.socketpair()
        peer.settimeout(5)
        self.peers.append(peer)
        thread = ClientThread(server_socket, ('test', index), self.server)
        self.threads.append(thread)
        thread.start()
        peer.sendall(packet(10100))
        self.assertEqual(receive_packet(peer)[0], 20100)
        player = self.players[index]
        peer.sendall(packet(10101, login_payload(player.low_id, player.token)))
        self.assertEqual(receive_packet(peer)[0], 20104)
        self.assertEqual(receive_packet(peer)[0], 24101)
        self.assertEqual(receive_packet(peer)[0], 20105)
        self.drain(peer)
        return peer

    def drain(self, peer):
        peer.settimeout(0.3)
        try:
            while True:
                packet_id, _, payload = receive_packet(peer)
                self.assertIn(packet_id, (20105, 20106, 24555, 24124), packet_id)
        except (TimeoutError, socket.timeout):
            pass
        finally:
            peer.settimeout(5)

    def create_team(self, peer):
        self.drain(peer)
        writer = native_writer()
        for value in (7, 0, 0):
            writer.writeVint(value)
        writer.writeBoolean(False)
        peer.sendall(packet(14350, writer.buffer))
        self.assertEqual(self.team_packets(peer, 2), [24124, 24131])
        return self.room_of(401)

    def team_packets(self, peer, count):
        found = []
        while len(found) < count:
            packet_id, _, payload = receive_packet(peer)
            if packet_id in (20105, 20106, 24555):
                continue
            found.append(packet_id)
        return found

    def room_of(self, low_id):
        for room in GameRoomService.get_rooms():
            if any(member['low_id'] == low_id for member in room['members']):
                return room
        return None

    def read_invitation(self, peer):
        while True:
            packet_id, _, payload = receive_packet(peer)
            if packet_id == 24589:
                break
            self.assertIn(packet_id, (20105, 20106, 24555, 24124), packet_id)
        reader = BSMessageReader(payload).enable_native_v13()
        invite_type = reader.read_Vint()
        sender_high, sender_low = reader.read_int(), reader.read_int()
        sender = read_friend(reader)
        reader.ensure_end()
        return invite_type, (sender_high, sender_low), sender

    def invite(self, peer, target_id, invite_type=0, message_id=14370):
        writer = native_writer()
        for value in (0, target_id, invite_type):
            writer.writeVint(value)
        peer.sendall(packet(message_id, writer.buffer))

    def respond(self, peer, response_type, inviter_id, mute=False):
        writer = native_writer()
        writer.writeVint(response_type)
        writer.writeInt(0)
        writer.writeInt(inviter_id)
        writer.writeBoolean(mute)
        peer.sendall(packet(14479, writer.buffer))

    def cancel(self, peer, high_id, low_id):
        writer = native_writer()
        writer.writeInt(high_id)
        writer.writeInt(low_id)
        peer.sendall(packet(14367, writer.buffer))
        packet_id, _, payload = receive_packet(peer)
        return packet_id, payload

    def test_invitation_reaches_the_recipient_with_the_native_wire(self):
        inviter = self.login(0)
        guest = self.login(1)
        room = self.create_team(inviter)
        self.invite(inviter, 402, 2)
        packet_id, _, payload = receive_packet(inviter)
        self.assertEqual(packet_id, 24124)
        pending = GameRoomService.get(room['id'])['invites']
        self.assertEqual(len(pending), 1)
        self.assertEqual(pending[0]['status'], GameRoomService.INVITE_PENDING)
        reader = BSMessageReader(payload).enable_native_v13()
        self.assertEqual(reader.read_Vint(), 0)
        self.assertFalse(reader.read_boolean())
        self.assertEqual(reader.read_Vint(), room['capacity'])
        self.assertEqual((reader.read_int(), reader.read_int()), (0, room['id']))
        invite_type, sender_reference, sender = self.read_invitation(guest)
        self.assertEqual(invite_type, TeamInvitationMessage.INVITE_NOTIFICATION)
        self.assertEqual(sender_reference, (0, 401))
        self.assertEqual(sender['low_id'], 401)

    def test_recipient_accepts_by_inviter_identifier(self):
        inviter = self.login(0)
        guest = self.login(1)
        room = self.create_team(inviter)
        self.invite(inviter, 402)
        self.assertEqual(receive_packet(inviter)[0], 24124)
        self.read_invitation(guest)
        self.respond(guest, 1, 401)
        self.assertEqual([receive_packet(guest)[0] for _ in range(2)], [24124, 24131])
        self.assertEqual([receive_packet(inviter)[0] for _ in range(2)], [24124, 24131])
        joined = GameRoomService.get(room['id'])
        self.assertEqual({member['low_id'] for member in joined['members']}, {401, 402})
        self.assertEqual(joined['invites'], [])

    def test_recipient_decline_keeps_native_declined_status(self):
        inviter = self.login(0)
        guest = self.login(1)
        room = self.create_team(inviter)
        self.invite(inviter, 402)
        self.assertEqual(receive_packet(inviter)[0], 24124)
        self.read_invitation(guest)
        self.respond(guest, 2, 401)
        self.assertEqual(receive_packet(inviter)[0], 24124)
        declined = GameRoomService.get(room['id'])['invites']
        self.assertEqual(len(declined), 1)
        self.assertEqual(declined[0]['status'], GameRoomService.INVITE_DECLINED)
        self.assertIsNone(self.room_of(402))

    def test_recipient_mute_blocks_the_next_invitation(self):
        inviter = self.login(0)
        guest = self.login(1)
        room = self.create_team(inviter)
        self.invite(inviter, 402)
        self.assertEqual(receive_packet(inviter)[0], 24124)
        self.read_invitation(guest)
        self.respond(guest, 3, 401, mute=True)
        self.assertEqual(receive_packet(inviter)[0], 24124)
        with self.assertRaises(GameRoomInviteError) as blocked:
            GameRoomService.invite(self.players[0], 402)
        self.assertEqual(blocked.exception.code, GameRoomInviteError.BLOCKED)
        loaded = Players(SimpleNamespace())
        loaded.token = self.players[1].token
        self.assertTrue(DataBase.loadAccount(SimpleNamespace(player=loaded)))
        self.assertIn('401', loaded.progression[GameRoomService.INVITE_MUTES_KEY])

    def test_inviter_cancels_the_pending_invitation(self):
        inviter = self.login(0)
        guest = self.login(1)
        room = self.create_team(inviter)
        self.invite(inviter, 402)
        self.assertEqual(receive_packet(inviter)[0], 24124)
        self.read_invitation(guest)
        packet_id, payload = self.cancel(inviter, 0, 402)
        self.assertEqual(packet_id, 24124)
        reader = BSMessageReader(payload).enable_native_v13()
        self.assertEqual(reader.read_Vint(), 0)
        self.assertFalse(reader.read_boolean())
        self.assertEqual(reader.read_Vint(), room['capacity'])
        self.assertEqual((reader.read_int(), reader.read_int()), (0, room['id']))
        expected = TeamGameroomDataMessage(
            None, self.players[0], GameRoomService.get(room['id'])
        )._encode_payload()
        self.assertEqual(payload, expected)
        self.assertEqual(GameRoomService.get(room['id'])['invites'], [])

    def test_cancel_without_matching_invitation_keeps_the_queue(self):
        inviter = self.login(0)
        guest = self.login(1)
        room = self.create_team(inviter)
        self.invite(inviter, 402)
        self.assertEqual(receive_packet(inviter)[0], 24124)
        self.read_invitation(guest)
        writer = native_writer()
        writer.writeInt(1)
        writer.writeInt(402)
        inviter.sendall(packet(14367, writer.buffer))
        inviter.settimeout(0.4)
        with self.assertRaises((TimeoutError, socket.timeout)):
            receive_packet(inviter)
        inviter.settimeout(5)
        self.assertEqual(len(GameRoomService.get(room['id'])['invites']), 1)
        self.assertEqual(
            GameRoomService.get(room['id'])['invites'][0]['status'],
            GameRoomService.INVITE_PENDING,
        )

    def test_invitation_to_offline_account_reports_the_native_error(self):
        inviter = self.login(0)
        self.login(1)
        self.create_team(inviter)
        self.peers[1].close()
        self.threads[1].join(4)
        self.drain(inviter)
        writer = native_writer()
        for value in (0, 402, 0):
            writer.writeVint(value)
        inviter.sendall(packet(14370, writer.buffer))
        while True:
            packet_id, _, payload = receive_packet(inviter)
            if packet_id == 24129:
                break
            self.assertEqual(packet_id, 24124)
        reader = BSMessageReader(payload).enable_native_v13()
        self.assertEqual((reader.read_Vint(), reader.read_Vint()), (0, 28))
        reader.ensure_end()
        room = self.room_of(401)
        self.assertEqual(room['invites'][0]['status'], GameRoomService.INVITE_OFFLINE)

    def test_invitation_to_a_teammate_reports_already_in_team(self):
        inviter = self.login(0)
        self.login(1)
        room = self.create_team(inviter)
        GameRoomService.join(self.players[1], room['id'])
        writer = native_writer()
        for value in (0, 402, 0):
            writer.writeVint(value)
        self.drain(inviter)
        inviter.sendall(packet(14370, writer.buffer))
        packet_id, _, payload = receive_packet(inviter)
        self.assertEqual(packet_id, 24129)
        reader = BSMessageReader(payload).enable_native_v13()
        self.assertEqual((reader.read_Vint(), reader.read_Vint()), (0, 29))
        reader.ensure_end()
        with self.assertRaises(GameRoomInviteError) as already:
            GameRoomService.invite(self.players[0], 402)
        self.assertEqual(already.exception.code, GameRoomInviteError.ALREADY_IN_TEAM)


class TeamInviteServiceTests(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.database = str(Path(temp.name) / 'invites44-pure.sqlite')
        route = patch.object(DataBase, '_database_path', lambda: self.database)
        route.start()
        self.addCleanup(route.stop)
        GameRoomService.init()
        self.addCleanup(GameRoomService.init)
        self.owner = self.account(501, 'owner-44')
        self.guest = self.account(502, 'guest-44')

    def account(self, low_id, token):
        player = Players(SimpleNamespace())
        player.low_id = low_id
        player.token = token
        player.name = f'Jogador {low_id}'
        player.room_id = 0
        player.brawlers_skins = {'0': 0}
        DataBase.createAccount(SimpleNamespace(player=player))
        return player

    def test_unknown_account_is_reported_as_no_friend(self):
        room = GameRoomService.create(self.owner, 1, 0, 0)
        self.addCleanup(GameRoomService.init)
        with self.assertRaises(GameRoomInviteError) as missing:
            GameRoomService.invite(self.owner, 999999)
        self.assertEqual(missing.exception.code, GameRoomInviteError.NO_FRIEND)
        self.assertEqual(GameRoomService.get(room['id'])['invites'], [])

    def test_full_room_is_reported_before_the_invitation_is_queued(self):
        room = GameRoomService.create(self.owner, 1, 0, 0)
        for low_id in range(600, 600 + room['capacity'] - 1):
            player = self.account(low_id, f'fill-{low_id}')
            GameRoomService.join(player, room['id'])
        with self.assertRaises(GameRoomFullError):
            GameRoomService.invite(self.owner, 502)
        self.assertEqual(GameRoomService.get(room['id'])['invites'], [])

    def test_pending_invitation_does_not_block_the_inviter_capacity(self):
        room = GameRoomService.create(self.owner, 1, 0, 0)
        for low_id in range(700, 700 + room['capacity'] - 1):
            player = self.account(low_id, f'fill2-{low_id}')
            GameRoomService.join(player, room['id'])
        with self.assertRaises(GameRoomFullError):
            GameRoomService.invite(self.owner, 502)

    def test_declined_invitation_allows_a_new_one(self):
        room = GameRoomService.create(self.owner, 1, 0, 0)
        GameRoomService.invite(self.owner, 502)
        declined_room, invite = GameRoomService.decline_invite_from(self.guest, 501)
        self.assertEqual(invite['status'], GameRoomService.INVITE_DECLINED)
        again, pending = GameRoomService.invite(self.owner, 502)
        self.assertEqual(len(again['invites']), 1)
        self.assertEqual(pending['status'], GameRoomService.INVITE_PENDING)

    def test_cancel_by_the_recipient_side_uses_the_sender_identifier(self):
        room = GameRoomService.create(self.owner, 1, 0, 0)
        GameRoomService.invite(self.owner, 502)
        cancelled, invite = GameRoomService.cancel_invite(self.guest, 0, 501)
        self.assertEqual(invite['sender_id'], 501)
        self.assertEqual(cancelled['invites'], [])

    def test_accept_requires_the_pending_invitation(self):
        GameRoomService.create(self.owner, 1, 0, 0)
        self.assertEqual(
            GameRoomService.accept_invite_from(self.guest, 501), (None, None)
        )
        self.assertIsNone(self.room_for(self.guest))

    def room_for(self, player):
        room = GameRoomService.for_player(player)
        return None if room is None else room


if __name__ == '__main__':
    unittest.main()
