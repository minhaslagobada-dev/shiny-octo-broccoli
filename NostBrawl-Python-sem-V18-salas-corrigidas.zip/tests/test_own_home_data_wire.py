import csv
import os
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch


PROJECT_ROOT = Path(__file__).resolve().parents[1]
os.chdir(PROJECT_ROOT)
sys.path.insert(0, str(PROJECT_ROOT))

from Logic.EventRotation import EventRotation
from Logic.EventSlots import EventSlots
from Logic.Player import Players
from Packets.Messages.Server.Home.OwnHomeDataMessage import OwnHomeDataMessage
from Utils.Reader import BSMessageReader


HOME_TIMESTAMP = 1793897003


class OwnHomeDataReader(BSMessageReader):
    """Independent bit/VInt reader for the complete OwnHomeData envelope."""

    def __init__(self, payload):
        super().__init__(payload)
        self.bit_index = 0
        self.bit_byte = 0

    def align(self):
        self.bit_index = 0

    def v(self):
        self.align()
        return self.read_Vint()

    def b(self):
        if self.bit_index == 0:
            self.bit_byte = self.read_byte()
        value = bool(self.bit_byte & (1 << self.bit_index))
        self.bit_index = (self.bit_index + 1) & 7
        return value

    def i(self):
        self.align()
        return self.read_int()

    def s(self):
        self.align()
        return self.read_string()

    def long(self):
        self.align()
        raw = self._read_exact(8)
        return int.from_bytes(raw[:4], "big"), int.from_bytes(raw[4:], "big")

    def array(self):
        return [self.v() for _ in range(self.v())]

    def references(self):
        return [(self.v(), self.v()) for _ in range(self.v())]

    def brawler_values(self):
        return [(self.v(), self.v(), self.v()) for _ in range(self.v())]


def fixed_home_events(_player):
    values = ((7, 2, 10), (32, 0, 10), (24, 0, 10), (0, 0, 10), (30, 0, 2))
    return [
        {"slot": slot, "map_id": map_id, "modifier": modifier, "tokens": tokens, "claimed": False}
        for slot, (map_id, modifier, tokens) in enumerate(values, 1)
    ]


def read_home_daily_fields(payload):
    reader = OwnHomeDataReader(payload)
    for _ in range(2):
        reader.v()
    for _ in range(5):
        reader.v()
    for _ in range(2):
        reader.v()
    reader.v()
    reader.references()
    reader.references()
    reader.b()
    for _ in range(6):
        reader.v()
    reader.b()
    reader.v()
    reader.b()
    for _ in range(2):
        reader.v()
    for _ in range(4):
        reader.b()
    for _ in range(3):
        reader.v()
    reader.b()
    return [reader.v() for _ in range(6)]


def read_home_commodities(payload):
    reader = OwnHomeDataReader(payload)
    reader.daily_timestamp = reader.v()
    reader.v()
    for _ in range(5):
        reader.v()
    for _ in range(3):
        reader.v()
    reader.references()
    reader.references()
    reader.b()
    for _ in range(6):
        reader.v()
    reader.token_limit = reader.b()
    reader.v()
    reader.b()
    for _ in range(2):
        reader.v()
    for _ in range(4):
        reader.b()
    for _ in range(3):
        reader.v()
    reader.b()
    for _ in range(reader.v()):
        for _ in range(reader.v()):
            reader.v()
            reader.v()
            target_class = reader.v()
            if target_class:
                reader.v()
            reader.v()
        for _ in range(5):
            reader.v()
        reader.b()
        reader.v()
        reader.b()
        reader.v()
        reader.s()
    reader.daily_home_fields = [reader.v() for _ in range(6)]
    reader.selected_brawler = (reader.v(), reader.v())
    reader.shop_timestamp = reader.v()
    for _ in range(11):
        reader.v()
    reader.array()
    reader.array()
    reader.events = []
    for _ in range(reader.v()):
        reader.events.append([reader.v() for _ in range(8)])
        reader.s()
        reader.v()
        reader.array()
        reader.v()
    reader.v()
    for _ in range(6):
        reader.array()
    reader.v()
    reader.daily_fields = [reader.v() for _ in range(5)]
    for _ in range(3):
        reader.b()
    for _ in range(2):
        reader.v()
    reader.b()
    reader.v()
    reader.long()
    for _ in range(reader.v()):
        reader.v()
        reader.v()
    reader.v()
    reader.b()
    reader.v()
    for _ in range(3):
        reader.v()
        reader.v()
    reader.s()
    reader.b()
    reader.s()
    reader.v()
    commodities = [
        (reader.v(), reader.v(), reader.v()) for _ in range(reader.v())
    ]
    return reader, commodities


class OwnHomeDataWireTests(unittest.TestCase):
    def test_complete_packet_has_no_missing_or_trailing_fields(self):
        player = SimpleNamespace(
            high_id=1,
            low_id=42,
            name="Wire",
            trophies=999,
            highest_trophies=999,
            trophy_road=7,
            exp_points=11,
            profile_icon=2,
            brawlers_skins={"0": 29, "1": 0},
            UnlockedSkins={"Skins": [29, 0]},
            tokensAnim=1,
            trophiesAnim=2,
            bigTokensAnim=3,
            tokensdoubler=1000,
            brawler_id=0,
            battle_tokens=200,
            brawlers_id=[0, 1],
            card_unlock_id=[10, 12],
            BrawlersUnlockedState={"0": 1, "1": 0},
            brawlers_trophies={"0": 12, "1": 13},
            brawlers_trophies_in_rank={"0": 22, "1": 23},
            brawlers_upgradium={"0": 32, "1": 33},
            Brawler_level={"0": 2, "1": 9},
            Brawler_starPower={"0": 76, "1": 80},
            progression={"brawlerNewTag": {"0": 0, "1": 1}},
            gems=969,
            gold=100,
            brawl_boxes=899,
            big_boxes=4,
            star_points=5,
            player_experience=77,
            tutorial=2,
        )
        message = OwnHomeDataMessage(None, player)
        with patch.object(EventSlots, "Timer", lambda self: 49020), \
             patch.object(EventRotation, "snapshot", side_effect=fixed_home_events), \
             patch.object(EventRotation, "seconds_to_next_day", lambda: 49020), \
             patch("Packets.Messages.Server.Home.OwnHomeDataMessage.time.time", return_value=HOME_TIMESTAMP), \
             patch(
                 "Packets.Messages.Server.Home.OwnHomeDataMessage.ShopService.encode_home",
                 lambda writer, player: writer.v(0),
             ):
            message.encode()
        fixture = Path(__file__).resolve().parent / "fixtures" / "own_home_data.bin"
        self.assertEqual(message.buffer, fixture.read_bytes())
        reader = OwnHomeDataReader(message.buffer)

        self.assertEqual([reader.v() for _ in range(2)], [HOME_TIMESTAMP, 0])
        self.assertEqual(
            [reader.v() for _ in range(5)], [999, 999, 0, 7, 77]
        )
        self.assertEqual((reader.v(), reader.v()), (28, 2))
        self.assertEqual(reader.v(), 0)
        self.assertEqual(reader.references(), [(29, 29), (29, 0)])
        self.assertEqual(reader.references(), [(29, 29)])

        self.assertFalse(reader.b())
        self.assertEqual(
            [reader.v() for _ in range(6)], [0, 1, 2, 3, 0, 0]
        )
        self.assertFalse(reader.b())
        self.assertEqual(reader.v(), 0)
        self.assertFalse(reader.b())
        self.assertEqual([reader.v(), reader.v()], [1000, 0])
        self.assertEqual([reader.b() for _ in range(4)], [False] * 4)
        self.assertEqual([reader.v() for _ in range(3)], [0, 0, 0])
        self.assertFalse(reader.b())
        self.assertEqual([reader.v() for _ in range(6)], [0, 0, 200, 0, 0, 0])
        self.assertEqual(reader.v(), 0)
        self.assertEqual((reader.v(), reader.v()), (16, 0))

        self.assertEqual(
            [reader.v() for _ in range(12)],
            [HOME_TIMESTAMP, 100, 10, 30, 3, 80, 10, 50, 1000, 500, 50, 999900],
        )
        self.assertEqual(reader.array(), [0, 30, 80, 170, 350, 0])
        slots = reader.array()
        self.assertEqual(slots, list(range(6)))

        expected_events = (
            (7, 10, 2),
            (32, 10, 0),
            (24, 10, 0),
            (0, 10, 0),
            (30, 2, 0),
        )
        self.assertEqual(reader.v(), len(expected_events))
        encoded_maps = []
        for index, (map_id, tokens, modifier) in enumerate(expected_events, 1):
            self.assertEqual(
                [reader.v() for _ in range(8)],
                [map_id, index, 0, 49020, tokens, 15, map_id, 1],
            )
            self.assertEqual(reader.s(), "")
            self.assertEqual(reader.v(), 0)
            self.assertEqual(reader.array(), [modifier] if modifier else [])
            self.assertEqual(reader.v(), 0)
            encoded_maps.append(map_id)
        with open(
            PROJECT_ROOT / "GameAssets" / "csv_logic" / "locations.csv",
            encoding="utf-8-sig",
            newline="",
        ) as csv_file:
            locations = list(csv.DictReader(csv_file))[1:]
        for map_id in encoded_maps:
            self.assertLess(map_id, len(locations))
            self.assertFalse(locations[map_id]["Disabled"])
        self.assertEqual(reader.v(), 0)
        self.assertEqual(reader.array(), [20, 35, 75, 140, 290, 480, 800, 1250])
        self.assertEqual(reader.array(), [1, 2, 3, 4, 5, 10, 15, 20])
        self.assertEqual(reader.array(), [10, 30, 80])
        self.assertEqual(reader.array(), [6, 20, 60])
        self.assertEqual(reader.array(), [20, 50, 140])
        self.assertEqual(reader.array(), [150, 400, 1200])

        self.assertEqual(reader.v(), 0)
        self.assertEqual([reader.v() for _ in range(5)], [700, 20, 8640, 10, 5])
        self.assertEqual([reader.b() for _ in range(3)], [False] * 3)
        self.assertEqual([reader.v(), reader.v()], [0, 0])
        self.assertTrue(reader.b())
        self.assertEqual(reader.v(), 0)

        self.assertEqual(reader.long(), (1, 42))
        self.assertEqual([reader.v(), reader.v()], [0, 0])
        self.assertFalse(reader.b())
        self.assertEqual(reader.v(), 0)

        for _ in range(3):
            self.assertEqual([reader.v(), reader.v()], [1, 42])
        self.assertEqual(reader.s(), "Wire")
        self.assertTrue(reader.b())
        self.assertEqual(reader.i(), 0xFFFFFFFF)
        self.assertEqual(reader.v(), 8)

        commodities = [
            (reader.v(), reader.v(), reader.v()) for _ in range(reader.v())
        ]
        self.assertEqual(commodities, [
            (23, 10, 1), (23, 12, 0), (23, 0, 5),
            (5, 1, 899), (5, 8, 100), (5, 9, 4),
        ])
        self.assertEqual(reader.brawler_values(), [(16, 0, 12), (16, 1, 13)])
        self.assertEqual(reader.brawler_values(), [(16, 0, 22), (16, 1, 23)])
        self.assertEqual(reader.v(), 0)
        self.assertEqual(reader.brawler_values(), [(16, 0, 32), (16, 1, 33)])
        self.assertEqual(reader.brawler_values(), [(16, 0, 2), (16, 1, 9)])
        self.assertEqual(reader.v(), 0)                        
        self.assertEqual(reader.v(), 0)                     
        self.assertEqual([reader.v() for _ in range(3)], [969, 969, 77])
        self.assertEqual([reader.v() for _ in range(7)], [0] * 7)
        self.assertEqual([reader.v(), reader.v()], [2, HOME_TIMESTAMP])
        self.assertEqual(reader.tell(), len(message.buffer))
        self.assertEqual(reader.read(), b"")

    def test_home_writes_ticket_balance_in_the_daily_resource_field(self):
        player = Players(SimpleNamespace())
        player.tickets = 7
        message = OwnHomeDataMessage(None, player)
        with patch.object(EventSlots, "Timer", lambda self: 49020), \
             patch.object(EventRotation, "snapshot", side_effect=fixed_home_events), \
             patch.object(EventRotation, "seconds_to_next_day", lambda: 49020), \
             patch(
                 "Packets.Messages.Server.Home.OwnHomeDataMessage.ShopService.encode_home",
                 lambda writer, player: writer.v(0),
             ):
            message.encode()
        self.assertEqual(read_home_daily_fields(message.buffer), [0, 0, 700, 0, 0, 7])

    def test_power_one_and_zero_points_use_zero_based_home_values(self):
        player = Players(SimpleNamespace())
        message = OwnHomeDataMessage(None, player)
        with patch.object(EventSlots, "Timer", lambda self: 49020), patch(
            "Packets.Messages.Server.Home.OwnHomeDataMessage.ShopService.encode_home",
            lambda writer, player: writer.v(0),
        ):
            message.encode()
        reader, _ = read_home_commodities(message.buffer)
        reader.brawler_values()
        reader.brawler_values()
        reader.v()
        points = reader.brawler_values()
        levels = reader.brawler_values()
        self.assertEqual(points[0], (16, 0, 0))
        self.assertEqual(levels[0], (16, 0, 0))

    def test_real_home_encodes_leon_with_unlock_card_115(self):
        player = Players(SimpleNamespace())
        player.BrawlersUnlockedState["23"] = 1
        leon_index = player.brawlers_id.index(23)
        self.assertEqual(len(player.brawlers_id), 22)
        self.assertEqual(player.card_unlock_id[leon_index], 115)
        message = OwnHomeDataMessage(None, player)
        with patch.object(EventSlots, "Timer", lambda self: 49020), patch(
            "Packets.Messages.Server.Home.OwnHomeDataMessage.ShopService.encode_home",
            lambda writer, player: writer.v(0),
        ):
            message.encode()
        reader, commodities = read_home_commodities(message.buffer)
        self.assertEqual(commodities[leon_index], (23, 115, 1))
        self.assertEqual(len(commodities[:len(player.card_unlock_id)]), 22)
        self.assertNotIn((23, 105, 1), commodities)
        reader.brawler_values()
        reader.brawler_values()
        reader.v()
        reader.brawler_values()
        reader.brawler_values()
        for _ in range(2):
            reader.v()
        for _ in range(3):
            reader.v()
        for _ in range(7):
            reader.v()
        for _ in range(2):
            reader.v()
        self.assertEqual(reader.tell(), len(message.buffer))
        self.assertEqual(reader.read(), b"")


if __name__ == "__main__":
    unittest.main()
