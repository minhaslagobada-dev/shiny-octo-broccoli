import sqlite3
import threading
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta
from unittest.mock import patch

from Database.DatabaseManager import DataBase
from Logic.DailyRewards import DailyRewards
from tests import test_daily_rewards
from tests.test_battle_end import BattleAccountTestCase
from tests.test_own_home_data_wire import read_home_commodities
from Packets.Messages.Server.Home.OwnHomeDataMessage import OwnHomeDataMessage


class TokenRefillTests(BattleAccountTestCase):
    make_daily_account = test_daily_rewards.DailyRewardTests.make_daily_account
    reward = test_daily_rewards.DailyRewardTests.reward
    refill_at = test_daily_rewards.DailyRewardTests.refill_at
    restart_schema = test_daily_rewards.DailyRewardTests.restart_schema

    def setUp(self):
        super().setUp()
        self.day = datetime.now().replace(microsecond=0)

    def test_first_consumption_starts_timer_and_boundary_refills_once(self):
        player = self.make_daily_account(tokens=700)
        full = DailyRewards.sync_player(player, self.day)
        self.assertEqual((full['remaining'], full['next_refill_in']), (700, 0))
        self.reward(player)
        before = DailyRewards.sync_player(player, self.day + timedelta(seconds=8639))
        self.assertEqual((before['remaining'], before['next_refill_in']), (680, 1))
        exact = DailyRewards.sync_player(player, self.day + timedelta(seconds=8640))
        self.assertEqual((exact['remaining'], exact['next_refill_at']), (700, 0))
        repeated = DailyRewards.sync_player(player, self.day + timedelta(seconds=8640))
        self.assertEqual((repeated['remaining'], repeated['next_refill_at']), (700, 0))

    def test_multiple_steps_cap_and_new_cycle(self):
        player = self.make_daily_account(tokens=659)
        start = DailyRewards.sync_player(player, self.day)
        self.assertEqual(start['next_refill_in'], 8640)
        partial = DailyRewards.sync_player(player, self.day + timedelta(seconds=2 * 8640 + 123))
        self.assertEqual((partial['remaining'], partial['next_refill_in']), (699, 8640 - 123))
        full = DailyRewards.sync_player(player, self.day + timedelta(seconds=10 * 8640))
        self.assertEqual((full['remaining'], full['next_refill_at']), (700, 0))
        later = self.day + timedelta(seconds=10 * 8640 + 1)
        self.reward(player, now=later)
        self.assertEqual(self.refill_at(player), int(later.timestamp()) + 8640)

    def test_midnight_does_not_reset_or_change_refill_timer(self):
        player = self.make_daily_account(tokens=0)
        start = self.day.replace(hour=23, minute=59, second=59)
        DailyRewards.sync_player(player, start)
        at_midnight = DailyRewards.sync_player(player, start + timedelta(seconds=1))
        self.assertEqual((at_midnight['remaining'], at_midnight['next_refill_in']), (0, 8639))

    def test_legacy_day_table_does_not_override_existing_balance(self):
        player = self.make_daily_account(tokens=137)
        with DataBase._connection() as db:
            db.execute('INSERT INTO daily_token_limits (player_id,day,used,updated_at) VALUES (?,?,?,?)',
                       (player.low_id, '2020-01-01', 700, 42))
            db.execute('DROP TABLE battle_token_refill')
        self.restart_schema()
        self.reload(player)
        synced = DailyRewards.sync_player(player, self.day)
        self.assertEqual((synced['remaining'], synced['next_refill_in']), (137, 8640))
        with DataBase._connection() as db:
            self.assertEqual(db.execute('SELECT day,used,updated_at FROM daily_token_limits WHERE player_id=?',
                                        (player.low_id,)).fetchone(), ('2020-01-01', 700, 42))

    def test_refill_and_consumption_rollback_together(self):
        player = self.make_daily_account(tokens=0)
        DailyRewards.sync_player(player, self.day)
        moment = self.day + timedelta(seconds=8640)
        with self.assertRaises(sqlite3.OperationalError):
            with DataBase._connection() as db:
                db.execute('BEGIN IMMEDIATE')
                changed = DailyRewards.consume(db, player.low_id, 10, now=moment)
                self.assertEqual((changed['remaining'], changed['tokens_gain']), (10, 10))
                raise sqlite3.OperationalError('injected')
        self.assertEqual(self.reload(player).battle_tokens, 0)
        self.assertEqual(self.refill_at(player), int(moment.timestamp()))
        self.assertEqual(DailyRewards.sync_player(player, moment)['remaining'], 20)

    def test_concurrent_refill_and_consumption_cannot_duplicate_balance(self):
        player = self.make_daily_account(tokens=0)
        DailyRewards.sync_player(player, self.day)
        moment = self.day + timedelta(seconds=8640)
        barrier = threading.Barrier(8)
        def consume(_):
            barrier.wait()
            with DataBase._connection() as db:
                db.execute('BEGIN IMMEDIATE')
                return DailyRewards.consume(db, player.low_id, 10, now=moment)['tokens_gain']
        with ThreadPoolExecutor(max_workers=8) as pool:
            granted = list(pool.map(consume, range(8)))
        self.assertEqual(sum(granted), 20)
        self.assertEqual(self.reload(player).battle_tokens, 0)
        self.assertEqual(self.refill_at(player), int(moment.timestamp()) + 8640)

    def test_home_serializes_remaining_seconds_after_restart(self):
        player = self.make_daily_account(tokens=700)
        self.reward(player)
        self.restart_schema()
        loaded = self.reload(player)
        with patch('Logic.DailyRewards.datetime') as clock, \
             patch('Packets.Messages.Server.Home.OwnHomeDataMessage.ShopService.encode_home',
                   lambda writer, target: writer.v(0)):
            clock.now.return_value = self.day + timedelta(seconds=123)
            payload = OwnHomeDataMessage(None, loaded)._encode_payload()
        reader, _ = read_home_commodities(payload)
        self.assertEqual(reader.daily_home_fields[1:3], [680, 8517])
        self.assertEqual(reader.daily_fields[:3], [700, 20, 8640])
