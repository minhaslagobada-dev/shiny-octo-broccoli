import json
import os
import socket
import sys
import threading
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

PROJECT_ROOT = Path(__file__).resolve().parents[1]
os.chdir(PROJECT_ROOT)
sys.path.insert(0, str(PROJECT_ROOT))

from Database.DatabaseManager import DataBase
from Logic.FriendService import FriendError, FriendService
from Logic.Player import Players
from Logic.PresenceService import PresenceService
from Packets.Messages.Client.Home.PlayerStatusMessage import PlayerStatusMessage
from Packets.LogicMessageFactory import packets
from Packets.Messages.Client.Friend.AcceptFriendMessage import AcceptFriendMessage
from Packets.Messages.Client.Friend.AddFriend import AddFriend
from Packets.Messages.Client.Friend.AskForAddableFriendsMessage import AskForAddableFriendsMessage
from Packets.Messages.Client.Friend.AskForFriendSuggestionsMessage import AskForFriendSuggestionsMessage
from Packets.Messages.Client.Friend.FacebookConnect import FacebookConnect
from Packets.Messages.Client.Friend.RemoveFriendMessage import RemoveFriendMessage
from Packets.Messages.Client.Friend.UnlinkFacebookAcount import UnlinkFacebookAcount
from Packets.Messages.Server.Friend.FriendListMessage import FriendListMessage
from Packets.Messages.Server.Friend.FriendListUpdateMessage import FriendListUpdateMessage
from Packets.Messages.Server.Friend.FriendSuggestionsMessage import FriendSuggestionsMessage
from Utils.Reader import BSMessageReader
from Utils.Writer import Writer


class CaptureClient:
    def __init__(self):
        self.packets = []

    def sendall(self, data):
        self.packets.append(bytes(data))

    def payload(self, index=-1):
        packet = self.packets[index]
        message_id = int.from_bytes(packet[:2], "big")
        length = int.from_bytes(packet[2:5], "big")
        if length != len(packet) - 7:
            raise AssertionError("Invalid packet length")
        return message_id, packet[7:]


def int_payload(*values, strings=()):
    writer = Writer(None)
    for value in values:
        writer.writeInt(value)
    for value in strings:
        writer.writeString(value)
    return writer.buffer


def facebook_payload(facebook_id, token):
    writer = Writer(None)
    writer.writeVint(0)
    writer.writeString(facebook_id)
    writer.writeString(token)
    return writer.buffer


def read_friend(reader):
    result = {"high_id": reader.read_int(), "low_id": reader.read_int()}
    result["strings"] = [reader.read_string() for _ in range(4)]
    result["ints"] = [reader.read_int() for _ in range(6)]
    result["has_club"] = reader.read_byte()
    if result["has_club"]:
        result["club"] = {
            "high_id": reader.read_int(),
            "low_id": reader.read_int(),
            "before_name": reader.read_int(),
            "name": reader.read_string(),
            "after_name": [reader.read_int(), reader.read_int()],
        }
    result["final_string"] = reader.read_string()
    result["profile_icon"] = reader.read_int()
    result["final_int"] = reader.read_int()
    return result


class FriendTests(unittest.TestCase):
    def setUp(self):
        self.temp_directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp_directory.cleanup)
        self.database_path = str(Path(self.temp_directory.name) / "players.db")
        path_patch = patch.object(DataBase, "_database_path", lambda: self.database_path)
        path_patch.start()
        self.addCleanup(path_patch.stop)
        self.players = [self.make_account(index) for index in range(1, 4)]
        self.clients = [CaptureClient() for _ in range(3)]
        registry = {"Clients": {}}
        for index, player in enumerate(self.players):
            player.ClientDict = registry
            registry["Clients"][str(player.low_id)] = {
                "SocketInfo": self.clients[index], "Crypto": None,
                "Lock": player.send_lock, "Status": 0, "Player": player,
            }

    def make_account(self, low_id):
        player = Players(SimpleNamespace())
        player.low_id = low_id
        player.high_id = 0
        player.token = "friend-token-%d" % low_id
        player.name = "Friend %d" % low_id
        player.profile_icon = low_id
        DataBase.createAccount(SimpleNamespace(player=player))
        return player

    def reload(self, source):
        player = Players(SimpleNamespace())
        player.token = source.token
        self.assertTrue(DataBase.loadAccount(SimpleNamespace(player=player)))
        return player

    def test_delayed_presence_does_not_reintroduce_removed_friend(self):
        first, second, _ = self.players
        FriendService.add(first, second.low_id)
        FriendService.accept(second, first.low_id)
        sender, receiver = socket.socketpair()
        self.addCleanup(sender.close)
        self.addCleanup(receiver.close)
        receiver.settimeout(0.15)
        first.ClientDict = {'Clients': {str(second.low_id): {
            'SocketInfo': sender, 'Crypto': None, 'Lock': second.send_lock,
        }}}
        waiting, release = threading.Event(), threading.Event()
        errors, delivered = [], []
        original = FriendListMessage._can_deliver
        def delayed(message, low_id):
            waiting.set()
            if not release.wait(3):
                raise TimeoutError('presença não liberada')
            return original(message, low_id)
        def push():
            try:
                delivered.append(FriendService.push_presence(first))
            except Exception as error:
                errors.append(error)
        with patch.object(FriendListMessage, '_can_deliver', new=delayed):
            thread = threading.Thread(target=push)
            thread.start()
            try:
                self.assertTrue(waiting.wait(2))
                FriendService.remove(first, second.low_id)
            finally:
                release.set()
                thread.join(3)
            self.assertFalse(thread.is_alive())
        self.assertEqual(errors, [])
        self.assertEqual(delivered, [1])
        from test_protocol import receive_packet
        message_id, _, raw = receive_packet(receiver)
        self.assertEqual(message_id, 20105)
        reader = BSMessageReader(raw)
        self.assertEqual(reader.read_int(), 0)
        self.assertEqual(reader.read_byte(), 1)
        self.assertEqual(reader.read_int(), 0)
        self.assertEqual(reader.read(), b'')

    def test_delayed_remove_lists_reflect_new_friend_request(self):
        first, second, _ = self.players
        FriendService.add(first, second.low_id)
        FriendService.accept(second, first.low_id)
        first_socket, first_peer = socket.socketpair()
        second_socket, second_peer = socket.socketpair()
        for endpoint in (first_socket, first_peer, second_socket, second_peer):
            self.addCleanup(endpoint.close)
            endpoint.settimeout(2)
        first.ClientDict = {'Clients': {str(second.low_id): {
            'SocketInfo': second_socket, 'Crypto': None, 'Lock': second.send_lock,
        }}}
        waiting, release = threading.Event(), threading.Event()
        errors = []
        original = FriendListMessage._can_deliver
        def delayed(message, low_id):
            if low_id == first.low_id:
                waiting.set()
                if not release.wait(3):
                    raise TimeoutError('lista não liberada')
            return original(message, low_id)
        def remove():
            try:
                message = RemoveFriendMessage(first_socket, first, int_payload(0, second.low_id))
                message.decode()
                message.process()
            except Exception as error:
                errors.append(error)
        with patch.object(FriendListMessage, '_can_deliver', new=delayed):
            thread = threading.Thread(target=remove)
            thread.start()
            try:
                self.assertTrue(waiting.wait(2))
                FriendService.add(second, first.low_id)
            finally:
                release.set()
                thread.join(3)
            self.assertFalse(thread.is_alive())
        self.assertEqual(errors, [])
        from test_protocol import receive_packet
        for peer, expected_id, expected_state in (
            (first_peer, second.low_id, FriendService.INCOMING),
            (second_peer, first.low_id, FriendService.OUTGOING),
        ):
            packet_id, _, payload = receive_packet(peer)
            self.assertEqual(packet_id, 20105)
            reader = BSMessageReader(payload)
            self.assertEqual(reader.read_int(), 0)
            self.assertTrue(reader.read_byte())
            self.assertEqual(reader.read_int(), 1)
            entry = read_friend(reader)
            self.assertEqual((entry['low_id'], entry['ints'][2]), (expected_id, expected_state))

    def test_nonzero_high_id_cannot_modify_local_friend_relation(self):
        first, second, _ = self.players
        add = AddFriend(self.clients[0], first, int_payload(1, second.low_id, 0, 0))
        add.decode()
        self.assertFalse(add.process()['accepted'])
        self.assertEqual(FriendService.friends(first), [])
        FriendService.add(first, second.low_id)
        accept = AcceptFriendMessage(self.clients[1], second, int_payload(1, first.low_id))
        accept.decode()
        self.assertFalse(accept.process()['accepted'])
        self.assertEqual(FriendService.friends(second)[0]['state'], FriendService.INCOMING)
        FriendService.accept(second, first.low_id)
        remove = RemoveFriendMessage(self.clients[0], first, int_payload(1, second.low_id))
        remove.decode()
        self.assertFalse(remove.process()['removed'])
        self.assertEqual(FriendService.friends(first)[0]['state'], FriendService.FRIEND)

    def test_factory_and_native_friend_decoders(self):
        self.assertIs(packets[10501], AcceptFriendMessage)
        self.assertIs(packets[10502], AddFriend)
        self.assertIs(packets[10503], AskForAddableFriendsMessage)
        self.assertIs(packets[10506], RemoveFriendMessage)
        with self.assertRaises(ValueError):
            AddFriend(self.clients[0], self.players[0], int_payload(0, 2)).decode()
        with self.assertRaises(ValueError):
            AcceptFriendMessage(
                self.clients[1], self.players[1], int_payload(0, 1, 0)
            ).decode()
        with self.assertRaises(ValueError):
            RemoveFriendMessage(
                self.clients[0], self.players[0], int_payload(0, 2, 0)
            ).decode()
        self.assertEqual(FriendService.friends(self.players[0]), [])

    def test_request_accept_remove_notifications_and_relogin(self):
        first, second, _ = self.players
        message = AddFriend(self.clients[0], first, int_payload(0, 2, 3, 0))
        message.decode()
        result = message.process()
        self.assertEqual(result["state"], FriendService.OUTGOING)
        self.assertEqual(FriendService.friends(first)[0]["state"], 2)
        self.assertEqual(FriendService.friends(second)[0]["state"], 3)
        message_id, raw = self.clients[0].payload()
        self.assertEqual(message_id, 20106)
        reader = BSMessageReader(raw)
        self.assertEqual(reader.read_byte(), 0)
        self.assertEqual(read_friend(reader)["ints"][2:4], [2, 3])
        self.assertEqual(reader.read(1), b"")
        message_id, raw = self.clients[1].payload()
        self.assertEqual(message_id, 20106)
        reader = BSMessageReader(raw)
        self.assertEqual(reader.read_byte(), 0)
        self.assertEqual(read_friend(reader)["ints"][2:4], [3, 3])
        self.assertEqual(reader.read(1), b"")

        duplicate = AddFriend(self.clients[0], first, int_payload(0, 2, 0, 0))
        duplicate.decode()
        duplicate.process()
        self.assertEqual(len(FriendService.friends(first)), 1)
        accept = AcceptFriendMessage(self.clients[1], second, int_payload(0, 1))
        accept.decode()
        accept.process()
        self.assertEqual(FriendService.friends(first)[0]["state"], 4)
        self.assertEqual(FriendService.friends(second)[0]["state"], 4)
        self.assertEqual(FriendService.friends(first)[0]["origin"], 3)
        self.assertEqual(FriendService.friends(second)[0]["origin"], 3)
        reloaded = self.reload(first)
        self.assertEqual([(entry["low_id"], entry["state"]) for entry in FriendService.friends(reloaded)], [(2, 4)])

        remove = RemoveFriendMessage(self.clients[0], first, int_payload(0, 2))
        remove.decode()
        remove.process()
        self.assertEqual(FriendService.friends(first), [])
        self.assertEqual(FriendService.friends(second), [])
        message_id, raw = self.clients[0].payload(-2)
        self.assertEqual(message_id, 20105)
        self.assertEqual(self.clients[0].payload()[0], 24555)
        reader = BSMessageReader(raw)
        self.assertEqual(reader.read_int(), 0)
        self.assertEqual(reader.read_byte(), 1)
        self.assertEqual(reader.read_int(), 0)
        self.assertEqual(reader.read(1), b"")
        message_id, raw = self.clients[1].payload(-2)
        self.assertEqual(message_id, 20105)
        self.assertEqual(self.clients[1].payload()[0], 24555)
        reader = BSMessageReader(raw)
        self.assertEqual(reader.read_int(), 0)
        self.assertEqual(reader.read_byte(), 1)
        self.assertEqual(reader.read_int(), 0)
        self.assertEqual(reader.read(1), b"")

    def test_friend_list_suggestions_and_club_wire(self):
        first, second, third = self.players
        with DataBase._connection() as connection:
            connection.execute(
                "INSERT INTO clubs(id, name, badge_id) VALUES(55, 'Native Friends', 12)"
            )
            connection.execute(
                "INSERT INTO club_members(club_id, player_id, role) VALUES(55, 2, 2)"
            )
            connection.execute("UPDATE players SET clubID = 55, clubRole = 2 WHERE lowID = 2")
        add = AddFriend(self.clients[0], first, int_payload(0, 2, 0, 0))
        add.decode()
        add.process()
        FriendListMessage(self.clients[0], first).send()
        message_id, raw = self.clients[0].payload()
        self.assertEqual(message_id, 20105)
        reader = BSMessageReader(raw)
        self.assertEqual(reader.read_int(), 0)
        self.assertEqual(reader.read_byte(), 1)
        self.assertEqual(reader.read_int(), 1)
        entry = read_friend(reader)
        self.assertEqual(reader.read(1), b"")
        self.assertEqual(entry["low_id"], 2)
        self.assertEqual(entry["strings"], ["Friend 2", "", "", ""])
        self.assertEqual(entry["ints"], [0, second.trophies, 2, 0, 0, 0])
        self.assertEqual(entry["club"]["low_id"], 55)
        self.assertEqual(entry["club"]["name"], "Native Friends")
        self.assertEqual(entry["profile_icon"], 28000002)

        entries = FriendService.suggestions(first)
        self.assertEqual([entry["low_id"] for entry in entries], [3])
        FriendSuggestionsMessage(self.clients[0], first, entries).send()
        message_id, raw = self.clients[0].payload()
        self.assertEqual(message_id, 20199)
        reader = BSMessageReader(raw)
        self.assertEqual(reader.read_int(), 1)
        self.assertEqual(reader.read_int(), 0)
        self.assertEqual(read_friend(reader)["low_id"], 3)
        self.assertEqual(reader.read(1), b"")
        AskForFriendSuggestionsMessage(self.clients[2], third, b"").process()
        self.assertEqual(self.clients[2].payload()[0], 20199)

    def test_addable_friends_and_facebook_persistence(self):
        first, second, _ = self.players
        connect = FacebookConnect(
            self.clients[1], second, facebook_payload("facebook-second", "secret-token")
        )
        connect.decode()
        connect.process()
        reloaded_second = self.reload(second)
        self.assertEqual(reloaded_second.FacebookID, "facebook-second")
        self.assertEqual(reloaded_second.FacebookToken, "secret-token")
        self.assertEqual(reloaded_second.IsFacebookLinked, 1)

        writer = Writer(None)
        writer.writeInt(1)
        writer.writeString("facebook-second")
        writer.writeInt(0)
        ask = AskForAddableFriendsMessage(self.clients[0], first, writer.buffer)
        ask.decode()
        entries = ask.process()
        self.assertEqual([entry["low_id"] for entry in entries], [2])
        message_id, raw = self.clients[0].payload()
        self.assertEqual(message_id, 20107)
        reader = BSMessageReader(raw)
        self.assertEqual(reader.read_int(), 1)
        self.assertEqual(reader.read_int(), 0)
        self.assertEqual(reader.read_int(), 2)
        self.assertEqual(reader.read_string(), "Friend 2")
        self.assertEqual(reader.read_int(), 1)
        self.assertEqual(reader.read_string(), "facebook-second")
        self.assertEqual(reader.read_string(), "")
        self.assertEqual(reader.read(1), b"")

        unlink = UnlinkFacebookAcount(
            self.clients[1], second, facebook_payload("facebook-second", "secret-token")
        )
        unlink.decode()
        unlink.process()
        self.assertEqual(FriendService.addable(first, ["facebook-second"], []), [])
        self.assertEqual(self.reload(second).FacebookID, "")

    def test_remove_rejects_missing_relation_without_friend_update(self):
        first, second, _ = self.players
        remove = RemoveFriendMessage(
            self.clients[0], first, int_payload(0, 2)
        )
        remove.decode()
        result = remove.process()
        self.assertFalse(result["removed"])
        self.assertEqual(FriendService.friends(first), [])
        self.assertEqual(FriendService.friends(second), [])
        self.assertEqual(self.clients[0].packets, [])
        self.assertEqual(self.clients[1].packets, [])
        with self.assertRaises(FriendError):
            FriendService.add(first, 2, 5)
        suggestion = next(
            entry for entry in FriendService.suggestions(first)
            if entry["low_id"] == 2
        )
        self.assertEqual(suggestion["state"], FriendService.SUGGESTION)
        self.assertEqual(FriendService.friends(first), [])

    def test_live_presence_updates_friend_wire_and_ignores_stale_database(self):
        first, second, _ = self.players
        FriendService.add(first, 2, 4)
        FriendService.accept(second, 1)
        clients = {
            "ClientCounts": 2,
            "Clients": {
                "1": {"SocketInfo": self.clients[0], "Crypto": None, "Lock": None, "Status": 1},
                "2": {"SocketInfo": self.clients[1], "Crypto": None, "Lock": None, "Status": 1},
            },
        }
        first.ClientDict = clients
        second.ClientDict = clients
        PresenceService.bind_clients(clients)
        self.addCleanup(PresenceService.bind_clients, None)
        writer = Writer(None).enable_native_v13()
        writer.writeVint(2)
        status = PlayerStatusMessage(self.clients[1], second, writer.buffer)
        status.decode()
        self.assertEqual(status.process(), 2)
        self.assertEqual(FriendService.friends(first)[0]["status"], 2)
        self.assertEqual([self.clients[0].payload(i)[0] for i in (-3, -2, -1)], [20105, 24555, 24555])
        message_id, raw = self.clients[0].payload(-3)
        self.assertEqual(message_id, 20105)
        reader = BSMessageReader(raw)
        self.assertEqual(reader.read_int(), 0)
        self.assertEqual(reader.read_byte(), 1)
        self.assertEqual(reader.read_int(), 1)
        entry = read_friend(reader)
        self.assertEqual(entry["low_id"], 2)
        self.assertEqual(entry["ints"], [2, second.trophies, 4, 4, 0, 0])
        self.assertEqual(reader.read(1), b"")
        del clients["Clients"]["2"]
        clients["ClientCounts"] = 1
        self.assertEqual(FriendService.friends(first)[0]["status"], 0)

    def test_reconnection_serializes_persistent_presence_with_old_disconnect(self):
        from main import Server
        from SCIDClient.GameSessions import GAME_SESSIONS
        server = Server("127.0.0.1", 0)
        self.addCleanup(server.server.close)
        self.addCleanup(PresenceService.bind_clients, None)
        self.addCleanup(GAME_SESSIONS.clear)
        old = self.players[0]
        new = self.reload(old)
        old.crypto = new.crypto = None
        old.online = new.online = 1
        old_socket, old_peer = socket.socketpair()
        new_socket, new_peer = socket.socketpair()
        for sock in (old_socket, old_peer, new_socket, new_peer):
            self.addCleanup(sock.close)
        server.register_client(old, old_socket)
        blocker = DataBase._connect()
        blocker.execute("BEGIN IMMEDIATE")
        errors = []
        started = threading.Event()
        def disconnect():
            try:
                started.set()
                self.assertTrue(PresenceService.set_status(old, 0, old_socket, persist=True))
            except Exception as error:
                errors.append(error)
        def reconnect():
            try:
                server.register_client(new, new_socket)
            except Exception as error:
                errors.append(error)
        first = threading.Thread(target=disconnect)
        second = threading.Thread(target=reconnect)
        try:
            first.start()
            self.assertTrue(started.wait(2))
            acquired = server.clients_lock.acquire(timeout=1)
            if acquired:
                server.clients_lock.release()
            self.assertFalse(acquired, "desconexão deveria aguardar o banco com o registro bloqueado")
            second.start()
        finally:
            blocker.rollback()
            blocker.close()
        first.join(5)
        if second.ident is not None:
            second.join(5)
        self.assertFalse(first.is_alive())
        self.assertFalse(second.is_alive())
        self.assertEqual(errors, [])
        self.assertIs(server.Clients["Clients"][str(old.low_id)]["Player"], new)
        self.assertEqual(server.Clients["Clients"][str(old.low_id)]["Status"], 1)
        with DataBase._connection() as connection:
            self.assertEqual(connection.execute(
                "SELECT online FROM players WHERE lowID = ?", (old.low_id,)
            ).fetchone()[0], 1)
        self.assertFalse(PresenceService.set_status(old, 0, old_socket, persist=True))
        self.assertEqual(self.reload(new).online, 1)

    def test_replaced_connection_cannot_overwrite_current_presence(self):
        player = self.players[0]
        old_client = self.clients[0]
        current_client = CaptureClient()
        clients = {
            "ClientCounts": 1,
            "Clients": {
                "1": {"SocketInfo": current_client, "Crypto": None, "Lock": None, "Status": 2},
            },
        }
        player.ClientDict = clients
        PresenceService.bind_clients(clients)
        self.addCleanup(PresenceService.bind_clients, None)
        DataBase.replaceValue(SimpleNamespace(player=player), "online", 2)
        writer = Writer(None).enable_native_v13()
        writer.writeVint(3)
        stale = PlayerStatusMessage(old_client, player, writer.buffer)
        stale.decode()
        original_online = player.online
        with self.assertRaises(ConnectionError):
            stale.process()
        self.assertEqual(player.online, original_online)
        self.assertEqual(PresenceService.status(1), 2)
        with DataBase._connection() as connection:
            self.assertEqual(
                connection.execute("SELECT online FROM players WHERE lowID = 1").fetchone()[0],
                2,
            )
        writer = Writer(None).enable_native_v13()
        writer.writeVint(1)
        current = PlayerStatusMessage(current_client, player, writer.buffer)
        current.decode()
        self.assertEqual(current.process(), 1)
        self.assertEqual(PresenceService.status(1), 1)

    def test_legacy_friend_ids_migrate_once_to_reciprocal_relations(self):
        first, second, _ = self.players
        first.Friends = {"0": {"lowID": 2}, "1": {"lowID": 2}}
        DataBase.replaceValue(SimpleNamespace(player=first), "Friends", first.Friends)
        entries = FriendService.friends(first)
        self.assertEqual([(entry["low_id"], entry["state"]) for entry in entries], [(2, 4)])
        self.assertEqual(FriendService.friends(second)[0]["state"], 4)
        self.assertEqual(first.Friends, {})
        with DataBase._connection() as connection:
            self.assertEqual(connection.execute("SELECT COUNT(*) FROM friend_relations").fetchone()[0], 2)
            stored = DataBase._read_state(connection, 1, "Friends")
        self.assertEqual(stored, {})
        self.assertEqual(len(FriendService.friends(first)), 1)


if __name__ == "__main__":
    unittest.main()
