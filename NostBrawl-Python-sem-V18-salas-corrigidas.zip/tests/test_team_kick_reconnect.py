import socket
import tempfile
import threading
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from Database.DatabaseManager import DataBase
from Logic.GameRoomService import GameRoomService
from Logic.Player import Players
from Logic.PresenceService import PresenceService
from SCIDClient.GameSessions import GAME_SESSIONS
from Utils.Writer import Writer
from main import ClientThread, Server
from test_protocol import packet, receive_packet


class KickReconnectTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        database = str(Path(temporary.name) / 'players.sqlite')
        resolved = str(Path(database).resolve())
        self.addCleanup(DataBase._initialized_paths.discard, resolved)
        route = patch.object(DataBase, '_database_path', lambda: database)
        route.start()
        self.addCleanup(route.stop)
        self.server = Server('127.0.0.1', 0)
        self.server.crypto_settings = {'Enabled': False}
        self.addCleanup(self.server.server.close)
        self.addCleanup(PresenceService.bind_clients, None)
        self.addCleanup(GAME_SESSIONS.clear)
        self.addCleanup(GameRoomService.init)
        GameRoomService.init()
        self.sockets = []
        self.addCleanup(self.close_sockets)
        self.addCleanup(self.cancel_timers)

    def pair(self):
        server_socket, peer = socket.socketpair()
        server_socket.settimeout(2)
        peer.settimeout(2)
        self.sockets.extend((server_socket, peer))
        return server_socket, peer

    def close_sockets(self):
        for connection in self.sockets:
            try:
                connection.close()
            except OSError:
                pass

    def cancel_timers(self):
        for key in list(self.server._season_timers):
            self.server._cancel_season_timer(key)

    def account(self, low_id, token):
        player = Players(SimpleNamespace())
        player.low_id = low_id
        player.token = token
        player.name = f'Account {low_id}'
        player.high_id = 0
        player.room_id = 0
        player.online = 1
        player.crypto = None
        player.logged_in = True
        DataBase.createAccount(SimpleNamespace(player=player))
        return player

    def test_crossed_kicks_acquire_account_locks_in_the_same_order(self):
        self.account(1002, 'host-two-token')
        self.account(1001, 'guest-one-token')
        host_socket, host_peer = self.pair()
        guest_socket, guest_peer = self.pair()
        host = ClientThread(host_socket, ('host-two', 0), self.server)
        guest = ClientThread(guest_socket, ('guest-one', 0), self.server)
        for thread, token, connection in (
            (host, 'host-two-token', host_socket),
            (guest, 'guest-one-token', guest_socket),
        ):
            thread.player.token = token
            self.assertTrue(DataBase.loadAccount(SimpleNamespace(player=thread.player)))
            thread.player.logged_in = True
            thread.player.online = 1
            self.server.register_client(thread.player, connection)
        room = GameRoomService.create(host.player, 0, 7, 0)
        GameRoomService.join(guest.player, room['id'])
        barrier = threading.Barrier(2)
        completed = threading.Event()
        processed = []
        lock_calls = {host: [], guest: []}
        call_lock = threading.Lock()
        original_lock = self.server.account_lock
        original_kick = GameRoomService.kick_transition
        def observe_lock(low_id):
            current = threading.current_thread()
            if current in lock_calls:
                with call_lock:
                    calls = lock_calls[current]
                    calls.append(int(low_id))
                    first = len(calls) == 1
                if first:
                    barrier.wait(2)
            return original_lock(low_id)
        def observed_kick(player, target_id):
            result = original_kick(player, target_id)
            with call_lock:
                processed.append(player.low_id)
                if len(processed) == 2:
                    completed.set()
            return result
        def payload(target):
            writer = Writer(None).enable_native_v13()
            writer.writeVint(0)
            writer.writeVint(target)
            return packet(14352, writer.buffer)
        with patch.object(self.server, 'account_lock', side_effect=observe_lock), \
             patch.object(GameRoomService, 'kick_transition', side_effect=observed_kick):
            host.start()
            guest.start()
            try:
                host_peer.sendall(payload(1001))
                guest_peer.sendall(payload(1002))
                self.assertTrue(completed.wait(3), 'Expulsões cruzadas não terminaram')
                self.assertEqual(lock_calls[host][:2], [1001, 1002])
                self.assertEqual(lock_calls[guest][:2], [1001, 1002])
                self.assertEqual(receive_packet(host_peer)[0], 24124)
                self.assertEqual(receive_packet(host_peer)[0], 24131)
                self.assertEqual(receive_packet(guest_peer)[0], 24125)
                self.assertEqual(GameRoomService.get(room['id'])['player_count'], 1)
            finally:
                host_peer.close()
                guest_peer.close()
                host.join(3)
                guest.join(3)
                self.assertFalse(host.is_alive())
                self.assertFalse(guest.is_alive())

    def test_kick_waits_for_target_reconnect_and_updates_current_session(self):
        self.account(1001, 'kick-host-token')
        guest = self.account(1002, 'kick-guest-token')
        host_socket, host_peer = self.pair()
        guest_socket, old_guest_peer = self.pair()
        new_guest_socket, new_guest_peer = self.pair()
        thread = ClientThread(host_socket, ('kick-host', 0), self.server)
        thread.player.token = 'kick-host-token'
        self.assertTrue(DataBase.loadAccount(SimpleNamespace(player=thread.player)))
        thread.player.logged_in = True
        thread.player.online = 1
        self.server.register_client(thread.player, host_socket)
        self.server.register_client(guest, guest_socket)
        room = GameRoomService.create(thread.player, 0, 7, 0)
        GameRoomService.join(guest, room['id'])
        replacement = Players(SimpleNamespace())
        replacement.token = guest.token
        self.assertTrue(DataBase.loadAccount(SimpleNamespace(player=replacement)))
        replacement.crypto = None
        replacement.online = 1
        replacement.logged_in = True
        waiting = threading.Event()
        original = self.server.account_lock
        def observe(low_id):
            if threading.current_thread() is thread and int(low_id) == 1002:
                waiting.set()
            return original(low_id)
        writer = Writer(None).enable_native_v13()
        writer.writeVint(0)
        writer.writeVint(1002)
        with patch.object(self.server, 'account_lock', side_effect=observe):
            thread.start()
            try:
                with original(1002):
                    host_peer.sendall(packet(14352, writer.buffer))
                    self.assertTrue(waiting.wait(2))
                    self.assertEqual(GameRoomService.get(room['id'])['player_count'], 2)
                    self.server.register_client(replacement, new_guest_socket)
                    GameRoomService.resume(replacement)
                self.assertEqual(receive_packet(host_peer)[0], 24124)
                self.assertEqual(receive_packet(host_peer)[0], 24131)
                self.assertEqual(receive_packet(new_guest_peer)[0], 24125)
                self.assertEqual(replacement.room_id, 0)
                self.assertEqual(GameRoomService.get(room['id'])['player_count'], 1)
                with DataBase._connection() as connection:
                    self.assertEqual(connection.execute(
                        'SELECT roomID FROM players WHERE lowID = ?', (1002,)
                    ).fetchone(), (0,))
                old_guest_peer.settimeout(0.05)
                with self.assertRaises(TimeoutError):
                    old_guest_peer.recv(1)
            finally:
                host_peer.close()
                thread.join(3)
                self.assertFalse(thread.is_alive())


if __name__ == '__main__':
    unittest.main()
