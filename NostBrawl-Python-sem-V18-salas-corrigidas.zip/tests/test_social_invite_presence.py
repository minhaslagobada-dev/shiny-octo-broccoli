import tempfile
import threading
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from Database.DatabaseManager import DataBase
from Logic.ClubService import ClubService
from Logic.FriendService import FriendService
from Logic.Player import Players
from Logic.PresenceService import PresenceService
from Packets.Messages.Server.Alliance.Alliance_Data_Message import AllianceDataMessage
from Packets.Messages.Server.Friend.FriendOnlineStatusEntryMessage import FriendOnlineStatusEntryMessage
from Utils.Reader import BSMessageReader


class Capture:
    def __init__(self):
        self.packets = []

    def sendall(self, data):
        self.packets.append(bytes(data))


class SignalingLock:
    def __init__(self, lock, entered):
        self.lock, self.entered = lock, entered

    def __enter__(self):
        self.entered.set()
        self.lock.acquire()
        return self

    def __exit__(self, *args):
        self.lock.release()


def status_packet(packet):
    assert int.from_bytes(packet[:2], 'big') == 24555
    assert int.from_bytes(packet[2:5], 'big') == len(packet) - 7
    reader = BSMessageReader(packet[7:]).enable_native_v13()
    account = (reader.read_int(), reader.read_int())
    present = reader.read_boolean()
    status = None
    if present:
        internal = (reader.read_int(), reader.read_int())
        status = (internal, reader.read_Vint(), reader.read_Vint(), reader.read_boolean())
    reader.ensure_end()
    return account, status


class SocialInvitePresenceTests(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        patcher = patch.object(DataBase, '_database_path', lambda: str(Path(temp.name) / 'accounts.sqlite'))
        patcher.start(); self.addCleanup(patcher.stop)
        self.registry = {'Clients': {}, 'RegistryLock': threading.RLock()}
        self.players = []
        self.captures = []
        for number in (71, 72, 73):
            player = Players(SimpleNamespace())
            player.low_id, player.high_id, player.name = number, 0, f'Jogador {number}'
            player.token = f'invite-presence-{number}'
            player.ClientDict = self.registry
            DataBase.createAccount(SimpleNamespace(player=player))
            client = Capture()
            self.registry['Clients'][str(number)] = {'SocketInfo': client, 'Lock': player.send_lock, 'Crypto': None, 'Player': player, 'Status': 1, 'StatusSince': 100}
            self.players.append(player); self.captures.append(client)
        PresenceService.bind_clients(self.registry)
        self.addCleanup(PresenceService.bind_clients, None)

    def test_accepted_friend_bootstrap_changes_and_removal(self):
        a, b, outsider = self.players
        FriendService.add(a, b.low_id)
        self.assertEqual(PresenceService.social_peers(a.low_id), [])
        FriendService.accept(b, a.low_id)
        with patch('Logic.PresenceService.time.time', return_value=130):
            self.assertEqual(PresenceService.sync_view(a), 1)
        self.assertEqual([status_packet(p) for p in self.captures[0].packets], [((0,72),None), ((0,72),((0,72),1,30,False))])
        self.assertEqual(self.captures[2].packets, [])
        self.captures[0].packets.clear()
        with patch('Logic.PresenceService.time.time', return_value=140):
            self.assertTrue(PresenceService.set_status(b, 8, self.captures[1]))
            self.assertTrue(PresenceService.sync_subject(b, b.low_id, a.low_id))
        self.assertEqual(status_packet(self.captures[0].packets[-1]), ((0,72),((0,72),8,0,False)))
        self.captures[0].packets.clear()
        FriendService.remove(a, b.low_id)
        self.assertTrue(PresenceService.sync_subject(b, b.low_id, a.low_id))
        self.assertEqual([status_packet(p) for p in self.captures[0].packets], [((0,72),None)])

    def test_club_member_without_friend_and_overlap(self):
        a,b,_ = self.players
        ClubService.create(a, 990071, 'Clube', '', 1, 1, 0, 0)
        ClubService.join(b, 990071)
        self.assertEqual(PresenceService.social_peers(a.low_id), [b.low_id])
        with patch('Logic.PresenceService.time.time', return_value=125):
            PresenceService.sync_pair(a, b.low_id)
        self.assertEqual(status_packet(self.captures[0].packets[-1]), ((0,72),((0,72),1,25,False)))
        FriendService.add(a, b.low_id); FriendService.accept(b, a.low_id)
        ClubService.leave(b)
        self.captures[0].packets.clear()
        PresenceService.sync_subject(a,b.low_id,a.low_id)
        self.assertIsNotNone(status_packet(self.captures[0].packets[-1])[1])
        FriendService.remove(a,b.low_id)
        self.captures[0].packets.clear()
        PresenceService.sync_subject(a,b.low_id,a.low_id)
        self.assertEqual([status_packet(p) for p in self.captures[0].packets], [((0,72),None)])

    def test_offline_and_replaced_session(self):
        a,b,_ = self.players
        FriendService.add(a, b.low_id); FriendService.accept(b,a.low_id)
        del self.registry['Clients'][str(b.low_id)]
        PresenceService.sync_subject(a,b.low_id,a.low_id)
        self.assertEqual([status_packet(p) for p in self.captures[0].packets], [((0,72),None)])
        self.assertFalse(PresenceService.set_status(b, 0, self.captures[1], persist=True))

    def test_club_wire_flag_own_or_other_and_override(self):
        a,b,_ = self.players
        ClubService.create(a, 990072, 'Clube', '', 1, 1, 0, 0)
        ClubService.join(b, 990072)
        for message, expected in ((AllianceDataMessage(None,a,0,990072),True), (AllianceDataMessage(None,self.players[2],0,990072),False), (AllianceDataMessage(None,self.players[2],0,990072,member_override=True),True)):
            reader=BSMessageReader(message._encode_payload()).enable_native_v13()
            self.assertEqual(reader.read_boolean(),expected)

    def test_club_snapshot_rechecks_membership_before_remote_delivery(self):
        owner, member, outsider = self.players
        ClubService.create(owner, 990073, 'Clube', '', 1, 1, 0, 0)
        ClubService.join(member, 990073)
        message = AllianceDataMessage(None, owner, 0, 990073, member_override=True)
        self.assertFalse(message.sendWithLowID(outsider.low_id))
        self.assertEqual(self.captures[2].packets, [])
        self.assertTrue(message.sendWithLowID(member.low_id))
        self.assertEqual(len(self.captures[1].packets), 1)
        entered, errors, result = threading.Event(), [], []
        self.registry['Clients'][str(member.low_id)]['Lock'] = SignalingLock(member.send_lock, entered)
        def deliver():
            try:
                result.append(message.sendWithLowID(member.low_id))
            except Exception as error:
                errors.append(error)
        with member.send_lock:
            worker = threading.Thread(target=deliver)
            worker.start()
            self.assertTrue(entered.wait(2))
            ClubService.leave(member)
        worker.join(2)
        self.assertFalse(worker.is_alive())
        self.assertEqual(errors, [])
        self.assertEqual(result, [False])
        self.assertEqual(len(self.captures[1].packets), 1)

    def test_delayed_status_checks_current_relationship(self):
        a, b, _ = self.players
        FriendService.add(a, b.low_id); FriendService.accept(b, a.low_id)
        entered = threading.Event()
        self.registry['Clients'][str(a.low_id)]['Lock'] = SignalingLock(a.send_lock, entered)
        errors = []
        def send():
            try:
                PresenceService.sync_subject(b, b.low_id, a.low_id)
            except Exception as error:
                errors.append(error)
        with a.send_lock:
            worker = threading.Thread(target=send)
            worker.start()
            self.assertTrue(entered.wait(2))
            FriendService.remove(a, b.low_id)
        worker.join(2)
        self.assertFalse(worker.is_alive())
        self.assertEqual(errors, [])
        self.assertEqual([status_packet(p) for p in self.captures[0].packets], [((0,72),None)])

    def test_delayed_status_does_not_send_to_superseded_socket(self):
        a, b, _ = self.players
        FriendService.add(a, b.low_id); FriendService.accept(b, a.low_id)
        entered = threading.Event()
        self.registry['Clients'][str(a.low_id)]['Lock'] = SignalingLock(a.send_lock, entered)
        outcome = []
        def send():
            outcome.append(PresenceService.sync_subject(b, b.low_id, a.low_id))
        with a.send_lock:
            worker = threading.Thread(target=send)
            worker.start()
            self.assertTrue(entered.wait(2))
            with self.registry['RegistryLock']:
                self.registry['Clients'][str(a.low_id)] = {'SocketInfo': Capture(), 'Lock': threading.RLock(), 'Status': 1}
        worker.join(2)
        self.assertFalse(worker.is_alive())
        self.assertEqual(outcome, [False])
        self.assertEqual(self.captures[0].packets, [])

    def test_generic_delivery_does_not_use_replaced_session_after_wait(self):
        from Packets.Messages.Server.Friend.FriendListMessage import FriendListMessage
        a, b, _ = self.players
        FriendService.add(a, b.low_id); FriendService.accept(b, a.low_id)
        entered = threading.Event()
        self.registry['Clients'][str(a.low_id)]['Lock'] = SignalingLock(a.send_lock, entered)
        outcome, errors = [], []
        def send():
            try:
                outcome.append(FriendListMessage(None, b, refresh=True).sendWithLowID(a.low_id))
            except Exception as error:
                errors.append(error)
        with a.send_lock:
            worker = threading.Thread(target=send)
            worker.start()
            self.assertTrue(entered.wait(2))
            with self.registry['RegistryLock']:
                self.registry['Clients'][str(a.low_id)] = {'SocketInfo': Capture(), 'Lock': threading.RLock(), 'Status': 1}
        worker.join(2)
        self.assertFalse(worker.is_alive())
        self.assertEqual(errors, [])
        self.assertEqual(outcome, [False])
        self.assertEqual(self.captures[0].packets, [])

    def test_status_pair_uses_recipient_v13_session_and_order(self):
        from Core import NaCl19
        from Core.Crypto import Crypto, Nonce
        a, b, _ = self.players
        FriendService.add(a, b.low_id); FriendService.accept(b, a.low_id)
        crypto = Crypto({'Enabled': True})
        crypto.decryptNonce = Nonce(bytes(range(24)))
        crypto.encryptNonce = Nonce(bytes(range(24, 48)))
        crypto.shared_en = bytes(range(32))
        crypto.login_completed = True
        self.registry['Clients'][str(a.low_id)]['Crypto'] = crypto
        with patch('Logic.PresenceService.time.time', return_value=110):
            self.assertTrue(PresenceService.sync_subject(b, b.low_id, a.low_id))
        nonce = Nonce(bytes(range(24, 48)))
        decoded = []
        for packet in self.captures[0].packets:
            nonce.increment()
            raw = NaCl19.secretbox_open(packet[7:], bytes(nonce), crypto.shared_en)
            decoded.append(status_packet(packet[:2] + len(raw).to_bytes(3, 'big') + packet[5:7] + raw))
        self.assertEqual(decoded, [((0,72),None), ((0,72),((0,72),1,10,False))])

    def test_status_wire_rejects_invalid_account(self):
        with self.assertRaises(ValueError):
            FriendOnlineStatusEntryMessage(None, self.players[0], 0)

if __name__ == '__main__':
    unittest.main()
