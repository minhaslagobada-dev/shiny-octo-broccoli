import unittest
from types import SimpleNamespace

from Logic.FriendPayload import encode_friend_entry
from Packets.Messages.Server.Gameroom.TeamGameroomDataMessage import TeamGameroomDataMessage
from Utils.Writer import Writer


class TeamRequestWireTests(unittest.TestCase):
    def test_request_identifiers_do_not_use_room_id(self):
        entry = dict(high_id=0, low_id=42, name='Requester', facebook_id='',
                     game_center_id='', state=4, origin=0, status=3,
                     trophies=450, profile_icon=28000007, club=None,
                     last_seen_seconds=0)
        request = dict(key_high_id=3, key=2345, recipient_high_id=4,
                       recipient_id=42, entry=entry)
        room = dict(id=99, type=0, slot_index=0, map_id=7, practice=False,
                    capacity=6, advertise_band=False, advertise_friends=True,
                    members=[], invites=[], join_requests=[request])
        payload = TeamGameroomDataMessage(None, SimpleNamespace(), room)._encode_payload()
        tail = Writer(None).enable_native_v13()
        tail.writeVint(1)
        tail.writeLong(3, 2345)
        tail.writeLong(4, 42)
        encode_friend_entry(tail, entry)
        self.assertTrue(payload.endswith(tail.buffer))

    def test_missing_response_identifier_is_not_replaced_by_room_id(self):
        request = dict(recipient_id=42, entry={})
        room = dict(id=99, type=0, slot_index=0, map_id=7, practice=False,
                    capacity=6, advertise_band=False, advertise_friends=True,
                    members=[], invites=[], join_requests=[request])
        with self.assertRaises(KeyError):
            TeamGameroomDataMessage(None, SimpleNamespace(), room)._encode_payload()


if __name__ == '__main__':
    unittest.main()
