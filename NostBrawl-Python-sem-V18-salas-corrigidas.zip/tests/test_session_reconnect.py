import socket
import tempfile
import threading
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from Database.DatabaseManager import DataBase
from Logic.Player import Players
from Logic.ClubService import ClubService
from Logic.PresenceService import PresenceService
from Logic.SeasonService import SeasonService
from SCIDClient.GameSessions import GAME_SESSIONS
from main import Server, ClientThread


class ReconnectionTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        database = str(Path(temporary.name) / 'sessions.sqlite')
        route = patch.object(DataBase, '_database_path', lambda: database)
        route.start()
        self.addCleanup(route.stop)
        self.server = Server('127.0.0.1', 0)
        self.addCleanup(self.server.server.close)
        self.addCleanup(PresenceService.bind_clients, None)
        self.addCleanup(GAME_SESSIONS.clear)
        self.old = Players(SimpleNamespace())
        self.old.low_id = 1001
        self.old.name = 'Account'
        self.old.token = 'reconnect-token'
        self.old.crypto = None
        self.old.online = 1
        DataBase.createAccount(SimpleNamespace(player=self.old))
        self.old.logged_in = True
        SeasonService.sync(self.old)
        self.new = Players(SimpleNamespace())
        self.new.token = self.old.token
        self.assertTrue(DataBase.loadAccount(SimpleNamespace(player=self.new)))
        self.new.crypto = None
        self.new.online = 1
        self.new.logged_in = True
        self.sockets = []
        self.peers = []
        for _ in range(2):
            client, peer = socket.socketpair()
            self.addCleanup(client.close)
            self.addCleanup(peer.close)
            self.sockets.append(client)
            self.peers.append(peer)
        self.addCleanup(self.cancel_timers)

    def cancel_timers(self):
        for key in list(self.server._season_timers):
            self.server._cancel_season_timer(key)

    def launch(self, function, errors):
        def run():
            try: function()
            except Exception as error: errors.append(error)
        thread = threading.Thread(target=run)
        thread.start()
        return thread

    def assert_threads_end(self, threads, errors):
        for thread in threads:
            thread.join(5)
            self.assertFalse(thread.is_alive())
        self.assertEqual(errors, [])

    def test_registration_and_removal_wait_for_inflight_recipient_send(self):
        from Utils.Writer import Writer

        class GateLock:
            def __init__(self, lock, attempted):
                self.lock, self.attempted = lock, attempted
            def __enter__(self):
                self.attempted.set()
                self.lock.acquire()
                return self
            def __exit__(self, *args):
                self.lock.release()

        class Packet(Writer):
            def __init__(self, sender, entered, release):
                super().__init__(None)
                self.id, self.player = 20105, sender
                self.entered, self.release = entered, release
            def encode(self):
                self.entered.set()
                if not self.release.wait(3):
                    raise TimeoutError('envio bloqueado')
                self.writeInt(123)

        for remove in (False, True):
            with self.subTest(remove=remove):
                self.server.register_client(self.old, self.sockets[0])
                entered, release, attempted = threading.Event(), threading.Event(), threading.Event()
                self.server.Clients['Clients']['1001']['Lock'] = GateLock(self.old.send_lock, attempted)
                packet, errors, result = Packet(self.old, entered, release), [], []
                sender = self.launch(lambda: result.append(packet.sendWithLowID(1001)), errors)
                changer = None
                try:
                    self.assertTrue(entered.wait(2))
                    attempted.clear()
                    if remove:
                        action = lambda: self.server.unregister_client(self.old, self.sockets[0])
                    else:
                        action = lambda: self.server.register_client(self.new, self.sockets[1])
                    changer = self.launch(action, errors)
                    self.assertTrue(attempted.wait(2))
                    self.assertIs(self.server.Clients['Clients']['1001']['SocketInfo'], self.sockets[0])
                finally:
                    release.set()
                self.assert_threads_end([sender, changer], errors)
                self.assertEqual(result, [True])
                self.peers[0].settimeout(1)
                self.assertEqual(self.peers[0].recv(11), bytes.fromhex('4e8900000400000000007b'))
                current = self.server.Clients['Clients'].get('1001')
                if remove:
                    self.assertIsNone(current)
                else:
                    self.assertIs(current['SocketInfo'], self.sockets[1])
                    self.server.unregister_client(self.new, self.sockets[1])

    def test_delayed_old_schedule_cannot_replace_new_session_timer(self):
        entered, release = threading.Event(), threading.Event()
        original = SeasonService.sync
        errors = []
        def sync(player, *args, **kwargs):
            result = original(player, *args, **kwargs)
            if player is self.old:
                entered.set()
                if not release.wait(3): raise TimeoutError('sincronização anterior bloqueada')
            return result
        with patch.object(SeasonService, 'sync', side_effect=sync):
            first = self.launch(lambda: self.server.register_client(self.old, self.sockets[0]), errors)
            second = None
            try:
                self.assertTrue(entered.wait(2))
                second = self.launch(lambda: self.server.register_client(self.new, self.sockets[1]), errors)
                self.assertFalse(self.server.account_lock(1001).acquire(timeout=0.1))
            finally:
                release.set()
            self.assert_threads_end([first, second], errors)
        new_timer = self.server._season_timers['1001']
        self.assertIs(new_timer.session_client, self.sockets[1])
        self.assertIs(GAME_SESSIONS._sessions[1001]['client'], self.sockets[1])
        self.server.unregister_client(self.old, self.sockets[0])
        self.assertIs(self.server._season_timers['1001'], new_timer)
        self.assertIs(GAME_SESSIONS._sessions[1001]['client'], self.sockets[1])

    def test_old_disconnect_cannot_cancel_replacement_timer(self):
        self.server.register_client(self.old, self.sockets[0])
        entered, release = threading.Event(), threading.Event()
        original = self.server._cancel_season_timer
        errors = []
        def cancel(key, client=None):
            if client is self.sockets[0]:
                entered.set()
                if not release.wait(3): raise TimeoutError('cancelamento bloqueado')
            return original(key, client)
        with patch.object(self.server, '_cancel_season_timer', side_effect=cancel):
            first = self.launch(lambda: self.server.unregister_client(self.old, self.sockets[0]), errors)
            second = None
            try:
                self.assertTrue(entered.wait(2))
                second = self.launch(lambda: self.server.register_client(self.new, self.sockets[1]), errors)
                self.assertFalse(self.server.clients_lock.acquire(timeout=0.1))
            finally:
                release.set()
            self.assert_threads_end([first, second], errors)
        self.assertIs(self.server._season_timers['1001'].session_client, self.sockets[1])
        self.assertIs(GAME_SESSIONS._sessions[1001]['client'], self.sockets[1])

    def test_club_refresh_and_reconnect_use_current_persisted_membership(self):
        owner = Players(SimpleNamespace())
        owner.low_id = 1002
        owner.name = 'Owner'
        owner.token = 'owner-token'
        owner.crypto = None
        DataBase.createAccount(SimpleNamespace(player=owner))
        ClubService.create(owner, 100002, 'Club', '', 1, 1, 0, 0)
        ClubService.join(self.old, 100002)
        self.new.club_low_id = 0
        self.new.club_role = 0
        self.server.register_client(self.old, self.sockets[0])
        with DataBase._connection() as connection:
            connection.execute('UPDATE club_members SET role = 3 WHERE player_id = ?', (1001,))
            connection.execute('UPDATE players SET clubRole = 3 WHERE lowID = ?', (1001,))
        entered, release = threading.Event(), threading.Event()
        original = ClubService._membership
        errors = []
        def membership(connection, account):
            if account == 1001 and threading.current_thread().name == 'club-refresh-test':
                entered.set()
                if not release.wait(3): raise TimeoutError('leitura de clube bloqueada')
            return original(connection, account)
        def refresh():
            try: ClubService.refresh_online_player(self.old, 1001)
            except Exception as error: errors.append(error)
        with patch.object(ClubService, '_membership', side_effect=membership):
            first = threading.Thread(target=refresh, name='club-refresh-test')
            first.start()
            second = None
            try:
                self.assertTrue(entered.wait(2))
                second = self.launch(lambda: self.server.register_client(self.new, self.sockets[1]), errors)
                self.assertFalse(self.server.clients_lock.acquire(timeout=0.1))
            finally:
                release.set()
            self.assert_threads_end([first, second], errors)
        self.assertIs(self.server.Clients['Clients']['1001']['Player'], self.new)
        self.assertEqual((self.new.club_low_id, self.new.club_role), (100002, 3))

    def test_scid_callback_waiting_for_relogin_targets_current_session(self):
        from SCIDClient.Runtime import get_service, set_service
        from Logic.NotificationFactory import NotificationFactory
        from test_protocol import receive_packet
        previous_service = get_service()
        self.addCleanup(set_service, previous_service)
        set_service(SimpleNamespace(store=SimpleNamespace(by_game=lambda low_id: object())))
        self.server.register_client(self.old, self.sockets[0])
        waiting = threading.Event()
        errors = []
        results = []
        original_lock = self.server.account_lock
        def observed_lock(low_id):
            waiting.set()
            return original_lock(low_id)
        GAME_SESSIONS._sessions[1001]['account_lock'] = observed_lock
        with self.server.account_lock(1001):
            worker = self.launch(lambda: results.append(GAME_SESSIONS.notify_registration(1001)), errors)
            self.assertTrue(waiting.wait(2))
            self.server.register_client(self.new, self.sockets[1])
        self.assert_threads_end([worker], errors)
        self.assertEqual(results, [True])
        self.peers[1].settimeout(2)
        self.assertEqual(receive_packet(self.peers[1])[0], 24111)
        self.peers[0].settimeout(0.1)
        with self.assertRaises(socket.timeout):
            self.peers[0].recv(1)
        self.assertTrue(any(skin == NotificationFactory.WIZARD_BARLEY_SKIN_ID
            for _, skin in NotificationFactory._entries(self.new.Notifications)))
        loaded = Players(SimpleNamespace())
        loaded.token = self.old.token
        self.assertTrue(DataBase.loadAccount(SimpleNamespace(player=loaded)))
        self.assertTrue(any(skin == NotificationFactory.WIZARD_BARLEY_SKIN_ID
            for _, skin in NotificationFactory._entries(loaded.Notifications)))

    def test_other_account_can_register_while_first_account_is_busy(self):
        other = Players(self.server.Clients)
        other.low_id = 1002
        other.token = 'other-token'
        other.crypto = None
        other.logged_in = True
        other.online = 1
        other.CreateClub = 0
        other.token_doubler = 0
        other.selected_brawler = 0
        other.gems = 0
        DataBase.createAccount(SimpleNamespace(player=other))
        errors = []
        finished = threading.Event()
        def register_other():
            self.server.register_client(other, self.sockets[1])
            finished.set()
        with self.server.account_lock(1001):
            worker = self.launch(register_other, errors)
            self.assertTrue(finished.wait(2), f'outra conta ficou bloqueada ou falhou: {errors!r}')
            self.assertIs(self.server.Clients['Clients']['1002']['SocketInfo'], self.sockets[1])
        self.assert_threads_end([worker], errors)

    def test_login_rejects_nonzero_high_id_for_existing_local_account(self):
        from test_protocol import login_payload, packet, receive_packet
        from SCIDClient.Game import SCIDGame
        self.server.crypto_settings = {'Enabled': False}
        DataBase.replaceValue(SimpleNamespace(player=self.old), 'online', 0)
        server_socket, peer = socket.socketpair()
        self.addCleanup(server_socket.close)
        self.addCleanup(peer.close)
        peer.settimeout(2)
        thread = ClientThread(server_socket, ('high-id-login', 0), self.server)
        with patch.object(SCIDGame, 'enabled', return_value=False):
            thread.start()
            try:
                peer.sendall(packet(10100))
                self.assertEqual(receive_packet(peer)[0], 20100)
                payload = login_payload(1001, self.old.token)
                payload = (1).to_bytes(4, 'big') + payload[4:]
                peer.sendall(packet(10101, payload))
                self.assertEqual(receive_packet(peer)[0], 20103)
                self.assertFalse(thread.player.logged_in)
                self.assertNotIn('1001', self.server.Clients['Clients'])
                with DataBase._connection() as connection:
                    self.assertEqual(connection.execute(
                        'SELECT online FROM players WHERE lowID = ?', (1001,)
                    ).fetchone(), (0,))
            finally:
                peer.close()
                thread.join(3)
                self.assertFalse(thread.is_alive())

    def test_failed_home_send_does_not_mark_unregistered_account_online(self):
        from Packets.Messages.Client.Login.LoginMessage import LoginMessage
        from Packets.Messages.Server.Home.OwnHomeDataMessage import OwnHomeDataMessage
        from test_protocol import login_payload, receive_packet
        DataBase.replaceValue(SimpleNamespace(player=self.old), 'online', 0)
        self.server.crypto_settings = {'Enabled': False}
        server_socket, peer = socket.socketpair()
        self.addCleanup(server_socket.close)
        self.addCleanup(peer.close)
        peer.settimeout(2)
        thread = ClientThread(server_socket, ('failed-login', 0), self.server)
        message = LoginMessage(server_socket, thread.player, login_payload(1001, self.old.token))
        message.decode()
        with patch.object(OwnHomeDataMessage, 'send', side_effect=BrokenPipeError('falha de envio')):
            with self.assertRaises(BrokenPipeError):
                thread._finish_login(message)
        self.assertEqual(receive_packet(peer)[0], 20104)
        self.assertFalse(thread.player.logged_in)
        self.assertNotIn('1001', self.server.Clients['Clients'])
        with DataBase._connection() as connection:
            self.assertEqual(connection.execute('SELECT online FROM players WHERE lowID = 1001').fetchone(), (0,))

    def test_authenticated_packet_completes_before_relogin_and_old_socket_is_rejected(self):
        from test_protocol import login_payload, packet, receive_packet
        import main
        from SCIDClient.Game import SCIDGame
        entered = threading.Event()
        release = threading.Event()
        new_login_waiting = threading.Event()
        new_registered = threading.Event()
        completed = []
        self.server.crypto_settings = {"Enabled": False}

        class BlockingAction:
            def __init__(self, client, player, payload):
                self.player = player
            def decode(self):
                return None
            def process(self):
                entered.set()
                if not release.wait(3):
                    raise TimeoutError('pacote antigo bloqueado')
                DataBase.replaceValue(self, 'name', 'Updated')
                self.player.name = 'Updated'
                completed.append(self.player.low_id)

        original_account_lock = self.server.account_lock
        original_register = self.server.register_client
        def account_lock(low_id):
            if threading.current_thread() is newer and int(low_id) == 1001:
                new_login_waiting.set()
            return original_account_lock(low_id)
        def register(player, client, address=None):
            result = original_register(player, client, address)
            if newer.client is client:
                new_registered.set()
            return result
        endpoints = []
        for _ in range(2):
            server_socket, peer = socket.socketpair()
            peer.settimeout(2)
            endpoints.append((server_socket, peer))
            self.addCleanup(server_socket.close)
            self.addCleanup(peer.close)
        old_thread = ClientThread(endpoints[0][0], ('old', 0), self.server)
        newer = ClientThread(endpoints[1][0], ('new', 0), self.server)
        with patch.dict(main.packets, {19999: BlockingAction}), \
             patch.object(SCIDGame, 'enabled', return_value=False), \
             patch.object(self.server, 'account_lock', side_effect=account_lock), \
             patch.object(self.server, 'register_client', side_effect=register):
            old_thread.start()
            newer.start()
            try:
                old_peer, new_peer = endpoints[0][1], endpoints[1][1]
                for peer in (old_peer, new_peer):
                    peer.sendall(packet(10100))
                    self.assertEqual(receive_packet(peer)[0], 20100)
                old_peer.sendall(packet(10101, login_payload(1001, self.old.token)))
                self.assertEqual(receive_packet(old_peer)[0], 20104)
                self.assertEqual(receive_packet(old_peer)[0], 24101)
                old_peer.sendall(packet(19999))
                self.assertTrue(entered.wait(3))
                new_peer.sendall(packet(10101, login_payload(1001, self.old.token)))
                self.assertTrue(new_login_waiting.wait(3))
                self.assertIs(self.server.Clients['Clients']['1001']['SocketInfo'], old_thread.client)
                release.set()
                self.assertEqual(receive_packet(new_peer)[0], 20104)
                self.assertEqual(receive_packet(new_peer)[0], 24101)
                self.assertTrue(new_registered.wait(3))
                self.assertEqual(self.server.Clients['Clients']['1001']['Player'].name, 'Updated')
                old_peer.sendall(packet(19999))
                old_thread.join(3)
                self.assertFalse(old_thread.is_alive())
                self.assertEqual(completed, [1001])
                self.assertIs(self.server.Clients['Clients']['1001']['SocketInfo'], newer.client)
                with DataBase._connection() as connection:
                    self.assertEqual(connection.execute('SELECT online, name FROM players WHERE lowID = 1001').fetchone(), (2, 'Updated'))
            finally:
                release.set()
                for _, peer in endpoints:
                    try: peer.close()
                    except OSError: pass
                old_thread.join(3)
                newer.join(3)

    def test_game_session_registration_cannot_be_reordered(self):
        entered, release = threading.Event(), threading.Event()
        original = GAME_SESSIONS.register
        errors = []
        def register(player, client, address=None):
            if player is self.old:
                entered.set()
                if not release.wait(3): raise TimeoutError('registro bloqueado')
            return original(player, client, address)
        with patch.object(GAME_SESSIONS, 'register', side_effect=register):
            first = self.launch(lambda: self.server.register_client(self.old, self.sockets[0]), errors)
            second = None
            try:
                self.assertTrue(entered.wait(2))
                second = self.launch(lambda: self.server.register_client(self.new, self.sockets[1]), errors)
                self.assertFalse(self.server.clients_lock.acquire(timeout=0.1))
            finally:
                release.set()
            self.assert_threads_end([first, second], errors)
        self.assertIs(self.server.Clients['Clients']['1001']['SocketInfo'], self.sockets[1])
        self.assertIs(GAME_SESSIONS._sessions[1001]['client'], self.sockets[1])
        self.assertIs(self.server._season_timers['1001'].session_client, self.sockets[1])


if __name__ == '__main__':
    unittest.main()
