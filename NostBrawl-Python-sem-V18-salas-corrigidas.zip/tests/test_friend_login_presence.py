import socket
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from Database.DatabaseManager import DataBase
from Logic.FriendService import FriendService
from Logic.GameRoomService import GameRoomService
from Logic.Player import Players
from Logic.PresenceService import PresenceService
from SCIDClient.Game import SCIDGame
from SCIDClient.GameSessions import GAME_SESSIONS
from Utils.Reader import BSMessageReader
from Utils.Writer import Writer
from main import ClientThread, Server
from test_friends import read_friend
from test_protocol import login_payload, packet, receive_packet


def read_list(raw):
    reader = BSMessageReader(raw)
    if reader.read_int() != 0 or reader.read_byte() != 1:
        raise AssertionError('Cabeçalho inesperado da lista de amigos')
    entries = [read_friend(reader) for _ in range(reader.read_int())]
    reader.ensure_end()
    return entries


class FriendLoginPresenceTests(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        database = str(Path(temp.name) / 'accounts.sqlite')
        route = patch.object(DataBase, '_database_path', lambda: database)
        route.start()
        self.addCleanup(route.stop)
        scid = patch.object(SCIDGame, 'enabled', return_value=False)
        scid.start()
        self.addCleanup(scid.stop)
        self.server = Server('127.0.0.1', 0)
        self.server.crypto_settings = {'Enabled': False}
        self.addCleanup(self.server.server.close)
        self.addCleanup(PresenceService.bind_clients, None)
        self.addCleanup(GAME_SESSIONS.clear)
        GameRoomService.init()
        self.addCleanup(GameRoomService.init)
        self.players = []
        self.threads = []
        self.peers = []
        self.addCleanup(self.close_sessions)
        for number in (201, 202):
            player = Players(SimpleNamespace())
            player.low_id = number
            player.name = 'Amigo ' + str(number)
            player.token = 'socket-friend-' + str(number)
            DataBase.createAccount(SimpleNamespace(player=player))
            self.players.append(player)
        FriendService.add(self.players[0], 202)
        FriendService.accept(self.players[1], 201)

    def close_sessions(self):
        for peer in self.peers:
            try: peer.close()
            except OSError: pass
        for thread in self.threads:
            thread.join(4)
            if thread.is_alive():
                raise AssertionError('Sessão não terminou')
        for key in list(self.server._season_timers):
            self.server._cancel_season_timer(key)

    def login(self, index):
        server_socket, peer = socket.socketpair()
        peer.settimeout(5)
        self.peers.append(peer)
        thread = ClientThread(server_socket, ('test', index), self.server)
        self.threads.append(thread)
        thread.start()
        peer.sendall(packet(10100))
        self.assertEqual(receive_packet(peer)[0], 20100)
        player = self.players[index]
        peer.sendall(packet(10101, login_payload(player.low_id, player.token)))
        self.assertEqual(receive_packet(peer)[0], 20104)
        self.assertEqual(receive_packet(peer)[0], 24101)
        packet_id, _, raw = receive_packet(peer)
        self.assertEqual(packet_id, 20105)
        entries = read_list(raw)
        self.assertEqual(self.read_presence(peer), (entries[0]['low_id'], None))
        if entries[0]['ints'][0] not in (0, 6):
            self.assertEqual(self.read_presence(peer), (entries[0]['low_id'], entries[0]['ints'][0]))
        return peer, entries

    def read_presence(self, peer):
        packet_id, _, raw = receive_packet(peer)
        self.assertEqual(packet_id, 24555)
        reader = BSMessageReader(raw).enable_native_v13()
        self.assertEqual(reader.read_int(), 0)
        low_id = reader.read_int()
        status = None
        if reader.read_boolean():
            self.assertEqual((reader.read_int(), reader.read_int()), (0, low_id))
            status = reader.read_Vint()
            self.assertGreaterEqual(reader.read_Vint(), 0)
            self.assertFalse(reader.read_boolean())
        reader.ensure_end()
        return low_id, status

    def read_update(self, peer):
        packet_id, _, raw = receive_packet(peer)
        self.assertEqual(packet_id, 20105)
        entries = read_list(raw)
        self.assertEqual(len(entries), 1)
        account, status = entries[0]['low_id'], entries[0]['ints'][0]
        self.assertEqual(self.read_presence(peer), (account, None))
        if status not in (0, 6):
            self.assertEqual(self.read_presence(peer), (account, status))
        return entries[0]

    def change_status(self, peer, value):
        writer = Writer(None).enable_native_v13()
        writer.writeVint(value)
        peer.sendall(packet(14366, writer.buffer))

    def test_two_authenticated_logins_and_presence_in_both_directions(self):
        first, first_list = self.login(0)
        self.assertEqual(len(first_list), 1)
        self.assertEqual((first_list[0]['low_id'], first_list[0]['ints'][0], first_list[0]['ints'][2]), (202, 0, 4))
        second, second_list = self.login(1)
        self.assertEqual(len(second_list), 1)
        self.assertEqual((second_list[0]['low_id'], second_list[0]['ints'][0], second_list[0]['ints'][2]), (201, 2, 4))
        update = self.read_update(first)
        self.assertEqual((update['low_id'], update['ints'][0], update['ints'][2]), (202, 2, 4))
        self.change_status(second, 1)
        self.assertEqual(self.read_update(first)['ints'][0], 1)
        self.change_status(first, 3)
        self.assertEqual(self.read_update(second)['ints'][0], 3)
        second.close()
        self.assertEqual(self.read_update(first)['ints'][0], 0)

    def team_packets(self, peer):
        found = []
        while len(found) < 2:
            packet_id, _, _ = receive_packet(peer)
            if packet_id in (20105, 20106, 24555):
                continue
            found.append(packet_id)
        return found

    def test_online_friend_receives_and_accepts_team_invitation(self):
        first, _ = self.login(0)
        second, second_list = self.login(1)
        self.assertEqual((second_list[0]['low_id'], second_list[0]['ints'][0]), (201, 2))
        self.assertEqual(self.read_update(first)['ints'][0], 2)
        create = Writer(None).enable_native_v13()
        for value in (7, 0, 0):
            create.writeVint(value)
        create.writeBoolean(False)
        first.sendall(packet(14350, create.buffer))
        self.assertEqual([receive_packet(first)[0] for _ in range(2)], [24124, 24131])
        invite = Writer(None).enable_native_v13()
        for value in (0, 202, 0):
            invite.writeVint(value)
        first.sendall(packet(14365, invite.buffer))
        self.assertEqual(receive_packet(first)[0], 24124)
        while True:
            packet_id, _, payload = receive_packet(second)
            if packet_id == 24589:
                break
            self.assertIn(packet_id, (20105, 20106, 24555, 24124))
        reader = BSMessageReader(payload).enable_native_v13()
        self.assertEqual(reader.read_Vint(), 1)
        self.assertEqual((reader.read_int(), reader.read_int()), (0, 201))
        sender = read_friend(reader)
        self.assertEqual((sender['low_id'], sender['ints'][0], sender['ints'][2]), (201, 3, 4))
        reader.ensure_end()
        response = Writer(None).enable_native_v13()
        response.writeVint(1)
        response.writeInt(0)
        response.writeInt(sender['low_id'])
        response.writeBoolean(False)
        second.sendall(packet(14479, response.buffer))
        self.assertEqual(self.team_packets(second), [24124, 24131])
        self.assertEqual(self.team_packets(first), [24124, 24131])
        room = next(
            item for item in GameRoomService.get_rooms()
            if any(member['low_id'] == 201 for member in item['members'])
        )
        self.assertEqual({member['low_id'] for member in room['members']}, {201, 202})


if __name__ == '__main__':
    unittest.main()
