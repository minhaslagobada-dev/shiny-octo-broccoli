import os
import socket
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch


PROJECT_ROOT = Path(__file__).resolve().parents[1]
os.chdir(PROJECT_ROOT)
sys.path.insert(0, str(PROJECT_ROOT))

from Logic.Battle.BattleParticipants import BattleParticipants
from Logic.Battle.Game.LogicCharacter import LogicCharacter
from Logic.GameRoomService import GameRoomService
from Logic.Player import Players
from Logic.TeamCode import TeamCode
from Packets.LogicMessageFactory import packets
from Packets.Messages.Client.Gameroom.TeamJoinOrCreateRoomMessage import TeamJoinOrCreateRoomMessage
from Packets.Messages.Client.Gameroom.TeamSetMemberReadyMessage import TeamSetMemberReadyMessage
from Packets.Messages.Server.Battle.StartLoadingMessage import StartLoadingMessage
from Packets.Messages.Server.Battle.VisionUpdateMessage import VisionUpdateMessage
from Utils.Reader import BSMessageReader
from Utils.Writer import Writer


def native_writer():
    return Writer(None).enable_native_v13()


def native_reader(payload):
    return BSMessageReader(payload).enable_native_v13()


def receive_exact(connection, length):
    data = bytearray()
    while len(data) < length:
        chunk = connection.recv(length - len(data))
        if not chunk:
            raise ConnectionError("socket fechado")
        data.extend(chunk)
    return bytes(data)


def receive_packet(connection):
    header = receive_exact(connection, 7)
    return (
        int.from_bytes(header[:2], "big"),
        receive_exact(connection, int.from_bytes(header[2:5], "big")),
    )


def make_player(low_id):
    player = Players(SimpleNamespace())
    player.low_id = low_id
    player.high_id = 0
    player.token = ""
    player.name = f"Player {low_id}"
    player.room_id = 0
    player.online = 3
    player.brawler_id = 0
    player.skin_id = 0
    player.profile_icon = 0
    player.name_color = 0
    player.brawlers_trophies = {"0": 100}
    player.brawlers_trophies_in_rank = {"0": 200}
    player.Brawler_level = {"0": 3}
    player.brawlers_skins = {"0": 0}
    player.ClientDict = {"ClientCounts": 0, "Clients": {}}
    player.crypto = None
    player.battleTick = 0
    player.dudu = 0
    return player


def parse_stream(payload):
    reader = native_reader(payload)
    reader.read_Vint()
    room_id = reader.read_Vint()
    events = []
    for _ in range(reader.read_Vint()):
        kind = reader.read_Vint()
        reader.read_Vint()
        entry_id = reader.read_Vint()
        reader.read_Vint()
        reader.read_Vint()
        reader.read_string()
        reader.read_Vint()
        reader.read_Vint()
        reader.read_boolean()
        event = None
        if kind == 2:
            reader.read_string()
        elif kind == 4:
            event = reader.read_Vint()
            if reader.read_boolean():
                reader.read_Vint()
                reader.read_Vint()
                reader.read_string()
        events.append((entry_id, kind, event))
    reader.ensure_end()
    return room_id, events


def parse_start_loading(payload):
    reader = native_reader(payload)
    result = {
        "count": reader.read_int(),
        "own_index": reader.read_int(),
        "own_team": reader.read_int(),
    }
    assert reader.read_int() == result["count"]
    result["members"] = []
    for _ in range(result["count"]):
        member = {"name": reader.read_string()}
        member["index"] = reader.read_Vint()
        member["team"] = reader.read_Vint()
        member["unknown"] = reader.read_Vint()
        member["object"] = reader.read_int()
        member["brawler"] = reader.readScId()
        member["skin"] = reader.readScId()
        member["optional"] = reader.read_boolean()
        result["members"].append(member)
    result["arrays"] = [reader.read_int(), reader.read_int()]
    result["timestamp"] = reader.read_int()
    result["variation"] = reader.read_Vint()
    result["controls"] = [reader.read_Vint(), reader.read_Vint()]
    result["flag"] = reader.read_boolean()
    result["tail"] = [reader.read_Vint(), reader.read_Vint()]
    result["map"] = reader.readScId()
    reader.ensure_end()
    return result


class RoomBattleTests(unittest.TestCase):
    def setUp(self):
        GameRoomService.init()
        self.addCleanup(GameRoomService.init)
        self.sockets = []
        self.addCleanup(self.close_sockets)

    def close_sockets(self):
        for connection in self.sockets:
            try:
                connection.close()
            except OSError:
                pass

    def socket_pair(self):
        server, client = socket.socketpair()
        server.settimeout(1)
        client.settimeout(1)
        self.sockets.extend((server, client))
        return server, client

    def register(self, *players_and_sockets):
        clients = {"ClientCounts": len(players_and_sockets), "Clients": {}}
        for player, connection in players_and_sockets:
            player.ClientDict = clients
            clients["Clients"][str(player.low_id)] = {
                "SocketInfo": connection,
                "Crypto": None,
                "Lock": player.send_lock,
            }
        return clients

    def ready_message(self, client, player, ready=True):
        writer = native_writer()
        writer.writeBoolean(ready)
        writer.writeVint(0)
        message = TeamSetMemberReadyMessage(client, player, writer.buffer)
        message.decode()
        return message

    def test_team_code_native_vectors_and_factory(self):
        self.assertIs(packets[14371], TeamJoinOrCreateRoomMessage)
        for low_id in (0, 1, 255, 256, 65535, 2147483647):
            code = TeamCode.to_code(0, low_id)
            self.assertEqual(TeamCode.to_id(code), (0, low_id))
        self.assertEqual(TeamCode.to_code(0, 0), "X")
        self.assertEqual(TeamCode.to_code(0, 1), "XAA")
        for code in ("", "YAA", "X!", "X0"):
            with self.assertRaises(ValueError):
                TeamCode.to_id(code)

    def test_join_or_create_resolves_rotation_and_synchronizes_stream(self):
        owner = make_player(1)
        guest = make_player(2)
        owner_server, owner_client = self.socket_pair()
        guest_server, guest_client = self.socket_pair()
        self.register((owner, owner_client), (guest, guest_client))

        create = TeamJoinOrCreateRoomMessage(owner_client, owner, self.string_payload("X"))
        create.decode()
        room = create.process()
        self.assertGreater(room["id"], 0)
        self.assertGreaterEqual(room["map_id"], 0)
        self.assertNotEqual(room["map_id"], -64)
        self.assertEqual(receive_packet(owner_server)[0], 24124)
        _, events = parse_stream(receive_packet(owner_server)[1])
        self.assertEqual([event[2] for event in events], [101])

        code = TeamCode.to_code(0, room["id"])
        join = TeamJoinOrCreateRoomMessage(guest_client, guest, self.string_payload(code))
        join.decode()
        joined = join.process()
        self.assertEqual(joined["id"], room["id"])
        self.assertEqual([m["low_id"] for m in joined["members"]], [1, 2])
        for connection in (guest_server, owner_server):
            self.assertEqual(receive_packet(connection)[0], 24124)
            stream_room, events = parse_stream(receive_packet(connection)[1])
            self.assertEqual(stream_room, room["id"])
            expected = [101, 102] if connection is owner_server else [102]
            self.assertEqual([event[2] for event in events], expected)

    @staticmethod
    def string_payload(value):
        writer = native_writer()
        writer.writeString(value)
        return writer.buffer

    def test_each_ready_uses_legacy_on_play_flow_only_for_that_player(self):
        owner = make_player(1)
        guest = make_player(2)
        room = GameRoomService.create(owner, 0, 7, 0, False)
        GameRoomService.request_join_transition(guest, room["id"])
        owner_server, owner_client = self.socket_pair()
        guest_server, guest_client = self.socket_pair()
        self.register((owner, owner_client), (guest, guest_client))

        def expect_cancelled(connection, player):
            self.assertEqual(receive_packet(connection), (20406, b""))
            self.assertEqual((player.map_id, player.mmplayers), (15, 1))

        with patch("Logic.Battle.Battle.Battle.start") as battle_start, \
             patch.object(StartLoadingMessage, "send") as start_loading:
            room = self.ready_message(owner_client, owner).process()
            self.assertTrue(room["members"][0]["ready"])
            self.assertFalse(room["members"][1]["ready"])
            for connection in (owner_server, guest_server):
                self.assertEqual(receive_packet(connection)[0], 24124)
            expect_cancelled(owner_server, owner)
            guest_server.settimeout(0.05)
            with self.assertRaises(TimeoutError):
                receive_packet(guest_server)
            guest_server.settimeout(1)

            self.ready_message(owner_client, owner).process()
            for connection in (owner_server, guest_server):
                self.assertEqual(receive_packet(connection)[0], 24124)
            expect_cancelled(owner_server, owner)

            self.ready_message(guest_client, guest).process()
            for connection in (owner_server, guest_server):
                self.assertEqual(receive_packet(connection)[0], 24124)
            expect_cancelled(guest_server, guest)
            owner_server.settimeout(0.05)
            with self.assertRaises(TimeoutError):
                receive_packet(owner_server)
            owner_server.settimeout(1)
        battle_start.assert_not_called()
        start_loading.assert_not_called()

    def test_start_loading_native_layout_and_personal_own_player(self):
        owner = make_player(1)
        guest = make_player(2)
        room = GameRoomService.create(owner, 0, 7, 0, False)
        room, _, _ = GameRoomService.request_join_transition(guest, room["id"])
        entries = BattleParticipants.build(room)
        self.assertEqual(len(entries), 6)
        for player, own_index in ((owner, 0), (guest, 1)):
            with patch(
                "Packets.Messages.Server.Battle.StartLoadingMessage.time.time",
                return_value=123456789,
            ):
                payload = StartLoadingMessage(None, player, room, entries)._encode_payload()
            decoded = parse_start_loading(payload)
            self.assertEqual(decoded["count"], 6)
            self.assertEqual(decoded["own_index"], own_index)
            self.assertEqual(decoded["own_team"], 0)
            self.assertEqual(decoded["arrays"], [0, 0])
            self.assertEqual(decoded["timestamp"], 123456789)
            self.assertEqual(decoded["variation"], 0)
            self.assertEqual(decoded["controls"], [1, 3])
            self.assertFalse(decoded["flag"])
            self.assertEqual(decoded["tail"], [0, 19])
            self.assertEqual(decoded["map"], (15, 7))
            self.assertEqual(
                [member["name"] for member in decoded["members"]],
                ["Player 1", "Player 2", "Bot", "Bot", "Bot", "Bot"],
            )
            for index, member in enumerate(decoded["members"]):
                self.assertEqual(member["index"], index)
                self.assertEqual(member["brawler"][0], 16)
                self.assertEqual(member["skin"][0], 29)
                self.assertFalse(member["optional"])

    def test_showdown_capacities_and_v13_mode_variations(self):
        player = make_player(1)
        cases = (
            (7, 0, 6), (13, 6, 10), (34, 9, 10), (21, 2, 6),
            (27, 7, 6), (57, 8, 3),
        )
        for map_id, variation, capacity in cases:
            room = GameRoomService.create(player, 0, map_id, 0, False)
            entries = BattleParticipants.build(room)
            self.assertEqual(BattleParticipants.game_mode_variation(map_id), variation)
            self.assertEqual(len(entries), capacity)
            GameRoomService.leave(player)

    def test_all_location_mode_variations_match_r101(self):
        cases = (
            (7, 0), (21, 2), (27, 7), (0, 3), (24, 4),
            (17, 5), (13, 6), (34, 9), (57, 8), (20, 11),
        )
        for map_id, variation in cases:
            with self.subTest(map_id=map_id):
                self.assertEqual(
                    BattleParticipants.game_mode_variation(map_id), variation
                )

    def test_vision_update_has_one_exact_length_prefixed_stream(self):
        player = make_player(1)
        room = GameRoomService.create(player, 0, 7, 0, False)
        entries = BattleParticipants.build(room)
        player.battleTick = 9
        player.dudu = 3
        payload = VisionUpdateMessage(None, player, room, entries)._encode_payload()
        reader = native_reader(payload)
        self.assertEqual([reader.read_Vint() for _ in range(4)], [9, 3, 0, 0])
        length = reader.read_int()
        self.assertEqual(length, len(payload) - reader.tell())
        self.assertEqual(len(reader.read(length)), length)
        reader.ensure_end()

        class Recorder:
            def __init__(self):
                self.calls = []

            def writePositiveInt(self, value, bits):
                self.calls.append(("int", value, bits))

            def writePositiveVInt(self, value, bits):
                self.calls.append(("vint", value, bits))

            def writeInt(self, value, bits):
                self.calls.append(("signed", value, bits))

            def writePVIntMax255OZ(self, value):
                self.calls.append(("oz", value))

        recorder = Recorder()
        LogicCharacter.encode(SimpleNamespace(), recorder, entries)
        self.assertEqual(recorder.calls[0], ("int", 6, 7))
        self.assertEqual(
            [call for call in recorder.calls[1:13:2]],
            [("int", 16, 5)] * 6,
        )
        self.assertEqual(
            recorder.calls[13:19],
            [("int", index, 14) for index in range(6)],
        )


if __name__ == "__main__":
    unittest.main(verbosity=2)
