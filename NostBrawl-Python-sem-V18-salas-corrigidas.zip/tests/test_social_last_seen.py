import socket
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from Database.DatabaseManager import DataBase
from Logic.ClubService import ClubService
from Logic.FriendService import FriendService
from Logic.Player import Players
from Logic.PresenceService import PresenceService
from Packets.Messages.Server.Alliance.Alliance_Data_Message import AllianceDataMessage
from Packets.Messages.Server.Friend.FriendListUpdateMessage import FriendListUpdateMessage
from Utils.Reader import BSMessageReader
from main import Server
from SCIDClient.GameSessions import GAME_SESSIONS


class LastSeenIntegrationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        database = str(Path(self.temp.name) / 'accounts.sqlite')
        route = patch.object(DataBase, '_database_path', lambda: database)
        route.start()
        self.addCleanup(route.stop)
        self.server = Server('127.0.0.1', 0)
        self.addCleanup(self.server.server.close)
        self.addCleanup(PresenceService.bind_clients, None)
        self.addCleanup(GAME_SESSIONS.clear)
        self.players = []
        self.sockets = []
        for account in (101, 102):
            player = Players(SimpleNamespace())
            player.low_id = account
            player.token = 'lastseen-test-' + str(account)
            player.name = 'Player ' + str(account)
            player.trophies = 1234 if account == 102 else 0
            player.crypto = None
            player.online = 0
            DataBase.createAccount(SimpleNamespace(player=player))
            server_side, peer = socket.socketpair()
            self.addCleanup(server_side.close)
            self.addCleanup(peer.close)
            self.players.append(player)
            self.sockets.append(server_side)
        self.observer, self.subject = self.players
        ClubService.create(self.observer, 100011, 'Test', '', 1, 1, 0, 0)
        ClubService.join(self.subject, 100011)
        FriendService.add(self.observer, self.subject.low_id)
        FriendService.accept(self.subject, self.observer.low_id)

    def test_real_account_activity_is_persisted_and_shared_to_both_payloads(self):
        subject = self.subject
        subject.online = 1
        with patch('Logic.PresenceService.time.time', return_value=10000):
            self.server.register_client(subject, self.sockets[1])
        with patch('Logic.PresenceService.time.time', return_value=10003):
            self.assertTrue(PresenceService.record_activity(subject, self.sockets[1]))
        with DataBase._connection() as connection:
            self.assertEqual(connection.execute(
                'SELECT last_activity_at FROM social_presence WHERE player_id = ?',
                (subject.low_id,)).fetchone()[0], 10003)
        with patch('Logic.PresenceService.time.time', return_value=10005):
            self.assertTrue(PresenceService.set_status(subject, 0, self.sockets[1], persist=True))
        self.server.unregister_client(subject, self.sockets[1])
        with patch('Logic.PresenceService.time.time', return_value=19005):
            friend = FriendService.friends(self.observer)[0]
            self.assertEqual((friend['status'], friend['last_seen_seconds']), (0, 9000))
            raw = FriendListUpdateMessage(None, self.observer, friend)._encode_payload()
            self.assertEqual(int.from_bytes(raw[-4:], 'big', signed=True), 9000)
            club = ClubService.get_club(100011)
            member = next(x for x in club['members'] if x['low_id'] == subject.low_id)
            self.assertEqual((member['status'], member['last_seen_seconds']), (0, 9000))
            message = AllianceDataMessage(None, self.observer, 0, 100011)
            message.encode()
            reader = BSMessageReader(message.buffer).enable_native_v13()
            self.assertTrue(reader.read_boolean()); reader.read_int(); reader.read_int(); reader.read_string()
            for _ in range(8): reader.read_Vint()
            reader.read_string()
            count = reader.read_Vint()
            records = {}
            for _ in range(count):
                reader.read_int(); account = reader.read_int(); reader.read_string()
                records[account] = [reader.read_Vint() for _ in range(5)]
                reader.readScId()
            self.assertEqual(records[subject.low_id], [1, 1234, 1234, 0, 9000])
            self.assertEqual(reader.read(), b'')

    def test_unknown_legacy_activity_is_not_fabricated(self):
        with DataBase._connection() as connection:
            connection.execute('DELETE FROM social_presence WHERE player_id = ?', (self.subject.low_id,))
        friend = FriendService.friends(self.observer)[0]
        self.assertEqual(friend['last_seen_seconds'], -1)
        raw = FriendListUpdateMessage(None, self.observer, friend)._encode_payload()
        self.assertEqual(int.from_bytes(raw[-4:], 'big', signed=True), -1)
        member = next(x for x in ClubService.get_club(100011)['members']
                      if x['low_id'] == self.subject.low_id)
        self.assertEqual((member['status'], member['last_seen_seconds']), (-1, -1))

    def test_superseded_socket_cannot_write_last_activity(self):
        subject = self.subject
        subject.online = 1
        with patch('Logic.PresenceService.time.time', return_value=10000):
            self.server.register_client(subject, self.sockets[1])
        replacement = Players(SimpleNamespace())
        replacement.token = subject.token
        self.assertTrue(DataBase.loadAccount(SimpleNamespace(player=replacement)))
        replacement.crypto = None
        replacement.online = 1
        replacement_socket, peer = socket.socketpair()
        self.addCleanup(replacement_socket.close)
        self.addCleanup(peer.close)
        with patch('Logic.PresenceService.time.time', return_value=10010):
            self.server.register_client(replacement, replacement_socket)
        with patch('Logic.PresenceService.time.time', return_value=10020):
            self.assertFalse(PresenceService.record_activity(subject, self.sockets[1]))
            self.assertFalse(PresenceService.set_status(subject, 0, self.sockets[1], persist=True))
        with DataBase._connection() as connection:
            self.assertEqual(connection.execute(
                'SELECT online, last_activity_at FROM players JOIN social_presence ON player_id = lowID WHERE lowID = ?',
                (subject.low_id,)).fetchone(), (1, 10010))


if __name__ == '__main__':
    unittest.main()
