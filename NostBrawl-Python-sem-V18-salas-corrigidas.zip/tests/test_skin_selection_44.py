"""Rodada 44: obter uma skin nunca altera a skin selecionada pelo jogador."""

import copy
import os
import random
import sys
import tempfile
import unittest
from contextlib import closing
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch


PROJECT_ROOT = Path(__file__).resolve().parents[1]
os.chdir(PROJECT_ROOT)
sys.path.insert(0, str(PROJECT_ROOT))

from Database.DatabaseManager import DataBase
from Files.CsvLogic.Skins import Skins
from Logic.NotificationFactory import NotificationFactory
from Logic.BoxService import open_boxes
from Logic.GameRoomService import GameRoomService
from Logic.Player import Players
from Logic.Rewards import RewardTransaction
from Logic.SkinPurchase import SkinPurchase


SKIN = 29
SKIN_BRAWLER = Skins.getBrawler(SKIN)


class SkinSelectionTestCase(unittest.TestCase):
    def setUp(self):
        self.temp_directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp_directory.cleanup)
        self.database_path = str(Path(self.temp_directory.name) / "players.db")
        path_patch = patch.object(DataBase, "_database_path", lambda: self.database_path)
        path_patch.start()
        self.addCleanup(path_patch.stop)
        GameRoomService.init()
        self.addCleanup(GameRoomService.init)
        self.player, self.owner = self.make_account()

    def make_account(self, low_id=1, token="skin-selection"):
        player = Players(SimpleNamespace())
        player.low_id = low_id
        player.high_id = 0
        player.token = token
        player.name = "Skin Test"
        owner = SimpleNamespace(player=player)
        DataBase.createAccount(owner)
        return player, owner

    def update(self, values, player=None):
        player = player or self.player
        owner = SimpleNamespace(player=player)
        self.assertTrue(DataBase.replaceValues(owner, values))
        self.assertTrue(DataBase.loadAccount(owner))

    def reload(self, player=None):
        source = player or self.player
        loaded = Players(SimpleNamespace())
        loaded.token = source.token
        self.assertTrue(DataBase.loadAccount(SimpleNamespace(player=loaded)))
        return loaded

    def selection(self, player):
        return (
            int(player.brawler_id),
            int(player.skin_id),
            dict(player.brawlers_skins),
        )


class NewAccountSkinTests(SkinSelectionTestCase):
    def test_new_account_starts_with_default_skin_and_no_selection(self):
        self.assertEqual(self.player.skin_id, 0)
        self.assertTrue(self.player.brawlers_skins)
        self.assertEqual(set(self.player.brawlers_skins.values()), {0})
        loaded = self.reload()
        self.assertEqual(loaded.skin_id, 0)
        self.assertEqual(set(loaded.brawlers_skins.values()), {0})

    def test_reward_transaction_unlocks_skin_without_selecting_it(self):
        self.update({"UnlockedBrawlers": {"0": 1}, "brawlersSkins": {}, "skinID": 5})
        before = self.selection(self.player)
        transaction = RewardTransaction(self.player)
        transaction.add_reward("Skin", SKIN, SKIN_BRAWLER)
        transaction.commit()
        self.assertIn(SKIN, self.player.UnlockedSkins["Skins"])
        self.assertEqual(self.selection(self.player), before)
        loaded = self.reload()
        self.assertIn(SKIN, loaded.UnlockedSkins["Skins"])
        self.assertEqual(self.selection(loaded), before)

    def test_box_skin_reward_keeps_selection_of_a_new_account(self):
        self.update({
            "UnlockedBrawlers": {"0": 1},
            "brawlersSkins": {"0": 0},
            "skinID": 0,
            "brawlerID": 0,
            "gems": 1000,
        })
        before = self.selection(self.player)
        with patch(
            "Logic.BoxService.generate_rewards",
            return_value=[
                {"name": "Skin", "amount": SKIN, "target": SKIN_BRAWLER},
            ],
        ):
            open_boxes(self.player, 1)
        self.assertIn(SKIN, self.player.UnlockedSkins["Skins"])
        self.assertEqual(self.selection(self.player), before)
        loaded = self.reload()
        self.assertIn(SKIN, loaded.UnlockedSkins["Skins"])
        self.assertEqual(self.selection(loaded), before)

    def test_notification_skin_claim_keeps_selection(self):
        self.update({"UnlockedBrawlers": {"0": 1}, "brawlersSkins": {"0": 0}})
        self.player.UnlockedBrawlers = {"0": 1}
        notification = NotificationFactory.add_skin(self.player, SKIN)
        before = self.selection(self.player)
        result = NotificationFactory.claim_skin(self.player, notification["Index"])
        self.assertEqual(result["skin"], SKIN)
        self.assertIn(SKIN, self.player.UnlockedSkins["Skins"])
        self.assertEqual(self.selection(self.player), before)
        self.assertEqual(self.selection(self.reload()), before)

    def test_shop_purchase_keeps_selection_of_every_brawler(self):
        self.update({
            "gems": 500,
            "UnlockedBrawlers": {"0": 1, "1": 1},
            "brawlersSkins": {"0": SKIN},
            "skinID": SKIN,
            "brawlerID": 0,
            "UnlockedSkins": {"Skins": [SKIN]},
        })
        skin = next(
            candidate for candidate in Skins.get_skins_id()
            if Skins.getBrawler(candidate) == 1
            and not Skins.getIsDefaultSkin(candidate)
        )
        before = self.selection(self.player)
        SkinPurchase.purchase(self.player, skin, 1)
        self.assertIn(skin, self.player.UnlockedSkins["Skins"])
        self.assertEqual(self.selection(self.player), before)
        self.assertEqual(self.selection(self.reload()), before)


class RoomSkinTests(SkinSelectionTestCase):
    def test_room_never_shows_a_skin_obtained_but_not_selected(self):
        self.update({
            "UnlockedBrawlers": {"0": 1},
            "UnlockedSkins": {"Skins": [SKIN]},
            "brawlersSkins": {},
            "skinID": 0,
            "brawlerID": 0,
        })
        self.assertNotEqual(Skins.resolve_skin(0, 0), SKIN)
        room = GameRoomService.create(self.player, 0, 0, 0, True)
        self.addCleanup(GameRoomService.leave, self.player)
        self.assertEqual(room["members"][0]["skin_id"], Skins.resolve_skin(0, 0))
        self.assertNotEqual(room["members"][0]["skin_id"], SKIN)

    def test_room_keeps_the_skin_the_player_selected(self):
        self.update({
            "UnlockedBrawlers": {"0": 1},
            "UnlockedSkins": {"Skins": [SKIN]},
            "brawlersSkins": {"0": SKIN},
            "skinID": SKIN,
            "brawlerID": 0,
        })
        room = GameRoomService.create(self.player, 0, 0, 0, True)
        self.addCleanup(GameRoomService.leave, self.player)
        self.assertEqual(room["members"][0]["skin_id"], SKIN)

    def test_room_falls_back_to_brawler_default_not_to_another_skin(self):
        other_skin = next(
            candidate for candidate in Skins.get_skins_id()
            if Skins.getBrawler(candidate) == 0
            and not Skins.getIsDefaultSkin(candidate)
            and candidate != SKIN
        )
        self.update({
            "UnlockedBrawlers": {"0": 1},
            "UnlockedSkins": {"Skins": [other_skin]},
            "brawlersSkins": {"0": 0},
            "skinID": other_skin,
            "brawlerID": 0,
        })
        self.player.skin_id = other_skin
        self.player.brawler_id = 0
        self.player.brawlers_skins = {"0": 0}
        room = GameRoomService.create(self.player, 0, 0, 0, True)
        self.addCleanup(GameRoomService.leave, self.player)
        self.assertEqual(room["members"][0]["skin_id"], Skins.resolve_skin(0, 0))


if __name__ == "__main__":
    unittest.main()
