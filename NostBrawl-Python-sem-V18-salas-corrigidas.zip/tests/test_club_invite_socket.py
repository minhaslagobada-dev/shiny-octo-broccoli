import socket
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from Database.DatabaseManager import DataBase
from Logic.ClubService import ClubService
from Logic.GameRoomService import GameRoomService
from Logic.Player import Players
from Logic.PresenceService import PresenceService
from SCIDClient.Game import SCIDGame
from SCIDClient.GameSessions import GAME_SESSIONS
from Utils.Reader import BSMessageReader
from Utils.Writer import Writer
from main import ClientThread, Server
from test_protocol import login_payload, packet, receive_packet
from test_social_invite_presence import status_packet


class ClubInviteSocketTests(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory(); self.addCleanup(temp.cleanup)
        database = str(Path(temp.name) / 'accounts.sqlite')
        route = patch.object(DataBase, '_database_path', lambda: database); route.start(); self.addCleanup(route.stop)
        scid = patch.object(SCIDGame, 'enabled', return_value=False); scid.start(); self.addCleanup(scid.stop)
        self.server = Server('127.0.0.1', 0); self.server.crypto_settings = {'Enabled': False}
        self.addCleanup(self.server.server.close); self.addCleanup(PresenceService.bind_clients, None); self.addCleanup(GAME_SESSIONS.clear)
        GameRoomService.init(); self.addCleanup(GameRoomService.init)
        self.threads, self.peers = [], []
        self.addCleanup(self.close_sessions)
        self.players=[]
        for number in (301,302):
            player=Players(SimpleNamespace()); player.low_id=number; player.name=f'Membro {number}'; player.token=f'club-invite-{number}'
            DataBase.createAccount(SimpleNamespace(player=player)); self.players.append(player)
        ClubService.create(self.players[0], 991001, 'Equipe', '', 1, 1, 0, 0)
        ClubService.join(self.players[1], 991001)

    def close_sessions(self):
        for peer in self.peers:
            try: peer.close()
            except OSError: pass
        for thread in self.threads:
            thread.join(4)
            if thread.is_alive(): raise AssertionError('Sessão não terminou')
        for key in list(self.server._season_timers): self.server._cancel_season_timer(key)

    def receive_status(self, peer):
        message, version, raw = receive_packet(peer)
        self.assertEqual((message,version),(24555,0))
        return status_packet(message.to_bytes(2,'big')+len(raw).to_bytes(3,'big')+version.to_bytes(2,'big')+raw)

    def login(self,index,online):
        server,peer=socket.socketpair(); peer.settimeout(5); self.peers.append(peer)
        thread=ClientThread(server,('test-club',index),self.server); self.threads.append(thread); thread.start()
        peer.sendall(packet(10100)); self.assertEqual(receive_packet(peer)[0],20100)
        player=self.players[index]; peer.sendall(packet(10101,login_payload(player.low_id,player.token)))
        self.assertEqual([receive_packet(peer)[0] for _ in range(5)],[20104,24101,24399,24311,20105])
        club=receive_packet(peer); self.assertEqual((club[0],club[1]),(24301,11))
        self.assertTrue(BSMessageReader(club[2]).enable_native_v13().read_boolean())
        other=self.players[1-index].low_id
        self.assertEqual(self.receive_status(peer),((0,other),None))
        if online:
            account,presence=self.receive_status(peer); self.assertEqual(account,(0,other)); self.assertEqual(presence[:2],((0,other),2))
        return peer

    def test_online_club_members_receive_status_and_exchange_invitation(self):
        self._exchange_invitation(14365)

    def test_club_invite_packet_14370(self):
        self._exchange_invitation(14370)

    def _exchange_invitation(self, message_id):
        first=self.login(0,False)
        second=self.login(1,True)
        self.assertEqual(receive_packet(first)[0],24308)
        self.assertEqual(self.receive_status(first),((0,302),None))
        account,presence=self.receive_status(first); self.assertEqual(account,(0,302)); self.assertEqual(presence[:2],((0,302),2))
        create=Writer(None).enable_native_v13()
        for value in (7,0,0): create.writeVint(value)
        create.writeBoolean(False)
        first.sendall(packet(14350,create.buffer)); self.assertEqual([receive_packet(first)[0] for _ in range(2)],[24124,24131])
        invite=Writer(None).enable_native_v13()
        for value in (0,302,0): invite.writeVint(value)
        first.sendall(packet(message_id,invite.buffer)); self.assertEqual(receive_packet(first)[0],24124)
        while True:
            message,_,raw=receive_packet(second)
            if message==24589:
                break
            self.assertIn(message,(20105,20106,24555,24308,24311),message)
        reader=BSMessageReader(raw).enable_native_v13(); self.assertEqual(reader.read_Vint(),1)
        self.assertEqual((reader.read_int(),reader.read_int()),(0,301))
        room=next(room['id'] for room in GameRoomService.get_rooms() if any(m['low_id']==301 for m in room['members']))
        response=Writer(None).enable_native_v13(); response.writeVint(1); response.writeInt(0); response.writeInt(301); response.writeBoolean(False)
        second.sendall(packet(14479,response.buffer))
        self.assertEqual([receive_packet(second)[0] for _ in range(2)],[24124,24131])
        self.assertEqual([receive_packet(first)[0] for _ in range(2)],[24124,24131])
        self.assertEqual({m['low_id'] for m in GameRoomService.get(room)['members']},{301,302})

if __name__=='__main__': unittest.main()
