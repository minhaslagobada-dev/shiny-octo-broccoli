import os
import socket
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

PROJECT_ROOT = Path(__file__).resolve().parents[1]
os.chdir(PROJECT_ROOT)
sys.path.insert(0, str(PROJECT_ROOT))

from Database.DatabaseManager import DataBase
from Logic.ClubService import ClubService
from Logic.FriendService import FriendService
from Logic.GameRoomService import GameRoomService
from Logic.Player import Players
from Logic.PresenceService import PresenceService
from SCIDClient.Game import SCIDGame
from SCIDClient.GameSessions import GAME_SESSIONS
from Utils.Reader import BSMessageReader
from Utils.Writer import Writer
from main import ClientThread, Server
from test_protocol import login_payload, packet, receive_packet


GameRoomServiceError24 = 24


def native_writer():
    return Writer(None).enable_native_v13()


def read_status(payload):
    reader = BSMessageReader(payload).enable_native_v13()
    reader.read_int(), reader.read_int()
    present = reader.read_boolean()
    if not present:
        reader.ensure_end()
        return None
    reader.read_int(), reader.read_int()
    status = reader.read_Vint()
    reader.read_Vint()
    reader.read_boolean()
    reader.ensure_end()
    return status


class TeamPresenceSocketTests(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        database = str(Path(temp.name) / 'presence46.sqlite')
        route = patch.object(DataBase, '_database_path', lambda: database)
        route.start()
        self.addCleanup(route.stop)
        scid = patch.object(SCIDGame, 'enabled', return_value=False)
        scid.start()
        self.addCleanup(scid.stop)
        self.server = Server('127.0.0.1', 0)
        self.server.crypto_settings = {'Enabled': False}
        self.addCleanup(self.server.server.close)
        self.addCleanup(PresenceService.bind_clients, None)
        self.addCleanup(GAME_SESSIONS.clear)
        GameRoomService.init()
        self.addCleanup(GameRoomService.init)
        self.players = []
        self.threads = []
        self.peers = []
        self.addCleanup(self.close_sessions)
        for number in (401, 402):
            player = Players(SimpleNamespace())
            player.low_id = number
            player.name = 'Presenca ' + str(number)
            player.token = 'presence-46-' + str(number)
            DataBase.createAccount(SimpleNamespace(player=player))
            self.players.append(player)
        FriendService.add(self.players[0], 402)
        FriendService.accept(self.players[1], 401)

    def close_sessions(self):
        for peer in self.peers:
            try:
                peer.close()
            except OSError:
                pass
        for thread in self.threads:
            thread.join(4)
            if thread.is_alive():
                raise AssertionError('Sessão não terminou')
        for key in list(self.server._season_timers):
            self.server._cancel_season_timer(key)

    def login(self, index):
        server_socket, peer = socket.socketpair()
        peer.settimeout(5)
        self.peers.append(peer)
        thread = ClientThread(server_socket, ('test', index), self.server)
        self.threads.append(thread)
        thread.start()
        peer.sendall(packet(10100))
        self.assertEqual(receive_packet(peer)[0], 20100)
        player = self.players[index]
        peer.sendall(packet(10101, login_payload(player.low_id, player.token)))
        self.assertEqual(receive_packet(peer)[0], 20104)
        self.assertEqual(receive_packet(peer)[0], 24101)
        self.assertEqual(receive_packet(peer)[0], 20105)
        self.drain(peer)
        return peer

    def drain(self, peer):
        peer.settimeout(0.3)
        try:
            while True:
                receive_packet(peer)
        except (TimeoutError, socket.timeout):
            pass
        finally:
            peer.settimeout(5)

    def collect(self, peer, wanted, timeout=2.0):
        found = []
        peer.settimeout(timeout)
        try:
            while len(found) < len(wanted):
                packet_id, _, payload = receive_packet(peer)
                if packet_id in wanted:
                    found.append((packet_id, payload))
        except (TimeoutError, socket.timeout):
            pass
        finally:
            peer.settimeout(5)
        return found

    def statuses(self, peer, subject):
        values = []
        peer.settimeout(2)
        try:
            while True:
                packet_id, _, payload = receive_packet(peer)
                if packet_id != 24555:
                    continue
                reader = BSMessageReader(payload).enable_native_v13()
                if (reader.read_int(), reader.read_int()) != (0, subject):
                    continue
                status = read_status(payload)
                if status is not None:
                    values.append(status)
        except (TimeoutError, socket.timeout):
            pass
        finally:
            peer.settimeout(5)
        return values

    def accept(self, guest, owner_id, owner_peer):
        self.drain(owner_peer)
        self.drain(guest)
        writer = native_writer()
        writer.writeVint(1)
        writer.writeInt(0)
        writer.writeInt(owner_id)
        writer.writeBoolean(False)
        guest.sendall(packet(14479, writer.buffer))
        self.assertEqual(self.team_packets(guest, 2), [24124, 24131])
        self.assertEqual(self.team_packets(owner_peer, 2), [24124, 24131])

    def wait_presence(self, low_id, expected, timeout=3.0):
        import time

        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if PresenceService.status(low_id) == expected:
                return expected
            time.sleep(0.02)
        return PresenceService.status(low_id)

    def create_team(self, peer):
        self.drain(peer)
        writer = native_writer()
        for value in (7, 0, 0):
            writer.writeVint(value)
        writer.writeBoolean(False)
        peer.sendall(packet(14350, writer.buffer))
        self.assertEqual(self.team_packets(peer, 2), [24124, 24131])

    def team_packets(self, peer, count):
        found = []
        while len(found) < count:
            packet_id, _, _ = receive_packet(peer)
            if packet_id in (20105, 20106, 24555):
                continue
            found.append(packet_id)
        return found

    def leave(self, peer):
        self.drain(peer)
        peer.sendall(packet(14353, b''))

    def invite(self, peer, target):
        self.drain(peer)
        writer = native_writer()
        for value in (0, target, 0):
            writer.writeVint(value)
        peer.sendall(packet(14370, writer.buffer))

    def room_of(self, low_id):
        return next(
            (
                room for room in GameRoomService.get_rooms()
                if any(member['low_id'] == low_id for member in room['members'])
            ),
            None,
        )

    def test_creating_a_team_publishes_in_team_presence_to_friends(self):
        owner = self.login(0)
        friend = self.login(1)
        self.create_team(owner)
        self.assertEqual(
            self.wait_presence(401, GameRoomService.TEAM_PRESENCE),
            GameRoomService.TEAM_PRESENCE,
        )
        self.assertEqual(
            self.statuses(friend, 401), [GameRoomService.TEAM_PRESENCE]
        )
        self.assertEqual(
            PresenceService.status(401), GameRoomService.TEAM_PRESENCE
        )

    def test_leaving_a_team_publishes_menus_presence_to_friends(self):
        owner = self.login(0)
        friend = self.login(1)
        self.create_team(owner)
        self.drain(friend)
        self.leave(owner)
        self.assertEqual(len(self.collect(owner, (24125,))), 1)
        self.assertEqual(
            self.wait_presence(401, GameRoomService.HOME_PRESENCE),
            GameRoomService.HOME_PRESENCE,
        )
        self.assertEqual(
            self.statuses(friend, 401), [GameRoomService.HOME_PRESENCE]
        )

    def test_host_leave_disbands_and_frees_the_guest(self):
        owner = self.login(0)
        guest = self.login(1)
        room = None
        self.create_team(owner)
        room = self.room_of(401)
        self.invite(owner, 402)
        self.assertEqual(len(self.collect(guest, (24589,))), 1)
        self.accept(guest, 401, owner)
        self.assertEqual(
            {member['low_id'] for member in GameRoomService.get(room['id'])['members']},
            {401, 402},
        )
        self.leave(owner)
        left = self.collect(guest, (24125,))
        self.assertEqual(len(left), 1)
        reader = BSMessageReader(left[0][1]).enable_native_v13()
        self.assertEqual(
            reader.read_int(), GameRoomService.DISBAND_REASON
        )
        reader.ensure_end()
        self.assertIsNone(GameRoomService.get(room['id']))
        self.assertEqual(
            [self.players[0].room_id, self.players[1].room_id], [0, 0]
        )
        self.assertEqual(
            self.wait_presence(402, GameRoomService.HOME_PRESENCE),
            GameRoomService.HOME_PRESENCE,
        )
        self.assertEqual(GameRoomService.count(), 0)
        self.create_team(owner)
        self.invite(owner, 402)
        self.assertEqual(self.team_packets(owner, 1), [24124])
        self.assertEqual(len(self.collect(guest, (24589,))), 1)

    def test_club_member_without_friendship_can_be_invited(self):
        owner = self.login(0)
        guest = self.login(1)
        ClubService.create(self.players[0], 960001, 'Equipe', '', 1, 1, 0, 0)
        ClubService.join(self.players[1], 960001)
        self.create_team(owner)
        self.invite(owner, 402)
        self.assertEqual(len(self.collect(guest, (24589,))), 1)
        invites = self.room_of(401)['invites']
        self.assertEqual(
            [(invite['recipient_id'], invite['status']) for invite in invites],
            [(402, GameRoomService.INVITE_PENDING)],
        )
        self.accept(guest, 401, owner)
        self.assertEqual(
            [member['low_id'] for member in self.room_of(401)['members']],
            [401, 402],
        )

    def test_invitation_to_a_missing_account_reports_error_24(self):
        owner = self.login(0)
        self.login(1)
        self.create_team(owner)
        self.invite(owner, 499)
        errors = []
        for packet_id, payload in self.collect(owner, (24129, 24124), 1.5):
            if packet_id != 24129:
                continue
            reader = BSMessageReader(payload).enable_native_v13()
            reader.read_Vint()
            errors.append(reader.read_Vint())
        self.assertEqual(errors, [GameRoomServiceError24])
        self.assertEqual(self.room_of(401)['invites'], [])

    def test_invitation_to_someone_in_another_team_reports_error_29(self):
        owner = self.login(0)
        guest = self.login(1)
        self.create_team(owner)
        self.create_team(guest)
        self.invite(owner, 402)
        errors = []
        for packet_id, payload in self.collect(owner, (24129, 24124), 1.0):
            if packet_id != 24129:
                continue
            reader = BSMessageReader(payload).enable_native_v13()
            reader.read_Vint()
            errors.append(reader.read_Vint())
        self.assertEqual(errors, [29])

    def test_guest_leave_keeps_the_host_and_allows_a_new_invitation(self):
        owner = self.login(0)
        guest = self.login(1)
        self.create_team(owner)
        room = self.room_of(401)
        self.invite(owner, 402)
        self.assertEqual(len(self.collect(guest, (24589,))), 1)
        self.accept(guest, 401, owner)
        self.leave(guest)
        self.drain(guest)
        self.assertEqual(self.team_packets(owner, 2), [24124, 24131])
        self.assertEqual(
            [member['low_id'] for member in GameRoomService.get(room['id'])['members']],
            [401],
        )
        self.assertEqual(guest_room := self.players[1].room_id, 0)
        self.invite(owner, 402)
        self.assertEqual(self.team_packets(owner, 1), [24124])
        self.assertEqual(len(self.collect(guest, (24589,))), 1)



class TeamSnapshotPrivacyTests(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        database = str(Path(temp.name) / 'snapshot46.sqlite')
        route = patch.object(DataBase, '_database_path', lambda: database)
        route.start()
        self.addCleanup(route.stop)
        GameRoomService.init()
        self.addCleanup(GameRoomService.init)
        self.owner = Players(SimpleNamespace())
        self.owner.low_id = 501
        self.owner.name = 'Dono'
        self.owner.token = 'snapshot-46-owner'
        self.owner.crypto = SimpleNamespace(key='segredo')
        self.guest = Players(SimpleNamespace())
        self.guest.low_id = 502
        self.guest.name = 'Convidado'
        self.guest.token = 'snapshot-46-guest'
        self.guest.crypto = SimpleNamespace(key='segredo')
        for player in (self.owner, self.guest):
            DataBase.createAccount(SimpleNamespace(player=player))

    def test_snapshots_never_expose_session_objects(self):
        room, _, _ = GameRoomService.create_transition(self.owner, 7, 0, 0, False)
        GameRoomService.join(self.guest, room['id'])
        for snapshot in [GameRoomService.get(room['id'])] + GameRoomService.get_rooms():
            for member in snapshot['members']:
                self.assertFalse([key for key in member if key.startswith('_')])
                self.assertNotIn('crypto', member)
            self.assertFalse([key for key in snapshot if key.startswith('_')])
        self.assertNotIn('_player', repr(GameRoomService.get(room['id'])))


if __name__ == '__main__':
    unittest.main()
