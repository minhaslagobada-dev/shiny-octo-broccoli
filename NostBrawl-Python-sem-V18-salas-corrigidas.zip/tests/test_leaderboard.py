import os
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

PROJECT_ROOT = Path(__file__).resolve().parents[1]
os.chdir(PROJECT_ROOT)
sys.path.insert(0, str(PROJECT_ROOT))

from Database.DatabaseManager import DataBase
from Logic.ClubService import ClubService
from Logic.LeaderboardService import LeaderboardService
from Logic.Player import Players
from Packets.Messages.Client.Home.GetLeaderboardMessage import GetLeaderboardMessage
from Packets.Messages.Client.Home.AskProfileMessage import AskProfileMessage
from Packets.Messages.Server.Leaderboard.LeaderboardMessage import LeaderboardMessage
from Packets.Messages.Server.Leaderboard.TopGlobalPlayersDataMessage import GetLeaderboardGlobalOkMessage
from Packets.Messages.Server.Leaderboard.TopLocalPlayersDataMessage import GetLeaderboardLocalOkMessage
from Utils.Reader import BSMessageReader
from Utils.Writer import Writer


def vint(value):
    writer = Writer(None)
    writer.writeVint(value)
    return writer.buffer


def string(value):
    writer = Writer(None)
    writer.writeString(value)
    return writer.buffer


def decode_leaderboard(payload):
    reader = BSMessageReader(payload)
    leaderboard_type = reader.read_Vint()
    target = None
    if leaderboard_type == 0:
        target = (reader.read_Vint(), reader.read_Vint())
    else:
        if reader.read_Vint() != 0:
            raise AssertionError("Invalid leaderboard reference")
    region = reader.read_string()
    entries = []
    ranks = []
    for _ in range(reader.read_Vint()):
        high_id = reader.read_Vint()
        low_id = reader.read_Vint()
        rank = reader.read_Vint()
        ranks.append(rank)
        trophies = reader.read_Vint()
        if leaderboard_type == 2:
            marker = reader.read_Vint()
            name = reader.read_string()
            members = reader.read_Vint()
            badge = (reader.read_Vint(), reader.read_Vint())
            entries.append((low_id, trophies, name, members, badge, marker))
        else:
            marker = reader.read_Vint()
            name = reader.read_string()
            club = reader.read_string()
            experience = reader.read_Vint()
            icon = (reader.read_Vint(), reader.read_Vint())
            trailing = reader.read_Vint()
            entries.append(
                (low_id, trophies, name, club, experience, icon, marker, trailing)
            )
        if high_id != 0:
            raise AssertionError("Invalid leaderboard entry")
    footer = [reader.read_Vint() for _ in range(4)]
    footer_region = reader.read_string()
    if reader.read():
        raise AssertionError("Trailing leaderboard bytes")
    return {
        "type": leaderboard_type,
        "target": target,
        "region": region,
        "entries": entries,
        "ranks": ranks,
        "own_rank": footer[1],
        "footer_region": footer_region,
    }


class CaptureClient:
    def __init__(self):
        self.packets = []

    def sendall(self, data):
        self.packets.append(bytes(data))


class LeaderboardTests(unittest.TestCase):
    def setUp(self):
        self.temp_directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp_directory.cleanup)
        self.database_path = str(Path(self.temp_directory.name) / "players.db")
        path_patch = patch.object(
            DataBase, "_database_path", lambda: self.database_path
        )
        path_patch.start()
        self.addCleanup(path_patch.stop)

    def make_account(self, low_id, trophies, brawler_trophies):
        player = Players(SimpleNamespace())
        player.low_id = low_id
        player.high_id = 0
        player.token = f"leaderboard-{low_id}"
        player.name = f"Player {low_id}"
        player.trophies = trophies
        player.highest_trophies = trophies
        player.profile_icon = low_id % 5
        player.brawlers_trophies = {"0": brawler_trophies}
        DataBase.createAccount(SimpleNamespace(player=player))
        return player

    def test_players_brawlers_clubs_and_v13_payloads(self):
        first = self.make_account(1, 100, 30)
        second = self.make_account(2, 500, 0)
        third = self.make_account(3, 300, 20)
        fourth = self.make_account(4, 50, 10)
        ClubService.create(second, 900001, "Alpha", "", 8, 1, 0, 0)

        players = LeaderboardService.players()
        self.assertEqual(
            [entry["low_id"] for entry in players], [2, 3, 1, 4]
        )
        self.assertEqual(players[0]["club_name"], "Alpha")
        decoded = decode_leaderboard(
            self.encode(GetLeaderboardGlobalOkMessage(None, fourth, players))
        )
        self.assertEqual(decoded["type"], 1)
        self.assertEqual(decoded["own_rank"], 4)
        self.assertEqual(decoded["region"], "")
        self.assertEqual(decoded["entries"][0][:4], (2, 500, "Player 2", "Alpha"))
        self.assertEqual(decoded["entries"][0][4], 99999)
        self.assertEqual(decoded["ranks"], [1, 2, 3, 4])

        local = decode_leaderboard(
            self.encode(GetLeaderboardLocalOkMessage(None, fourth, players))
        )
        self.assertEqual(local["region"], fourth.region)
        self.assertEqual(local["own_rank"], 4)

        brawlers = LeaderboardService.players(0)
        self.assertEqual([entry["low_id"] for entry in brawlers], [1, 3, 4])
        self.assertEqual([entry["trophies"] for entry in brawlers], [30, 20, 10])
        brawler = decode_leaderboard(
            self.encode(LeaderboardMessage(None, first, 0, False, brawlers, 0))
        )
        self.assertEqual(brawler["target"], (16, 0))
        self.assertEqual(brawler["own_rank"], 1)
        self.assertEqual([entry[0] for entry in brawler["entries"]], [1, 3, 4])

        clubs = LeaderboardService.clubs()
        club = decode_leaderboard(
            self.encode(LeaderboardMessage(None, second, 2, False, clubs))
        )
        self.assertEqual(club["own_rank"], 1)
        self.assertEqual(club["entries"][0][:5], (900001, 500, "Alpha", 1, (8, 8)))

    def test_top_200_preserves_rank_outside_display(self):
        players = [{
            "low_id": index,
            "name": f"P{index}",
            "trophies": 1000 - index,
            "profile_icon": 0,
            "name_color": 0,
            "club_id": 0,
            "club_name": "",
            "player_experience": 99999,
            "online": 0,
        } for index in range(1, 202)]
        owner = SimpleNamespace(low_id=201, club_low_id=0, region="BR")
        decoded = decode_leaderboard(
            self.encode(LeaderboardMessage(None, owner, 1, False, players))
        )
        self.assertEqual(len(decoded["entries"]), 200)
        self.assertEqual(decoded["entries"][-1][0], 200)
        self.assertEqual(decoded["ranks"][-1], 200)
        self.assertEqual(decoded["own_rank"], 201)

        clubs = [{
            "id": index,
            "name": f"C{index}",
            "trophies": 2000 - index,
            "member_count": 1,
            "badge_id": 0,
        } for index in range(1, 202)]
        owner.club_low_id = 201
        decoded = decode_leaderboard(
            self.encode(LeaderboardMessage(None, owner, 2, False, clubs))
        )
        self.assertEqual(len(decoded["entries"]), 200)
        self.assertEqual(decoded["entries"][-1][0], 200)
        self.assertEqual(decoded["own_rank"], 201)

    def test_empty_rankings_emit_complete_v13_payloads(self):
        owner = SimpleNamespace(low_id=50, club_low_id=0, region="BR")
        for leaderboard_type in (0, 1, 2):
            with self.subTest(type=leaderboard_type):
                message = LeaderboardMessage(
                    None,
                    owner,
                    leaderboard_type,
                    False,
                    [],
                    0,
                )
                decoded = decode_leaderboard(self.encode(message))
                self.assertEqual(decoded["entries"], [])
                self.assertEqual(
                    decoded["own_rank"], 0 if leaderboard_type == 2 else 1
                )
                if leaderboard_type == 0:
                    self.assertEqual(decoded["target"], (16, 0))

    def test_client_handler_routes_players_brawlers_and_clubs(self):
        player = self.make_account(10, 100, 25)
        ClubService.create(player, 900010, "Routes", "", 8, 1, 0, 0)
        cases = (
            (vint(0) + vint(1) + vint(0), 1, None, False),
            (vint(0) + vint(0) + vint(16) + vint(0), 0, (16, 0), False),
            (vint(0) + vint(2) + vint(0), 2, None, False),
            (vint(1) + vint(1) + vint(0), 1, None, True),
        )
        for payload, expected_type, target, is_local in cases:
            with self.subTest(type=expected_type, local=is_local):
                client = CaptureClient()
                message = GetLeaderboardMessage(client, player, payload)
                message.decode()
                self.assertEqual(message.read(), b"")
                message.process()
                self.assertEqual(len(client.packets), 1)
                packet = client.packets[0]
                self.assertEqual(int.from_bytes(packet[:2], "big"), 24403)
                self.assertEqual(int.from_bytes(packet[5:7], "big"), 13)
                length = int.from_bytes(packet[2:5], "big")
                decoded = decode_leaderboard(packet[7:7 + length])
                self.assertEqual(decoded["type"], expected_type)
                self.assertEqual(decoded["target"], target)
                self.assertEqual(
                    decoded["region"], player.region if is_local else ""
                )

    def test_other_player_profile_from_leaderboard_uses_native_v13_layout(self):
        owner = self.make_account(30, 100, 25)
        target = self.make_account(31, 500, 40)
        DataBase.replaceValues(
            SimpleNamespace(player=target),
            {
                "UnlockedBrawlers": {"0": 1, "1": 1},
                "brawlersTrophies": {"0": 40, "1": 70},
                "brawlersTrophiesForRank": {"0": 17, "1": 23},
                "brawlerPowerLevel": {"0": 4, "1": 8},
                "brawlerStarPower": {"0": 0, "1": 1},
            },
        )
        entries = LeaderboardService.players()
        self.assertEqual(entries[0]["low_id"], target.low_id)
        payload = (
            (0).to_bytes(4, "big")
            + target.low_id.to_bytes(4, "big")
            + vint(0)
        )
        client = CaptureClient()
        request = AskProfileMessage(client, owner, payload)
        request.decode()
        self.assertEqual(request.read(), b"")
        request.process()
        self.assertEqual(len(client.packets), 1)
        packet = client.packets[0]
        self.assertEqual(int.from_bytes(packet[:2], "big"), 24113)
        self.assertEqual(int.from_bytes(packet[5:7], "big"), 9)
        length = int.from_bytes(packet[2:5], "big")
        reader = BSMessageReader(packet[7:7 + length])
        self.assertEqual([reader.read_Vint() for _ in range(2)], [0, 31])
        self.assertEqual(reader.read_string(), "Player 31")
        self.assertEqual(reader.readScId(), (0, -1))
        self.assertEqual(reader.read_Vint(), 2)
        for brawler_id, trophies, rank, power in (
            (0, 40, 17, 5),
            (1, 70, 23, 10),
        ):
            self.assertEqual(reader.readScId(), (16, brawler_id))
            self.assertEqual(reader.readScId(), (0, -1))
            self.assertEqual(reader.read_Vint(), trophies)
            self.assertEqual(reader.read_Vint(), rank)
            self.assertEqual(reader.read_Vint(), power)
        self.assertEqual(reader.read_Vint(), 10)
        for _ in range(10):
            reader.read_Vint()
            reader.read_Vint()
        self.assertEqual(reader.read_byte(), 0)
        self.assertEqual(reader.readScId(), (0, -1))
        self.assertEqual(reader.read(), b"")

    def test_profile_request_consumes_optional_native_data(self):
        target = self.make_account(32, 200, 10)
        payload = (
            (0).to_bytes(4, "big")
            + target.low_id.to_bytes(4, "big")
            + vint(1)
            + vint(7)
            + (2).to_bytes(4, "big")
            + (9).to_bytes(4, "big")
            + vint(3)
            + vint(1)
            + string("Profile context")
            + vint(16)
            + vint(4)
            + vint(5)
            + vint(6)
            + vint(7)
        )
        request = AskProfileMessage(CaptureClient(), target, payload)
        request.decode()
        self.assertTrue(request.hasProfileData)
        self.assertEqual(
            request.profileData,
            (
                7,
                (2, 9),
                3,
                True,
                "Profile context",
                (16, 4),
                5,
                6,
                7,
            ),
        )
        self.assertEqual(request.read(), b"")

    @staticmethod
    def encode(message):
        message.encode()
        return message.buffer


if __name__ == "__main__":
    unittest.main()
