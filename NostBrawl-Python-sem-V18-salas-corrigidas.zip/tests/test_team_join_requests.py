import os
import socket
import sys
import tempfile
import unittest
from contextlib import closing
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch


PROJECT_ROOT = Path(__file__).resolve().parents[1]
os.chdir(PROJECT_ROOT)
sys.path.insert(0, str(PROJECT_ROOT))

from Database.DatabaseManager import DataBase
from Logic.GameRoomService import GameRoomFullError, GameRoomService
from Logic.Player import Players
from Packets.Messages.Client.Gameroom.TeamJoinRequestCancelMessage import TeamJoinRequestCancelMessage
from Packets.Messages.Client.Gameroom.TeamJoinRequestResponseMessage import TeamJoinRequestResponseMessage
from Packets.Messages.Client.Gameroom.TeamRequestJoinMessage import TeamRequestJoinMessage
from Utils.Reader import BSMessageReader
from Utils.Writer import Writer


def native_writer():
    return Writer(None).enable_native_v13()


def native_reader(payload):
    return BSMessageReader(payload).enable_native_v13()


def receive_exact(connection, length):
    data = bytearray()
    while len(data) < length:
        chunk = connection.recv(length - len(data))
        if not chunk:
            raise ConnectionError("socket fechado")
        data.extend(chunk)
    return bytes(data)


def receive_packet(connection):
    header = receive_exact(connection, 7)
    return (
        int.from_bytes(header[:2], "big"),
        receive_exact(connection, int.from_bytes(header[2:5], "big")),
    )


def make_player(low_id, name=None, token=""):
    player = Players(SimpleNamespace())
    player.low_id = low_id
    player.high_id = 0
    player.token = token
    player.name = name or f"Player {low_id}"
    player.room_id = 0
    player.online = 3
    player.brawler_id = 0
    player.skin_id = 0
    player.profile_icon = 3
    player.name_color = 0
    player.brawlers_trophies = {"0": 120}
    player.brawlers_trophies_in_rank = {"0": 200}
    player.Brawler_level = {"0": 5}
    player.brawlers_skins = {"0": 0}
    player.progression = {}
    player.ClientDict = {"ClientCounts": 0, "Clients": {}}
    player.crypto = None
    return player


class TeamJoinRequestTests(unittest.TestCase):
    def setUp(self):
        GameRoomService.init()
        self.addCleanup(GameRoomService.init)
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.path = str(Path(self.directory.name) / "players.db")
        self.addCleanup(DataBase._initialized_paths.discard, str(Path(self.path).resolve()))
        patcher = patch.object(DataBase, "_database_path", lambda: self.path)
        patcher.start()
        self.addCleanup(patcher.stop)
        self.owner = make_player(42, "Owner", token="owner-token")
        self.guest = make_player(77, "Guest", token="guest-token")
        self.outsider = make_player(91, "Outsider", token="outsider-token")
        for player in (self.owner, self.guest, self.outsider):
            DataBase.createAccount(SimpleNamespace(player=player))
        self.room = GameRoomService.create(self.owner, 1, 0, 0)

    def request(self, player=None, recipient=None, room_id=None):
        return GameRoomService.request_join_request(
            player or self.guest,
            (recipient or self.owner).low_id,
            room_id if room_id is not None else self.room["id"],
        )

    def test_request_creates_pending_entry_without_joining(self):
        room, request = self.request()
        self.assertEqual(room["player_count"], 1)
        self.assertEqual(self.guest.room_id, 0)
        self.assertEqual(len(room["join_requests"]), 1)
        stored = room["join_requests"][0]
        self.assertEqual(stored["key"], request["key"])
        self.assertEqual(stored["recipient_id"], self.owner.low_id)
        self.assertEqual(stored["requester_id"], self.guest.low_id)
        self.assertEqual(stored["entry"]["low_id"], self.guest.low_id)
        self.assertEqual(stored["entry"]["name"], "Guest")
        self.assertEqual(
            [event["event"] for event in GameRoomService.stream(self.room["id"])],
            [101],
        )

    def test_new_request_from_same_player_replaces_the_previous_key(self):
        _, first = self.request()
        room, second = self.request()
        self.assertNotEqual(first["key"], second["key"])
        self.assertEqual(len(room["join_requests"]), 1)
        self.assertEqual(room["join_requests"][0]["key"], second["key"])

    def test_request_requires_addressed_member_and_absent_requester(self):
        self.assertIsNone(self.request(recipient=self.outsider)[0])
        self.assertIsNone(self.request(room_id=self.room["id"] + 500)[0])
        GameRoomService.join(self.guest, self.room["id"])
        self.assertIsNone(self.request()[0])
        self.assertEqual(GameRoomService.get(self.room["id"])["join_requests"], [])

    def test_only_the_addressed_member_can_respond(self):
        _, request = self.request()
        self.assertIsNone(
            GameRoomService.respond_join_request(
                self.outsider, request["key"], True
            )
        )
        self.assertEqual(
            len(GameRoomService.get(self.room["id"])["join_requests"]), 1
        )
        self.assertIsNone(
            GameRoomService.respond_join_request(self.owner, request["key"] + 99, True)
        )

    def test_accept_joins_requester_persists_room_and_clears_request(self):
        _, request = self.request()
        outcome = GameRoomService.respond_join_request(
            self.owner, request["key"], True
        )
        self.assertTrue(outcome["accepted"])
        self.assertTrue(outcome["joined"])
        self.assertEqual(outcome["room"]["player_count"], 2)
        self.assertEqual(outcome["room"]["join_requests"], [])
        self.assertEqual(self.guest.room_id, self.room["id"])
        names = sorted(member["name"] for member in outcome["room"]["members"])
        self.assertEqual(names, ["Guest", "Owner"])
        with DataBase._connection() as connection:
            row = connection.execute(
                "SELECT roomID FROM players WHERE lowID = ?", (self.guest.low_id,)
            ).fetchone()
        self.assertEqual(int(row[0]), self.room["id"])
        events = [event["event"] for event in GameRoomService.stream(self.room["id"])]
        self.assertIn(102, events)

    def test_accept_twice_does_not_duplicate_member(self):
        _, request = self.request()
        GameRoomService.respond_join_request(self.owner, request["key"], True)
        self.assertIsNone(
            GameRoomService.respond_join_request(self.owner, request["key"], True)
        )
        self.assertEqual(GameRoomService.get(self.room["id"])["player_count"], 2)

    def test_reject_and_mute_block_further_requests(self):
        _, request = self.request()
        outcome = GameRoomService.respond_join_request(
            self.owner, request["key"], False, True
        )
        self.assertFalse(outcome["accepted"])
        self.assertEqual(outcome["room"]["join_requests"], [])
        self.assertEqual(self.guest.room_id, 0)
        self.assertIsNone(self.request()[0])
        with DataBase._connection() as connection:
            progression = DataBase._read_state(
                connection, self.owner.low_id, "progression"
            )
        mutes = progression.get(GameRoomService.INVITE_MUTES_KEY, {})
        self.assertGreater(
            int(mutes[str(self.guest.low_id)]), int(GameRoomService._now())
        )

    def test_mute_from_one_member_does_not_block_the_other_member(self):
        second_member = make_player(55, "Second", token="second-token")
        DataBase.createAccount(SimpleNamespace(player=second_member))
        GameRoomService.join(second_member, self.room["id"])
        _, request = self.request()
        GameRoomService.respond_join_request(self.owner, request["key"], False, True)
        room, accepted = self.request(recipient=second_member)
        self.assertIsNotNone(accepted)
        self.assertEqual(accepted["recipient_id"], second_member.low_id)

    def test_cancel_removes_pending_request_from_every_room(self):
        _, request = self.request()
        other = make_player(66, "Other", token="other-token")
        DataBase.createAccount(SimpleNamespace(player=other))
        second_room = GameRoomService.create(other, 1, 0, 0)
        affected = GameRoomService.cancel_join_requests(self.guest)
        self.assertEqual(
            [item["key"] for _, requests in affected for item in requests],
            [request["key"]],
        )
        self.assertEqual(
            GameRoomService.get(self.room["id"])["join_requests"], []
        )
        self.assertIsNotNone(second_room)

    def test_pending_requests_count_against_capacity(self):
        guests = []
        for offset in range(1, 6):
            player = make_player(100 + offset, f"Guest {offset}", token=f"g{offset}")
            DataBase.createAccount(SimpleNamespace(player=player))
            GameRoomService.join(player, self.room["id"])
            guests.append(player)
        self.assertEqual(GameRoomService.get(self.room["id"])["player_count"], 6)
        with self.assertRaises(GameRoomFullError):
            self.request()
        GameRoomService.leave(guests[-1])
        room, request = self.request()
        self.assertEqual(len(room["join_requests"]), 1)
        with self.assertRaises(GameRoomFullError):
            self.request(player=self.outsider)

    def test_accept_into_full_room_keeps_request_and_reports_error(self):
        _, request = self.request()
        for offset in range(1, 6):
            player = make_player(200 + offset, f"Late {offset}", token=f"l{offset}")
            DataBase.createAccount(SimpleNamespace(player=player))
            GameRoomService.join(player, self.room["id"])
        with self.assertRaises(GameRoomFullError):
            GameRoomService.respond_join_request(self.owner, request["key"], True)
        self.assertEqual(
            len(GameRoomService.get(self.room["id"])["join_requests"]), 1
        )
        self.assertEqual(self.guest.room_id, 0)


class TeamJoinRequestWireTests(unittest.TestCase):
    def setUp(self):
        GameRoomService.init()
        self.addCleanup(GameRoomService.init)
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.path = str(Path(self.directory.name) / "players.db")
        self.addCleanup(DataBase._initialized_paths.discard, str(Path(self.path).resolve()))
        patcher = patch.object(DataBase, "_database_path", lambda: self.path)
        patcher.start()
        self.addCleanup(patcher.stop)
        self.owner = make_player(42, "Owner", token="wire-owner")
        self.guest = make_player(77, "Guest", token="wire-guest")
        for player in (self.owner, self.guest):
            DataBase.createAccount(SimpleNamespace(player=player))
        self.room = GameRoomService.create(self.owner, 1, 0, 0)
        self.sockets = []
        self.addCleanup(self.close_sockets)
        self.owner_server, self.owner_client = self.socket_pair()
        self.guest_server, self.guest_client = self.socket_pair()
        clients = {"ClientCounts": 2, "Clients": {}}
        for player, connection in (
            (self.owner, self.owner_client), (self.guest, self.guest_client)
        ):
            player.ClientDict = clients
            clients["Clients"][str(player.low_id)] = {
                "SocketInfo": connection,
                "Crypto": None,
                "Lock": player.send_lock,
            }

    def close_sockets(self):
        for connection in self.sockets:
            try:
                connection.close()
            except OSError:
                pass

    def socket_pair(self):
        server, client = socket.socketpair()
        server.settimeout(1)
        client.settimeout(1)
        self.sockets.extend((server, client))
        return server, client

    def send_request(self):
        writer = native_writer()
        writer.writeInt(0)
        writer.writeInt(self.owner.low_id)
        writer.writeInt(0)
        writer.writeInt(self.room["id"])
        message = TeamRequestJoinMessage(self.guest_client, self.guest, writer.buffer)
        message.decode()
        return message

    def test_14881_notifies_addressed_member_with_request_vector(self):
        result = self.send_request().process()
        self.assertEqual(result["room"]["player_count"], 1)
        packet_id, payload = receive_packet(self.owner_server)
        self.assertEqual(packet_id, 24124)
        reader = native_reader(payload)
        reader.read_Vint()
        reader.read_boolean()
        reader.read_Vint()
        reader.read_int()
        reader.read_int()
        reader.read_Vint()
        reader.read_boolean()
        reader.read_boolean()
        reader.read_Vint()
        reader.read_Vint()
        reader.readScId()
        for _ in range(reader.read_Vint()):
            reader.read_boolean()
            reader.read_int()
            reader.read_int()
            reader.read_string()
            reader.read_Vint()
            reader.readScId()
            reader.readScId()
            for _ in range(4):
                reader.read_Vint()
            reader.read_boolean()
            for _ in range(2):
                reader.read_Vint()
        for _ in range(reader.read_Vint()):
            for _ in range(4):
                reader.read_int()
            reader.read_string()
            reader.read_Vint()
            reader.read_Vint()
        self.assertEqual(reader.read_Vint(), 1)
        key_high = reader.read_int()
        key_low = reader.read_int()
        recipient_high = reader.read_int()
        recipient_low = reader.read_int()
        self.assertEqual((key_high, recipient_high), (0, 0))
        self.assertEqual(recipient_low, self.owner.low_id)
        self.assertGreater(key_low, 0)

    def test_14882_accept_delivers_team_to_requester(self):
        request = self.send_request().process()["request"]
        self.assertEqual(receive_packet(self.owner_server)[0], 24124)
        writer = native_writer()
        writer.writeInt(0)
        writer.writeInt(request["key"])
        writer.writeBoolean(True)
        writer.writeBoolean(False)
        message = TeamJoinRequestResponseMessage(
            self.owner_client, self.owner, writer.buffer
        )
        message.decode()
        self.assertEqual(
            (message.request_high_id, message.request_id,
             message.accepted, message.mute_requester),
            (0, request["key"], True, False),
        )
        outcome = message.process()
        self.assertTrue(outcome["joined"])
        self.assertEqual(self.guest.room_id, self.room["id"])
        self.assertEqual(receive_packet(self.guest_server)[0], 24124)
        self.assertEqual(receive_packet(self.guest_server)[0], 24131)
        self.assertEqual(receive_packet(self.owner_server)[0], 24124)
        self.assertEqual(receive_packet(self.owner_server)[0], 24131)

    def test_14882_reject_keeps_team_and_clears_request_silently(self):
        request = self.send_request().process()["request"]
        self.assertEqual(receive_packet(self.owner_server)[0], 24124)
        writer = native_writer()
        writer.writeInt(0)
        writer.writeInt(request["key"])
        writer.writeBoolean(False)
        writer.writeBoolean(True)
        message = TeamJoinRequestResponseMessage(
            self.owner_client, self.owner, writer.buffer
        )
        message.decode()
        outcome = message.process()
        self.assertFalse(outcome["accepted"])
        self.assertEqual(GameRoomService.get(self.room["id"])["player_count"], 1)
        self.assertEqual(receive_packet(self.owner_server)[0], 24124)
        self.guest_server.settimeout(0.2)
        with self.assertRaises(TimeoutError):
            self.guest_client.recv(1)

    def test_14880_cancel_clears_request_for_addressed_member(self):
        self.send_request().process()
        self.assertEqual(receive_packet(self.owner_server)[0], 24124)
        message = TeamJoinRequestCancelMessage(self.guest_client, self.guest, b"")
        message.decode()
        result = message.process()
        self.assertEqual(len(result["cancelled"]), 1)
        self.assertEqual(
            GameRoomService.get(self.room["id"])["join_requests"], []
        )
        self.assertEqual(receive_packet(self.owner_server)[0], 24124)


if __name__ == "__main__":
    unittest.main()
