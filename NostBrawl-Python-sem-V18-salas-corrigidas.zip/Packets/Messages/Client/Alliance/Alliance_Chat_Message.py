from Database.DatabaseManager import DataBase
from Logic.ClubService import ClubError, ClubService
from Packets.Messages.Server.Alliance.Alliance_Chat_Server_Message import AllianceChatServerMessage
from Packets.Messages.Server.AllianceBot.Alliance_Bot_Chat_Server_Message import AllianceBotChatServerMessage
from Packets.Messages.Server.Login.LoginFailedMessage import LoginFailedMessage
from Utils.Reader import BSMessageReader


class AllianceChatMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client
        self.bot_msg = ""
        self.msg = ""

    def decode(self):
        self.msg = self.read_string()

    def _load_account(self):
        parts = self.msg.split()
        if len(parts) != 2:
            AllianceBotChatServerMessage(
                self.client, self.player, "Use: /load <id>"
            ).send()
            return "Formato /load inválido"
        try:
            nost_id = int(parts[1])
        except ValueError:
            AllianceBotChatServerMessage(
                self.client, self.player, "Use: /load <id>"
            ).send()
            return "ID /load inválido"
        loaded = DataBase.loadOldAccount(self, nost_id)
        self.player.err_code = 1
        if loaded:
            LoginFailedMessage(
                self.client,
                self.player,
                "Conta vinculada. Entre novamente para carregar os dados.",
            ).send()
            return True
        LoginFailedMessage(self.client, self.player, "Conta não encontrada.").send()
        return False

    def process(self):
        if self.msg.lower().startswith("/load"):
            return self._load_account()
        try:
            club_id, entry = ClubService.chat(self.player, self.msg)
        except ClubError as error:
            return str(error)
        club = ClubService.get_club(club_id)
        AllianceChatServerMessage(
            self.client, self.player, self.msg, club_id, entry=entry
        ).send()
        for member_id in club["member_ids"]:
            if member_id != self.player.low_id:
                AllianceChatServerMessage(
                    self.client, self.player, self.msg, club_id, entry=entry
                ).sendWithLowID(member_id)
        return entry
