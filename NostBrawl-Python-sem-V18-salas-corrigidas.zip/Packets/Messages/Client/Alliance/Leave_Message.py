from Logic.ClubService import ClubError, ClubService
from Logic.FriendService import FriendService
from Logic.PresenceService import PresenceService
from Packets.Messages.Server.Alliance.Alliance_Data_Message import AllianceDataMessage
from Packets.Messages.Server.Alliance.Alliance_Chat_Server_Message import AllianceChatServerMessage
from Packets.Messages.Server.Alliance.Events.AllianceLeaveOkMessage import AllianceLeaveOkMessage
from Packets.Messages.Server.Alliance.My_Alliance_Message import MyAllianceMessage
from Utils.Reader import BSMessageReader


class Leave_Message(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        pass

    def process(self):
        try:
            result = ClubService.leave(self.player)
        except ClubError as error:
            return str(error)
        AllianceLeaveOkMessage(self.client, self.player).send()
        MyAllianceMessage(self.client, self.player, 0).send()
        successor_id = result.get("successorID")
        if successor_id is not None:
            successor = ClubService.refresh_online_player(self.player, successor_id)
            if successor is not None:
                MyAllianceMessage(None, successor, result["clubID"]).sendWithLowID(successor_id)
        for member_id in result["memberIDs"]:
            AllianceDataMessage(
                self.client, self.player, 0, result["clubID"], member_override=True
            ).sendWithLowID(member_id)
            AllianceChatServerMessage(
                self.client, self.player, 4, result["clubID"], entry=result["entry"]
            ).sendWithLowID(member_id)
        FriendService.push_presence(self.player)
        for member_id in result["memberIDs"]:
            PresenceService.sync_pair(self.player, member_id)
        return result
