from Logic.ClubService import ClubError, ClubService
from Logic.FriendService import FriendService
from Logic.PresenceService import PresenceService
from Packets.Messages.Server.Alliance.Alliance_Data_Message import AllianceDataMessage
from Packets.Messages.Server.Alliance.AllianceStreamMessage import AllianceStreamMessage
from Packets.Messages.Server.Alliance.Alliance_Chat_Server_Message import AllianceChatServerMessage
from Packets.Messages.Server.Alliance.Events.AllianceJoinOkMessage import AllianceJoinOkMessage
from Packets.Messages.Server.Alliance.Events.JoinFail import AllianceJoinFail
from Packets.Messages.Server.Alliance.My_Alliance_Message import MyAllianceMessage
from Utils.Reader import BSMessageReader


class Join_Message(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.club_high_id = self.read_int()
        self.clubID = self.read_int()

    def process(self):
        try:
            if self.club_high_id != 0:
                raise ClubError("Clube não encontrado")
            club, entry = ClubService.join(self.player, self.clubID)
        except ClubError as error:
            AllianceJoinFail(self.client, self.player).send()
            return str(error)
        AllianceJoinOkMessage(self.client, self.player).send()
        MyAllianceMessage(self.client, self.player, club["id"]).send()
        AllianceStreamMessage(self.client, self.player, club["id"], 0).send()
        AllianceDataMessage(self.client, self.player, 0, club["id"]).send()
        for member_id in club["member_ids"]:
            if member_id != self.player.low_id:
                AllianceDataMessage(self.client, self.player, 0, club["id"], member_override=True).sendWithLowID(member_id)
            AllianceChatServerMessage(
                self.client, self.player, 3, club["id"], entry=entry
            ).sendWithLowID(member_id)
        FriendService.push_presence(self.player)
        for member_id in club["member_ids"]:
            if member_id != self.player.low_id:
                PresenceService.sync_pair(self.player, member_id)
        return club
