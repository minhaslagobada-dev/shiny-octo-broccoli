from Logic.ClubService import ClubError, ClubService
from Logic.FriendService import FriendService
from Logic.PresenceService import PresenceService
from Packets.Messages.Server.Alliance.Alliance_Data_Message import AllianceDataMessage
from Packets.Messages.Server.Alliance.Alliance_Chat_Server_Message import AllianceChatServerMessage
from Packets.Messages.Server.Alliance.Events.KickMemberOK import AllianceKickMemberOK
from Packets.Messages.Server.Alliance.My_Alliance_Message import MyAllianceMessage
from Utils.Reader import BSMessageReader


class Kick_Member_Message(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.highID = self.read_int()
        self.lowID = self.read_int()
        self.reason = self.read_string()

    def process(self):
        try:
            if self.highID != 0:
                raise ClubError("Conta não encontrada")
            club, entry, target_id = ClubService.kick(self.player, self.lowID)
        except ClubError as error:
            return str(error)
        AllianceKickMemberOK(self.client, self.player).send()
        MyAllianceMessage(self.client, self.player, club["id"]).send()
        target = ClubService.refresh_online_player(self.player, target_id)
        if target is not None:
            MyAllianceMessage(None, target, 0).sendWithLowID(target_id)
        FriendService.push_account(self.player, target_id)
        for member_id in club["member_ids"]:
            AllianceDataMessage(
                self.client, self.player, 0, club["id"], member_override=True
            ).sendWithLowID(member_id)
            AllianceChatServerMessage(
                self.client, self.player, 1, club["id"], entry=entry
            ).sendWithLowID(member_id)
        for member_id in club["member_ids"]:
            PresenceService.sync_subject(self.player, target_id, member_id)
            PresenceService.sync_subject(self.player, member_id, target_id)
        return club
