from Logic.ClubService import ClubService
from Packets.Messages.Server.Alliance.AllianceSearchResultMessage import AllianceSearchResultMessage
from Utils.Reader import BSMessageReader


class Search_Message(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.RequestedName = self.read_string()
        self.minMembers = self.read_int()
        self.maxMembers = self.read_int()
        self.clubType = self.read_int()
        self.maxListLength = self.read_int()
        self.onlyOnline = self.read_boolean()
        self.regionID = self.read_int()
        self.sortOrder = self.read_int()

    def process(self):
        clubs = ClubService.list_clubs(
            self.minMembers,
            self.maxMembers,
            self.clubType,
            self.maxListLength,
            self.RequestedName,
        )
        AllianceSearchResultMessage(
            self.client, self.player, self.RequestedName, len(clubs), clubs
        ).send()
        return clubs
