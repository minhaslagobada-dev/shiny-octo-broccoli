from Logic.ClubService import ClubError, ClubService
from Packets.Messages.Server.Alliance.Alliance_Data_Message import AllianceDataMessage
from Packets.Messages.Server.Alliance.Events.AllianceEditOkMessage import AllianceEditOkMessage
from Packets.Messages.Server.Alliance.My_Alliance_Message import MyAllianceMessage
from Utils.Reader import BSMessageReader


class Edit_Settings_Message(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.clubDescription = self.read_string()
        self.inf2 = self.read_Vint()
        self.badgeID = self.read_Vint()
        self.inf4 = 0
        self.regionID = 0
        self.clubType = self.read_Vint()
        self.requiredTrophies = self.read_Vint()
        self.friendlyFamilly = None

    def process(self):
        try:
            club = ClubService.edit(
                self.player,
                self.clubDescription,
                self.badgeID,
                self.clubType,
                self.requiredTrophies,
                self.friendlyFamilly,
            )
        except ClubError as error:
            return str(error)
        AllianceEditOkMessage(self.client, self.player).send()
        MyAllianceMessage(self.client, self.player, club["id"]).send()
        for member_id in club["member_ids"]:
            if member_id != self.player.low_id:
                AllianceDataMessage(
                    self.client, self.player, 0, club["id"], member_override=True
                ).sendWithLowID(member_id)
        return club
