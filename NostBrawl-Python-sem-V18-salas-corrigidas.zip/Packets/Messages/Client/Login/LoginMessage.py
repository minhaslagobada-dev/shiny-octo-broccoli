import json
import logging
from contextlib import nullcontext

from Database.DatabaseManager import DataBase
from Logic.GameRoomGateway import GameRoomGateway
from Logic.GameRoomService import GameRoomService
from Logic.NotificationFactory import NotificationFactory
from Packets.Messages.Server.Alliance.AllianceStreamMessage import AllianceStreamMessage
from Packets.Messages.Server.Alliance.My_Alliance_Message import MyAllianceMessage
from Packets.Messages.Server.Gameroom.SetInvitesBlockedOkMessage import SetInvitesBlockedOkMessage
from Packets.Messages.Server.Home.OwnHomeDataMessage import OwnHomeDataMessage
from Packets.Messages.Server.Login.LoginFailedMessage import LoginFailedMessage
from Packets.Messages.Server.Login.LoginOkMessage import LoginOkMessage
from SCIDClient.Game import SCIDGame
from SCIDClient.Protocol import MAX_COMPRESSED_SIZE, decode_compressed_string
from SCIDClient.Models import SCIDError
from Utils.Config import Config
from Utils.Helpers import Helpers
from Utils.Reader import BSMessageReader


LOGGER = logging.getLogger(__name__)


class LoginMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.initial_bytes = initial_bytes
        self.player = player
        self.client = client
        self.scid_token = None
        self.scid_account = None
        self.scid_error = False
        self.banned = {"banned_low_id": []}

    def decode(self):
        self.enable_native_v13()
        self.player.high_id = self.read_int()
        self.player.low_id = self.read_int()
        self.player.token = self.read_string()

        self.major = self.read_int()
        self.minor = self.read_int()
        self.build = self.read_int()
        self.fingerprint_sha = self.read_string()

        self.read_string()
        self.player.device.OpenUDID = self.read_string()
        self.player.device.AndroidID = self.read_string()
        self.player.device.OSVersion = self.read_string()
        try:
            self._decode_optional_fields()
        except (ValueError, UnicodeError):
            self.scid_error = True

        try:
            with open("JSON/banned.json", "r", encoding="utf-8") as banned_file:
                self.banned = json.load(banned_file)
        except (OSError, ValueError):
            LOGGER.warning("Could not read JSON/banned.json; assuming no bans")

    def _at_end(self):
        return self.tell() >= len(self.initial_bytes)

    def _decode_optional_fields(self):
        if self._at_end():
            return
        self.readScId()
        self.read_string()
        if self._at_end():
            return
        self.read_string()
        if self._at_end():
            return
        self.read_string()
        if self._at_end():
            return
        self.read_boolean()
        if self._at_end():
            return
        self.read_string()
        self.read_string()
        if self._at_end():
            return
        self.read_string()
        if self._at_end():
            return
        self.read_boolean()
        self.read_string()
        if self._at_end():
            return
        self.read_int()
        if self._at_end():
            return
        self.read_Vint()
        self.read_string()
        self.read_string()
        if self._at_end():
            return
        self.read_string()
        if self._at_end():
            return
        self.read_string()
        self.read_string()
        self.read_Vint()
        if self._at_end():
            return
        self.read_string()
        self.read_string()
        self.read_string()
        if self._at_end():
            return

        envelope_offset = self.tell()
        envelope_size = self.read_int()
        if envelope_size == 0xFFFFFFFF:
            if not self._at_end():
                raise ValueError("Dados residuais após o campo SCID nulo")
            return
        if envelope_size < 4 or envelope_size > MAX_COMPRESSED_SIZE:
            raise ValueError("Campo SCID inválido")
        self._read_exact(envelope_size)
        token, end = decode_compressed_string(self.initial_bytes, envelope_offset)
        if end != len(self.initial_bytes):
            raise ValueError("Dados residuais após o token SCID")
        self.scid_token = token

    def _fail(self, error_code, message=""):
        hello_version = (
            getattr(self.player, "client_major", None),
            getattr(self.player, "client_minor", None),
            getattr(self.player, "client_build", None),
        )
        LOGGER.warning(
            "Login rejected: code=%s version=%s.%s.%s hello=%s maintenance=%s "
            "patch=%s fingerprint_match=%s received_sha=%s expected_sha=%s",
            error_code,
            self.major,
            self.minor,
            self.build,
            hello_version,
            self.player.maintenance,
            self.player.patch,
            self.fingerprint_sha == self.player.patch_sha,
            self.fingerprint_sha,
            self.player.patch_sha,
        )
        self.player.err_code = error_code
        self.player.logged_in = False
        LoginFailedMessage(self.client, self.player, message).send()
        return False

    def _send_success(self, defer_registration=False):
        LOGGER.info(
            "Login accepted: version=%s.%s.%s hello=%s maintenance=%s "
            "patch=%s fingerprint_match=%s",
            self.major,
            self.minor,
            self.build,
            (
                getattr(self.player, "client_major", None),
                getattr(self.player, "client_minor", None),
                getattr(self.player, "client_build", None),
            ),
            self.player.maintenance,
            self.player.patch,
            self.fingerprint_sha == self.player.patch_sha,
        )
        try:
            NotificationFactory.ensure_star_shelly(self.player)
            if NotificationFactory.has_scid_connection(self.player):
                NotificationFactory.ensure_wizard_barley(self.player)
        except Exception:
            LOGGER.exception("Could not create the login skin notifications")
        self.player.online = 2
        if not defer_registration:
            DataBase.replaceValue(self, "online", 2)
        LoginOkMessage(self.client, self.player).send()
        OwnHomeDataMessage(self.client, self.player).send()
        club_low_id = getattr(self.player, "club_low_id", 0) or 0
        if club_low_id:
            MyAllianceMessage(self.client, self.player, club_low_id).send()
            AllianceStreamMessage(self.client, self.player, club_low_id, 0).send()
        if int(getattr(self.player, "do_not_distrub", 0) or 0) == 1:
            SetInvitesBlockedOkMessage(self.client, self.player).send()
        if not defer_registration:
            self._resume_room()
        self.player.logged_in = True
        return True

    def _resume_room(self):
        GameRoomService.clear_offline_invites(self.player)
        if int(getattr(self.player, "room_id", 0) or 0) > 0:
            room = GameRoomService.resume(self.player)
            if room is not None:
                GameRoomGateway.broadcast_data(self.player, room, self.client)

    def process(self):
        settings = Config.GetValue()

        if self.major != settings["ClientMajor"]:
            return self._fail(
                8,
                "Your client is outdated. This server requires Brawl Stars "
                f"{settings['ClientMajor']}.{settings['ClientMinor']}.{settings['ClientBuild']}.",
            )

        if self.player.low_id in self.banned.get("banned_low_id", []):
            return self._fail(11, "This account is banned from the server.")

        if self.player.maintenance:
            return self._fail(10)

        if self.player.patch and self.fingerprint_sha != self.player.patch_sha:
            return self._fail(7)

        if self.scid_error:
            return self._fail(9, "Invalid Supercell ID credentials.")

        requested_low_id = self.player.low_id
        try:
            requested_low_id = SCIDGame.before_account_load(self, requested_low_id)
            if self.player.low_id in self.banned.get("banned_low_id", []):
                return self._fail(11, "This account is banned from the server.")
            new_account = requested_low_id == 0
            if not new_account and self.player.high_id != 0:
                return self._fail(9, "Invalid account credentials.")
            if new_account:
                self.player.low_id = Helpers.randomID(self)
                self.player.high_id = 0
                self.player.token = Helpers.randomStringDigits(self)
            elif not self.player.token:
                return self._fail(9, "Invalid account credentials.")
        except SCIDError as error:
            LOGGER.warning("SCID login rejected: %s", error.code)
            return self._fail(9, "Invalid Supercell ID credentials.")
        except Exception:
            LOGGER.exception("Database failure while preparing login")
            return self._fail(9, "Could not access the account database.")

        account_lock = getattr(self, "account_lock", None)
        with account_lock(self.player.low_id) if account_lock else nullcontext():
            try:
                if new_account:
                    DataBase.createAccount(self)
                else:
                    found = DataBase.loadAccount(self)
                    if found is False or self.player.low_id != requested_low_id:
                        return self._fail(9, "Invalid account credentials.")
                SCIDGame.after_account_load(self)
            except SCIDError as error:
                LOGGER.warning("SCID login rejected: %s", error.code)
                return self._fail(9, "Invalid Supercell ID credentials.")
            except Exception:
                LOGGER.exception("Database failure while processing login")
                return self._fail(9, "Could not access the account database.")

            finish_login = getattr(self, "finish_login", None)
            if finish_login is not None:
                return finish_login(self)
            return self._send_success()
