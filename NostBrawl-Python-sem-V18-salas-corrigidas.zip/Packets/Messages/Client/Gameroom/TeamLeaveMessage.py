from Logic.GameRoomGateway import GameRoomGateway
from Logic.GameRoomService import GameRoomService
from Packets.Messages.Server.Gameroom.TeamLeftMessage import TeamLeftMessage
from Utils.Reader import BSMessageReader


class TeamLeaveMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.enable_native_v13()
        self.player = player
        self.client = client

    def decode(self):
        self.ensure_end()

    def process(self):
        outcome = GameRoomService.leave_transition(self.player)
        room = outcome["room"]
        if room is not None:
            GameRoomGateway.broadcast_data_and_stream(self.player, room)
        if outcome["departed"]:
            TeamLeftMessage(self.client, self.player).send()
        for member in outcome["disbanded"]:
            GameRoomGateway.send_left(
                self.player,
                int(member["low_id"]),
                reason=GameRoomService.DISBAND_REASON,
            )
        if outcome["departed"]:
            GameRoomService.sync_presence(
                self.player, GameRoomService.HOME_PRESENCE
            )
        for member in outcome["disbanded"]:
            participant = member.get("_player")
            if participant is not None:
                GameRoomService.sync_presence(
                    participant, GameRoomService.HOME_PRESENCE
                )
        return room
