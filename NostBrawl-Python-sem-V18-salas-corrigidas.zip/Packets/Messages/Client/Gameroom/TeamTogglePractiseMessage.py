from Logic.GameRoomGateway import GameRoomGateway
from Logic.GameRoomService import GameRoomService
from Utils.Reader import BSMessageReader


class TeamTogglePractiseMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.enable_native_v13()
        self.player = player
        self.client = client

    def decode(self):
        self.ensure_end()

    def process(self):
        room = GameRoomService.toggle_practice(self.player)
        if room is not None:
            GameRoomGateway.broadcast_data(self.player, room, self.client)
        return room
