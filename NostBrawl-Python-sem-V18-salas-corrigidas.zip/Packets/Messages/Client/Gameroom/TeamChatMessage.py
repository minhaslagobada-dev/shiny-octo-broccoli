from Logic.GameRoomGateway import GameRoomGateway
from Logic.GameRoomService import GameRoomService
from Utils.Reader import BSMessageReader


class TeamChatMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.enable_native_v13()
        self.player = player
        self.client = client
        self.message = ""

    def decode(self):
        self.message = self.read_string()
        self.ensure_end()

    def process(self):
        room, chat = GameRoomService.add_chat(self.player, self.message)
        if room is None:
            return None
        GameRoomGateway.broadcast_data_and_stream(
            self.player, room, self.client, stream_first=True
        )
        return {"room": room, "chat": chat}
