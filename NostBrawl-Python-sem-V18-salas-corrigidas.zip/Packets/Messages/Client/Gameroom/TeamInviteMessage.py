from Logic.GameRoomGateway import GameRoomGateway
from Logic.GameRoomService import (
    GameRoomFullError, GameRoomInviteError, GameRoomService,
)
from Packets.Messages.Server.Gameroom.TeamErrorMessage import TeamErrorMessage
from Packets.Messages.Server.Gameroom.TeamInvitationMessage import TeamInvitationMessage
from Utils.Reader import BSMessageReader


class TeamInviteMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.enable_native_v13()
        self.player = player
        self.client = client
        self.high_id = 0
        self.recipient_id = 0
        self.invite_type = 0

    def decode(self):
        self.high_id = self.read_Vint()
        self.recipient_id = self.read_Vint()
        self.invite_type = self.read_Vint()
        self.ensure_end()

    def process(self):
        if self.high_id != 0:
            return None
        try:
            room, invite = GameRoomService.invite(
                self.player, self.recipient_id, self.invite_type
            )
        except GameRoomFullError:
            TeamErrorMessage(self.client, self.player, 25).send()
            return None
        except GameRoomInviteError as error:
            TeamErrorMessage(self.client, self.player, error.code).send()
            return None
        if room is None:
            return None
        GameRoomGateway.broadcast_data(self.player, room, self.client)
        delivered = TeamInvitationMessage(
            None, self.player, invite
        ).sendWithLowID(self.recipient_id)
        if not delivered:
            room, invite = GameRoomService.mark_invite(
                self.player, self.recipient_id, GameRoomService.INVITE_OFFLINE
            )
            if room is not None:
                GameRoomGateway.broadcast_data(self.player, room, self.client)
            TeamErrorMessage(
                self.client, self.player, GameRoomInviteError.OFFLINE
            ).send()
            return {"room": room, "invite": invite, "delivered": False}
        return {"room": room, "invite": invite, "delivered": True}
