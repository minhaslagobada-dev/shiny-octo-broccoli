from Logic.GameRoomGateway import GameRoomGateway
from Logic.GameRoomService import GameRoomFullError, GameRoomService
from Packets.Messages.Server.Gameroom.TeamErrorMessage import TeamErrorMessage
from Utils.Reader import BSMessageReader


class TeamSpectateMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.enable_native_v13()
        self.player = player
        self.client = client
        self.map_slot = 0
        self.room_id = 0
        self.requested_map = 0

    def decode(self):
        self.map_slot = self.read_Vint()
        self.room_id = self.read_Vint()
        self.requested_map = self.read_Vint()
        self.ensure_end()

    def process(self):
        room = None
        previous = None
        departed = False
        for room_id in dict.fromkeys(
            (self.room_id, self.requested_map, self.map_slot)
        ):
            if room_id <= 0:
                continue
            try:
                room, previous, departed = GameRoomService.request_join_transition(
                    self.player, room_id
                )
            except GameRoomFullError:
                TeamErrorMessage(self.client, self.player, 2).send()
                return None
            if room is not None:
                break
        if room is None:
            return None
        if departed:
            GameRoomGateway.send_left(
                self.player, self.player.low_id, client=self.client
            )
        if previous is not None:
            GameRoomGateway.broadcast_data_and_stream(self.player, previous)
        GameRoomGateway.broadcast_data_and_stream(
            self.player, room, self.client
        )
        return room
