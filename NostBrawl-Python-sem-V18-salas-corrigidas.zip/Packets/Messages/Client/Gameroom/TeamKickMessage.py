from Logic.GameRoomGateway import GameRoomGateway
from Logic.GameRoomService import GameRoomService
from Utils.Reader import BSMessageReader


class TeamKickMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.enable_native_v13()
        self.player = player
        self.client = client
        self.target_high_id = 0
        self.target_id = 0

    def decode(self):
        self.target_high_id = self.read_Vint()
        self.target_id = self.read_Vint()
        self.ensure_end()

    def process(self):
        if self.target_high_id != 0:
            return None
        outcome = GameRoomService.kick_transition(self.player, self.target_id)
        room = outcome["room"]
        target_id = outcome["target_id"]
        if not target_id:
            return None
        if room is not None:
            GameRoomGateway.broadcast_data_and_stream(self.player, room)
        GameRoomGateway.send_leave_ok(self.player, target_id)
        target = outcome["target"]
        if target is not None:
            GameRoomService.sync_presence(
                target, GameRoomService.HOME_PRESENCE
            )
        return room
