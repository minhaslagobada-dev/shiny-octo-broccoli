import copy

from Database.DatabaseManager import DataBase
from Files.CsvLogic.Skins import Skins
from Logic.GameRoomGateway import GameRoomGateway
from Logic.GameRoomService import GameRoomService
from Utils.Reader import BSMessageReader


class TeamChangeMemberSettingsMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.enable_native_v13()
        self.player = player
        self.client = client
        self.brawler_reference = (0, -1)
        self.skin_reference = (0, -1)
        self.unknown = 0

    def decode(self):
        self.unknown = self.read_Vint()
        self.skin_reference = self.readScId()
        self.ensure_end()

    def process(self):
        _, skin_id = self.skin_reference
        brawler_id = Skins.getBrawler(skin_id)
        self.brawler_reference = (16, int(brawler_id))
        self.player.brawler_id = int(brawler_id)
        self.player.skin_id = int(skin_id)
        selected = copy.deepcopy(getattr(self.player, "brawlers_skins", {}))
        if not isinstance(selected, dict):
            selected = {}
        selected[str(self.player.brawler_id)] = self.player.skin_id
        self.player.brawlers_skins = selected
        DataBase.replaceValue(self, "skinID", self.player.skin_id)
        DataBase.replaceValue(self, "brawlerID", self.player.brawler_id)
        DataBase.replaceValue(self, "brawlersSkins", selected)
        room = GameRoomService.set_member_settings(
            self.player, self.player.brawler_id, self.player.skin_id
        )
        if room is not None:
            GameRoomGateway.broadcast_data(self.player, room, self.client)
        return room
