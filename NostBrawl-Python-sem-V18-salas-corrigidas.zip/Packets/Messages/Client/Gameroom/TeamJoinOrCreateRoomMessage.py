from Logic.GameRoomGateway import GameRoomGateway
from Logic.GameRoomService import GameRoomFullError, GameRoomService
from Packets.Messages.Server.Gameroom.TeamErrorMessage import TeamErrorMessage
from Logic.TeamCode import TeamCode
from Utils.Reader import BSMessageReader


class TeamJoinOrCreateRoomMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.enable_native_v13()
        self.player = player
        self.client = client
        self.code = ""

    def decode(self):
        self.code = self.read_string()
        self.ensure_end()

    def process(self):
        try:
            high_id, room_id = TeamCode.to_id(self.code)
        except ValueError:
            return None
        if high_id != 0:
            return None
        previous = None
        departed = False
        if room_id == 0:
            room, previous, departed = GameRoomService.create_transition(
                self.player, 0, -64, 0, False
            )
        else:
            try:
                room, previous, departed = GameRoomService.request_join_transition(
                    self.player, room_id
                )
            except GameRoomFullError:
                TeamErrorMessage(self.client, self.player, 2).send()
                return None
        if room is None:
            return None
        if departed:
            GameRoomGateway.send_left(
                self.player, self.player.low_id, client=self.client
            )
        if previous is not None:
            GameRoomGateway.broadcast_data_and_stream(self.player, previous)
        GameRoomGateway.broadcast_data_and_stream(
            self.player, room, self.client
        )
        GameRoomService.sync_presence(self.player, GameRoomService.TEAM_PRESENCE)
        return room
