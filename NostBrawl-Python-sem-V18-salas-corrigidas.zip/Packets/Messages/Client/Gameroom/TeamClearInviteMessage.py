from Logic.GameRoomGateway import GameRoomGateway
from Logic.GameRoomService import GameRoomService
from Utils.Reader import BSMessageReader


class TeamClearInviteMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.enable_native_v13()
        self.player = player
        self.client = client
        self.high_id = 0
        self.low_id = 0

    def decode(self):
        self.high_id = self.read_int()
        self.low_id = self.read_int()
        self.ensure_end()

    def process(self):
        room, invite = GameRoomService.cancel_invite(
            self.player, self.high_id, self.low_id
        )
        if room is None:
            return None
        GameRoomGateway.broadcast_data(self.player, room, self.client)
        return {"room": room, "invite": invite}
