from Database.DatabaseManager import DataBase
from Packets.Messages.Server.Gameroom.SetInvitesBlockedOkMessage import SetInvitesBlockedOkMessage
from Utils.Reader import BSMessageReader


class SetInvitesBlockedMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.enable_native_v13()
        self.player = player
        self.client = client
        self.blocked = False

    def decode(self):
        self.blocked = self.read_boolean()
        self.ensure_end()

    def process(self):
        self.player.do_not_distrub = int(self.blocked)
        DataBase.replaceValue(self, "DoNotDistrub", self.player.do_not_distrub)
        SetInvitesBlockedOkMessage(self.client, self.player).send()
        return self.blocked
