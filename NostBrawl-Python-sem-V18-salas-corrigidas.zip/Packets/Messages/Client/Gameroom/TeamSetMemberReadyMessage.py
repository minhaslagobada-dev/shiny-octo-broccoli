from Logic.BattleInstances import BattleInstanceService
from Logic.GameRoomGateway import GameRoomGateway
from Logic.GameRoomService import GameRoomService
from Packets.Messages.Server.Battle.MatchMakingCancelledMessage import (
    MatchMakingCancelledMessage,
)
from Utils.Reader import BSMessageReader


class TeamSetMemberReadyMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.enable_native_v13()
        self.player = player
        self.client = client
        self.ready = False
        self.unknown = 0

    def decode(self):
        self.ready = self.read_boolean()
        self.unknown = self.read_Vint()
        self.ensure_end()

    def process(self):
        room = GameRoomService.set_ready(self.player, self.ready)
        if room is None:
            return None
        if self.ready:
            BattleInstanceService.begin(self.player)
        GameRoomGateway.broadcast_data(self.player, room, self.client)
        if self.ready:
            self.player.map_id = 15
            self.player.mmplayers = 1
            MatchMakingCancelledMessage(self.client, self.player).send()
        return room
