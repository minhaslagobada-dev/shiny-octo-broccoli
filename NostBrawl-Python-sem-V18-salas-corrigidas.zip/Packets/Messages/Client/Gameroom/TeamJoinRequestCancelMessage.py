from Logic.GameRoomGateway import GameRoomGateway
from Logic.GameRoomService import GameRoomService
from Utils.Reader import BSMessageReader


class TeamJoinRequestCancelMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.enable_native_v13()
        self.player = player
        self.client = client

    def decode(self):
        self.ensure_end()

    def process(self):
        affected = GameRoomService.cancel_join_requests(self.player)
        for room, requests in affected:
            for recipient_id in {
                int(request["recipient_id"]) for request in requests
            }:
                GameRoomGateway.send_data_to(
                    recipient_id, self.player, room
                )
        return {"cancelled": affected}
