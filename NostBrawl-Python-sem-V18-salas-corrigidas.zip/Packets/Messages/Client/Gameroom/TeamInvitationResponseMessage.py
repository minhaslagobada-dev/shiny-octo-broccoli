from Logic.GameRoomGateway import GameRoomGateway
from Logic.GameRoomService import GameRoomFullError, GameRoomService
from Packets.Messages.Server.Gameroom.TeamErrorMessage import TeamErrorMessage
from Utils.Reader import BSMessageReader


class TeamInvitationResponseMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.enable_native_v13()
        self.player = player
        self.client = client
        self.response_type = 0
        self.inviter_high_id = 0
        self.inviter_id = 0
        self.mute_sender = False

    def decode(self):
        self.response_type = self.read_Vint()
        self.inviter_high_id = self.read_int()
        self.inviter_id = self.read_int()
        self.mute_sender = self.read_boolean()
        self.ensure_end()

    def process(self):
        if self.inviter_high_id != 0:
            return None
        if self.response_type not in (1, 2, 3):
            return None
        accepted = self.response_type == 1
        previous = GameRoomService.for_player(self.player) if accepted else None
        try:
            if accepted:
                room, invite = GameRoomService.accept_invite_from(
                    self.player, self.inviter_id, mute_sender=self.mute_sender
                )
            else:
                room, invite = GameRoomService.decline_invite_from(
                    self.player, self.inviter_id, mute_sender=self.mute_sender
                )
        except GameRoomFullError:
            TeamErrorMessage(self.client, self.player, 2).send()
            return None
        if room is None:
            return None
        if accepted:
            if previous is not None and previous["id"] != room["id"]:
                GameRoomGateway.send_left(
                    self.player, self.player.low_id, client=self.client
                )
                previous = GameRoomService.get(previous["id"])
                if previous is not None:
                    GameRoomGateway.broadcast_data_and_stream(
                        self.player, previous
                    )
            GameRoomGateway.broadcast_data_and_stream(
                self.player, room, self.client
            )
            GameRoomService.sync_presence(
                self.player, GameRoomService.TEAM_PRESENCE
            )
        else:
            GameRoomGateway.broadcast_data(self.player, room)
        return {"room": room, "invite": invite, "accepted": accepted}
