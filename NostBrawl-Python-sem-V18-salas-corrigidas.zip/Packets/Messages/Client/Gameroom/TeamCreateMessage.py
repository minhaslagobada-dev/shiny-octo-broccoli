from Logic.GameRoomGateway import GameRoomGateway
from Logic.GameRoomService import GameRoomService
from Utils.Reader import BSMessageReader


class TeamCreateMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.enable_native_v13()
        self.player = player
        self.client = client
        self.map_slot = 0
        self.requested_map = 0
        self.room_type = 0
        self.practice = False
        self.has_optional_data = False
        self.optional_text = ""
        self.optional_value = 0
        self.optional_reference = (0, -1)

    def decode(self):
        self.requested_map = self.read_Vint()
        self.map_slot = self.read_Vint()
        self.room_type = self.read_Vint()
        self.practice = self.read_boolean()
        self.ensure_end()

    def process(self):
        room, previous, departed = GameRoomService.create_transition(
            self.player, self.map_slot, self.requested_map,
            self.room_type, self.practice,
        )
        if departed:
            GameRoomGateway.send_left(
                self.player, self.player.low_id, client=self.client
            )
        if previous is not None:
            GameRoomGateway.broadcast_data_and_stream(self.player, previous)
        GameRoomGateway.broadcast_data_and_stream(
            self.player, room, self.client
        )
        GameRoomService.sync_presence(self.player, GameRoomService.TEAM_PRESENCE)
        return room
