from Logic.GameRoomGateway import GameRoomGateway
from Logic.GameRoomService import GameRoomFullError, GameRoomService
from Packets.Messages.Server.Gameroom.TeamErrorMessage import TeamErrorMessage
from Utils.Reader import BSMessageReader


class TeamJoinRequestResponseMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.enable_native_v13()
        self.player = player
        self.client = client
        self.request_high_id = 0
        self.request_id = 0
        self.accepted = False
        self.mute_requester = False

    def decode(self):
        self.request_high_id = self.read_int()
        self.request_id = self.read_int()
        self.accepted = self.read_boolean()
        self.mute_requester = self.read_boolean()
        self.ensure_end()

    def process(self):
        if self.request_high_id != 0:
            return None
        try:
            outcome = GameRoomService.respond_join_request(
                self.player,
                self.request_id,
                self.accepted,
                self.mute_requester,
            )
        except GameRoomFullError:
            TeamErrorMessage(self.client, self.player, 2).send()
            return None
        if outcome is None:
            return None
        room = outcome["room"]
        if room is None:
            return outcome
        if outcome["accepted"]:
            previous = outcome["previous"]
            if previous is not None:
                GameRoomGateway.send_left(
                    self.player,
                    int(outcome["request"]["requester_id"]),
                )
                GameRoomGateway.broadcast_data(self.player, previous)
            GameRoomGateway.broadcast_data_and_stream(
                self.player, room, self.client
            )
            requester_id = int(outcome["request"]["requester_id"])
            requester = next(
                (
                    member.get("_player") for member in room.get("members", [])
                    if int(member["low_id"]) == requester_id
                ),
                None,
            )
            if requester is not None:
                GameRoomService.sync_presence(
                    requester, GameRoomService.TEAM_PRESENCE
                )
        else:
            GameRoomGateway.broadcast_data(self.player, room, self.client)
        return outcome
