from Logic.GameRoomGateway import GameRoomGateway
from Logic.GameRoomService import GameRoomFullError, GameRoomService
from Packets.Messages.Server.Gameroom.TeamErrorMessage import TeamErrorMessage
from Utils.Reader import BSMessageReader


class TeamRequestJoinMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.enable_native_v13()
        self.player = player
        self.client = client
        self.recipient_high_id = 0
        self.recipient_id = 0
        self.room_high_id = 0
        self.room_id = 0

    def decode(self):
        self.recipient_high_id = self.read_int()
        self.recipient_id = self.read_int()
        self.room_high_id = self.read_int()
        self.room_id = self.read_int()
        self.ensure_end()

    def process(self):
        if self.recipient_high_id != 0 or self.room_high_id != 0:
            return None
        try:
            room, request = GameRoomService.request_join_request(
                self.player, self.recipient_id, self.room_id
            )
        except GameRoomFullError:
            TeamErrorMessage(self.client, self.player, 45).send()
            return None
        if room is None:
            return None
        GameRoomGateway.send_data_to(self.recipient_id, self.player, room)
        return {"room": room, "request": request}
