from Utils.Reader import BSMessageReader
from Logic.PresenceService import PresenceService


class PlayerStatusMessage(BSMessageReader):
    NATIVE_STATUSES = frozenset((-1, 1, 2, 3, 4, 5, 7, 8, 10, 11))

    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.enable_native_v13()
        self.status = self.read_Vint()
        self.ensure_end()
        if self.status not in self.NATIVE_STATUSES:
            raise ValueError("Estado de presença inválido")

    def process(self):
        if not PresenceService.set_status(self.player, self.status, self.client, persist=True):
            raise ConnectionError("Sessão de presença substituída")
        PresenceService.publish(self.player)
        return self.status
