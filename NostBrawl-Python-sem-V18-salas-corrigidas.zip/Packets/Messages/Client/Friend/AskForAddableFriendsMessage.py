from Logic.FriendService import FriendError, FriendService
from Packets.Messages.Server.Friend.AddableFriendsMessage import AddableFriendsMessage
from Utils.Reader import BSMessageReader


class AskForAddableFriendsMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client
        self.facebook_ids = []
        self.game_center_ids = []

    def _read_ids(self):
        count = self.read_int()
        if count == -1:
            return []
        if not 0 <= count <= 10000:
            raise ValueError("Quantidade de contatos inválida")
        return [self.read_string() for _ in range(count)]

    def decode(self):
        self.facebook_ids = self._read_ids()
        self.game_center_ids = self._read_ids()

    def process(self):
        try:
            entries = FriendService.addable(
                self.player, self.facebook_ids, self.game_center_ids
            )
        except (FriendError, TypeError, ValueError):
            entries = []
        AddableFriendsMessage(self.client, self.player, entries).send()
        return entries
