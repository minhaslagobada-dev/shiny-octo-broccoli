from Logic.FriendService import FriendError, FriendService
from Logic.PresenceService import PresenceService
from Packets.Messages.Server.Friend.Events.AddFriendFailedMessage import AddFriendFailedMessage
from Packets.Messages.Server.Friend.FriendListUpdateMessage import FriendListUpdateMessage
from Utils.Reader import BSMessageReader


class AddFriend(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client
        self.high_id = 0
        self.low_id = 0
        self.source = 0
        self.unknown = 0

    def decode(self):
        self.high_id = self.read_int()
        self.low_id = self.read_int()
        self.source = self.read_int()
        self.unknown = self.read_int()
        self.ensure_end()

    def process(self):
        try:
            if self.high_id != 0:
                raise FriendError("Conta de amizade inexistente")
            result = FriendService.add(self.player, self.low_id, self.source)
        except (FriendError, TypeError, ValueError) as error:
            AddFriendFailedMessage(self.client, self.player).send()
            return {"accepted": False, "error": str(error)}
        FriendListUpdateMessage(
            self.client, self.player, result["entry"], refresh=True
        ).send()
        FriendListUpdateMessage(
            self.client, self.player, result["reverse_entry"], refresh=True
        ).sendWithLowID(result["friend_id"])
        if result["accepted"]:
            PresenceService.sync_pair(self.player, result["friend_id"])
        return result
