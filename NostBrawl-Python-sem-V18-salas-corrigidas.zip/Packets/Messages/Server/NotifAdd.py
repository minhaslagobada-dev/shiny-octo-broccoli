from Logic.ClubService import ClubService
from Logic.NotificationFactory import NotificationFactory
from Utils.Writer import Writer


class LogicAddNotificationCommand(Writer):
    def __init__(self, client, player, msg, notification=None):
        super().__init__(client)
        self.id = 24111
        self.player = player
        self.msg = msg
        self.notification = notification

    def encode(self):
        notification = self.notification
        if notification is None:
            club_id = int(getattr(self.player, "club_low_id", 0) or 0)
            notifications = ClubService.get_notifications(club_id, 1) if club_id else []
            notification = notifications[-1] if notifications else None
        self.writeVint(206)
        if notification is not None:
            self.writeVint(1)
            notification_type = int(notification.get("Type", 0) or 0)
            if notification_type == NotificationFactory.SKIN_REWARD_TYPE:
                self.writeVint(NotificationFactory.SKIN_REWARD_TYPE)
                self.writeVint(
                    NotificationFactory.SKIN_GLOBAL_ID
                    + NotificationFactory._skin_id(notification)
                )
                return
            if notification_type == 99:
                self.writeVint(99)
                NotificationFactory.encode_season(self, notification)
                return
            self.writeVint(82)
            self.writeInt(0)
            self.writeByte(0)
            self.writeInt(0)
            self.writeString(notification["text"])
            self.writeString(str(getattr(self.player, "name", "") or ""))
            name_color = int(getattr(self.player, "name_color", 0) or 0)
            profile_icon = int(getattr(self.player, "profile_icon", 0) or 0)
            self.writeVint(43000000 + name_color)
            self.writeVint(28000000 + profile_icon)
            self.writeVint(43000000 + name_color)
