from Utils.Writer import Writer


class TeamLeftMessage(Writer):
    def __init__(self, client, player, reason=0):
        super().__init__(client)
        self.enable_native_v13()
        self.id = 24125
        self.player = player
        self.reason = int(reason)

    def encode(self):
        self.writeInt(self.reason)
