from Utils.Writer import Writer


class TeamErrorMessage(Writer):
    def __init__(self, client, player, error, detail=0):
        super().__init__(client)
        self.enable_native_v13()
        self.id = 24129
        self.player = player
        self.error = int(error)
        self.detail = int(detail)

    def encode(self):
        self.writeVint(self.detail)
        self.writeVint(self.error)
