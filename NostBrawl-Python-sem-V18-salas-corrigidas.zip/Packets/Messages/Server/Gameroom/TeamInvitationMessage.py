from Logic.FriendPayload import encode_friend_entry
from Utils.Writer import Writer


class TeamInvitationMessage(Writer):
    INVITE_NOTIFICATION = 1

    def __init__(self, client, player, invite):
        super().__init__(client)
        self.enable_native_v13()
        self.id = 24589
        self.player = player
        self.invite = invite

    def encode(self):
        entry = self.invite.get("entry")
        if entry is None:
            raise ValueError("Convite sem perfil real do remetente")
        self.writeVint(self.INVITE_NOTIFICATION)
        self.writeLong(0, int(self.invite["sender_id"]))
        encode_friend_entry(self, entry)
