import time

from Utils.Writer import Writer


class TeamStreamMessage(Writer):
    def __init__(self, client, player, room=None, entries=None):
        super().__init__(client)
        self.enable_native_v13()
        self.id = 24131
        self.player = player
        self.room = room
        self.entries = entries

    def _base(self, entry):
        self.writeVint(0)
        self.writeVint(entry["id"])
        self.writeVint(0)
        self.writeVint(entry["player_id"])
        self.writeString(entry["player_name"])
        self.writeVint(entry.get("player_role", 0))
        age = max(0, int(time.time()) - int(entry["created_at"]))
        self.writeVint(age)
        self.writeBoolean(False)

    def encode(self):
        room = self.room
        if room is None:
            from Logic.GameRoomService import GameRoomService
            room = GameRoomService.for_player(self.player)
        room_id = int(room["id"]) if room is not None else 0
        entries = self.entries
        if entries is None and room is not None:
            from Logic.GameRoomService import GameRoomService
            entries = GameRoomService.stream(room_id)
        entries = entries or []
        self.writeVint(0)
        self.writeVint(room_id)
        self.writeVint(len(entries))
        for entry in entries:
            kind = int(entry["kind"])
            self.writeVint(kind)
            self._base(entry)
            if kind == 2:
                self.writeString(entry["message"])
            elif kind == 4:
                self.writeVint(entry["event"])
                self.writeBoolean(True)
                self.writeVint(0)
                self.writeVint(entry["target_id"])
                self.writeString(entry["target_name"])
            else:
                raise ValueError(f"Unknown team stream entry: {kind}")


TeamStream = TeamStreamMessage
