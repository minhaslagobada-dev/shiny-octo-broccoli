from Packets.Messages.Server.Gameroom.TeamLeftMessage import TeamLeftMessage


class TeamLeaveOkMessage(TeamLeftMessage):
    def __init__(self, client, player):
        super().__init__(client, player, 0)
