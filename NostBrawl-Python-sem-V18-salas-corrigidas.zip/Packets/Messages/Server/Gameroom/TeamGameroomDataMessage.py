from Logic.FriendPayload import encode_friend_entry
from Utils.Writer import Writer


class TeamGameroomDataMessage(Writer):
    def __init__(self, client, player, room=None):
        super().__init__(client)
        self.enable_native_v13()
        self.id = 24124
        self.player = player
        self.room = room

    def encode(self):
        room = self.room
        if room is None:
            from Logic.GameRoomService import GameRoomService
            room = GameRoomService.for_player(self.player)
        if room is None:
            room = {
                "id": 0, "type": 0, "slot_index": 0, "map_id": 0,
                "practice": False, "capacity": 0, "advertise_band": False,
                "advertise_friends": False, "members": [], "invites": [],
                "join_requests": [],
            }
        self.writeVint(room["type"])
        self.writeBoolean(room["practice"])
        self.writeVint(room.get("capacity", 0))
        self.writeLong(0, room["id"])
        self.writeVint(1)
        self.writeBoolean(room.get("advertise_band", False))
        self.writeBoolean(room.get("advertise_friends", False))
        self.writeVint(0)
        self.writeVint(room["slot_index"])
        self.writeScId(15, room["map_id"])
        members = room["members"]
        self.writeVint(len(members))
        for member in members:
            self.writeBoolean(member["host"])
            self.writeLong(member["high_id"], member["low_id"])
            self.writeString(member["name"])
            self.writeVint(0)
            self.writeScId(16, member["brawler_id"])
            self.writeScId(29, member["skin_id"])
            self.writeVint(member["trophies"])
            self.writeVint(member["highest_trophies"])
            self.writeVint(member["power_level"] + 1)
            self.writeVint(member["status"])
            self.writeBoolean(member["ready"])
            self.writeVint(member["team"])
            self.writeVint(0)
        invites = room.get("invites", [])
        self.writeVint(len(invites))
        for invite in invites:
            self.writeLong(0, invite["sender_id"])
            self.writeLong(0, invite["recipient_id"])
            self.writeString(invite["name"])
            self.writeVint(invite["invite_type"])
            self.writeVint(invite["status"])
        requests = room.get("join_requests", [])
        self.writeVint(len(requests))
        for request in requests:
            self.writeLong(request.get("key_high_id", 0), request["key"])
            self.writeLong(
                request.get("recipient_high_id", 0), request["recipient_id"]
            )
            encode_friend_entry(self, request["entry"])
