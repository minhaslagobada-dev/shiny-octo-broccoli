from Logic.LeaderboardService import LeaderboardService
from Packets.Messages.Server.Leaderboard.LeaderboardMessage import LeaderboardMessage


class GetLeaderboardGlobalOkMessage(LeaderboardMessage):
    def __init__(self, client, player, players=None):
        if players is None:
            players = LeaderboardService.players()
        super().__init__(client, player, 1, False, players)
