from Utils.Writer import Writer


class LeaderboardMessage(Writer):
    LIMIT = 200

    def __init__(
        self,
        client,
        player,
        leaderboard_type,
        is_local,
        entries,
        target_brawler=0,
    ):
        super().__init__(client)
        self.id = 24403
        self.version = 13
        self.player = player
        self.leaderboard_type = int(leaderboard_type)
        self.is_local = bool(is_local)
        self.entries = list(entries)
        self.target_brawler = int(target_brawler)
        self.region = str(getattr(player, "region", "BR") or "BR")
        if self.leaderboard_type not in (0, 1, 2):
            raise ValueError("Unsupported leaderboard type")

    def own_rank(self):
        default = 0 if self.leaderboard_type == 2 else 1
        if self.leaderboard_type == 2:
            own_id = int(getattr(self.player, "club_low_id", 0) or 0)
            key = "id"
        else:
            own_id = int(getattr(self.player, "low_id", 0) or 0)
            key = "low_id"
        for index, entry in enumerate(self.entries, 1):
            if int(entry.get(key, 0)) == own_id:
                return index
        return default

    def encode(self):
        displayed = self.entries[:self.LIMIT]
        self.writeVint(self.leaderboard_type)
        if self.leaderboard_type == 0:
            self.writeScId(16, self.target_brawler)
        else:
            self.writeVint(0)
        self.writeString(self.region if self.is_local else None)
        self.writeVint(len(displayed))

        for rank, entry in enumerate(displayed, 1):
            if self.leaderboard_type == 2:
                self.writeVint(0)
                self.writeVint(entry["id"])
                self.writeVint(rank)
                self.writeVint(entry["trophies"])
                self.writeVint(2)
                self.writeString(entry["name"])
                self.writeVint(entry["member_count"])
                self.writeScId(8, entry["badge_id"])
                continue

            self.writeVint(0)
            self.writeVint(entry["low_id"])
            self.writeVint(rank)
            self.writeVint(entry["trophies"])
            self.writeVint(1)
            self.writeString(entry["name"])
            self.writeString(entry.get("club_name") or None)
            self.writeVint(entry["player_experience"])
            self.writeScId(28, entry["profile_icon"])
            self.writeVint(0)

        self.writeVint(0)
        self.writeVint(self.own_rank())
        self.writeVint(0)
        self.writeVint(0)
        self.writeString(self.region)
