from Utils.Config import Config
from Utils.Writer import Writer


class LoginOkMessage(Writer):
    def __init__(self, client, player):
        super().__init__(client)
        self.player = player
        self.id = 20104
        self.version = 1
        self.enable_native_v13()

    def encode(self):
        settings = Config.GetValue()

                     
        self.writeInt(self.player.high_id)
        self.writeInt(self.player.low_id)

                  
        self.writeInt(self.player.high_id)
        self.writeInt(self.player.low_id)

        self.writeString(self.player.token)
        self.writeString()               
        self.writeString()                  

                                                                         
        self.writeInt(settings["ClientMajor"])
        self.writeInt(settings["ClientMinor"])
        self.writeInt(settings["ClientBuild"])

        self.writeString("dev")

        self.writeInt(0)                 
        self.writeInt(0)                     
        self.writeInt(0)                              

        self.writeString()
        self.writeString()
        self.writeString()
        self.writeInt(0)
        self.writeString()

        self.writeString(getattr(self.player, "region", settings.get("Region", "BR")))
        self.writeString()
        self.writeInt(1)

        self.writeString()
        self.writeString()
        self.writeString()
        self.writeVint(0)
        scid_token = getattr(self.player, "scid_token", None)
        if scid_token:
            self.writeCompressedString(scid_token)
        else:
            self.writeInt(-1)
        self.writeBoolean(True)
        self.writeBoolean(False)
