import json

from Logic.ClubService import ClubService
from Logic.SeasonService import SeasonService


class NotifManager:
    def __init__(self, player, client):
        self.plr = player
        self.cl = client

    def getClubNotifications(self):
        club_id = int(getattr(self.plr, "club_low_id", 0) or 0)
        if not club_id:
            return []
        return [json.dumps(item) for item in ClubService.get_notifications(club_id)]

    def getSysNotifications(self):
        return

    def SeasonEnd(self):
        return SeasonService.end_now(self.plr)

    def getAllNotif(self):
        return NotifManager(self.plr, self.cl).getClubNotifications().append(
            f"Привет, {self.plr.name}! Обновление от 20.11.2021 уже тут!\n"
            "Нововведения:\nКлубная почта"
        )
