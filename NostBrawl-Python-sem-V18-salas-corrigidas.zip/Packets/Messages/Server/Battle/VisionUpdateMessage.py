from Logic.Battle.Game.LogicGameObjectManager import LogicGameObjectManager
from Utils.BitStream import BitStream
from Utils.Writer import Writer


class VisionUpdateMessage(Writer):
    def __init__(self, client, player, room=None, participants=None):
        super().__init__(client)
        self.enable_native_v13()
        self.id = 24109
        self.player = player
        self.room = room if room is not None else getattr(player, "battle_room", None)
        self.participants = (
            participants if participants is not None
            else getattr(player, "battle_participants", None)
        )

    def encode(self):
        self.writeVint(self.player.battleTick)
        self.writeVint(self.player.dudu)
        self.writeVint(0)
        self.writeVint(0)
        stream = BitStream()
        LogicGameObjectManager.encode(self, stream, self.participants)
        self.writeInt(stream.size())
        self.writeBytes(stream.getBuff())
