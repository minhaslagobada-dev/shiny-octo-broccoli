import time

from Logic.Battle.BattleParticipants import BattleParticipants
from Utils.Writer import Writer


class StartLoadingMessage(Writer):
    def __init__(self, client, player, room=None, participants=None):
        super().__init__(client)
        self.enable_native_v13()
        self.id = 20559
        self.client = client
        self.player = player
        self.room = room
        self.participants = participants

    def encode(self):
        entries = self.participants
        if entries is None:
            entries = BattleParticipants.build(self.room, self.player)
        own_index = BattleParticipants.own_index(entries, self.player)
        own = entries[own_index]
        self.writeInt(len(entries))
        self.writeInt(own_index)
        self.writeInt(own["team"])
        self.writeInt(len(entries))
        for entry in entries:
            self.writeString(entry["name"])
            self.writeVint(entry["index"])
            self.writeVint(entry["team"])
            self.writeVint(0)
            self.writeInt(0)
            self.writeScId(16, entry["brawler_id"])
            self.writeScId(29, entry["skin_id"])
            self.writeBoolean(False)
        self.writeInt(0)
        self.writeInt(0)
        self.writeInt(int(time.time()))
        map_id = int(
            (self.room or {}).get(
                "map_id", getattr(self.player, "map_id", 7)
            )
        )
        self.writeVint(BattleParticipants.game_mode_variation(map_id))
        self.writeVint(1)
        self.writeVint(3)
        self.writeBoolean(False)
        self.writeVint(0)
        self.writeVint(19)
        self.writeScId(15, map_id)
