from Logic.FriendPayload import encode_friend_entry
from Logic.FriendService import FriendService
from Utils.Writer import Writer


class FriendListMessage(Writer):
    def __init__(self, client, player, entries=None, refresh=False):
        super().__init__(client)
        self.id = 20105
        self.player = player
        self.entries = entries
        self.refresh = bool(refresh)

    def _can_deliver(self, low_id):
        if self.refresh:
            self.entries = FriendService.friends_for_account(low_id)
        return True

    def encode(self):
        entries = self.entries
        if entries is None:
            entries = FriendService.friends(self.player)
        self.writeInt(0)
        self.writeBoolean(True)
        self.writeInt(len(entries))
        for entry in entries:
            encode_friend_entry(self, entry)
