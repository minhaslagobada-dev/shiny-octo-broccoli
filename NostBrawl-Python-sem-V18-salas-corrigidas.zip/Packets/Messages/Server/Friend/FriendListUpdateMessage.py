from Logic.FriendPayload import encode_friend_entry
from Logic.FriendService import FriendService
from Utils.Writer import Writer


class FriendListUpdateMessage(Writer):
    def __init__(self, client, player, entry, removed=False, refresh=False):
        super().__init__(client)
        self.id = 20106
        self.player = player
        self.entry = entry
        self.removed = bool(removed)
        self.refresh = bool(refresh)

    def _can_deliver(self, low_id):
        if not self.refresh:
            return True
        entry = FriendService.current_entry(low_id, self.entry["low_id"])
        if entry is None:
            return False
        self.entry = entry
        return True

    def encode(self):
        self.writeBoolean(self.removed)
        encode_friend_entry(self, self.entry)
