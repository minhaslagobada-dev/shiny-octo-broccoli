from Utils.Writer import Writer


class FriendOnlineStatusEntryMessage(Writer):
    def __init__(self, client, player, subject_id, status=None, elapsed=0):
        super().__init__(client)
        self.enable_native_v13()
        self.id = 24555
        self.player = player
        self.subject_id = int(subject_id)
        self.status = None if status is None else int(status)
        self.elapsed = int(elapsed)
        if not 0 < self.subject_id <= 0x7fffffff:
            raise ValueError("Conta de presença inválida")
        if self.status is not None and not 0 <= self.elapsed <= 0x7fffffff:
            raise ValueError("Duração de presença inválida")

    def encode(self):
        self.writeLong(0, self.subject_id)
        self.writeBoolean(self.status is not None)
        if self.status is not None:
            self.writeLong(0, self.subject_id)
            self.writeVint(self.status)
            self.writeVint(self.elapsed)
            self.writeBoolean(False)
