from Utils.Writer import Writer


class LobbyInfoMessage(Writer):
    """Small V13 lobby notification sent after authenticated messages."""

    def __init__(self, client, player):
        super().__init__(client)
        self.id = 23457
        self.player = player

    def encode(self):
        self.writeVint(1)
        self.writeString()
        self.writeVint(0)
