from Logic.ClubService import ClubService
from Utils.Writer import Writer


class MyAllianceMessage(Writer):
    def __init__(self, client, player, LowID):
        super().__init__(client)
        self.id = 24399
        self.version = 11
        self.player = player
        self.clubid = LowID

    def encode(self):
        club, role = ClubService.get_own_club(self.player)
        if club is None:
            self.writeVint(0)
            self.writeVint(0)
            return
        self.writeVint(club["online_count"])
        self.writeVint(1)
        self.writeVint(25)
        self.writeVint(role)
        self.writeInt(0)
        self.writeInt(club["id"])
        self.writeString(club["name"])
        self.writeVint(8)
        self.writeVint(club["badge_id"])
        self.writeVint(club["type"])
        self.writeVint(club["member_count"])
        self.writeVint(club["trophies"])
        self.writeVint(club["required_trophies"])
        self.writeVint(0)
        self.writeVint(club["online_count"])
