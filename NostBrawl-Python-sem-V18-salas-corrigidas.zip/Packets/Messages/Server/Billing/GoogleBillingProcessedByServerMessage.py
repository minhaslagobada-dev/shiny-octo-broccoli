from Utils.Writer import Writer


class GoogleBillingProcessedByServerMessage(Writer):
    def __init__(self, client, player, product, transaction_id, result=0):
        super().__init__(client)
        self.id = 20152
        self.player = player
        self.product = product
        self.transaction_id = transaction_id
        self.result = result

    def encode(self):
        self.writeString(self.product)
        self.writeString(self.transaction_id)
        self.writeInt(self.result)
