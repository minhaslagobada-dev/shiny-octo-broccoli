from Utils.Reader import BSMessageReader
from Packets.Commands.Client.LogicUpgradeBrawler import Upgrade_Brawler
from Packets.Commands.Client.LogicSetPlayerThumbnailCommand import LogicSetPlayerThumbnailCommand
from Packets.Commands.Client.LogicSetPlayerNameColorCommand import LogicSetPlayerNameColorCommand
from Packets.Commands.Client.LogicPurchaseBoxCommand import LogicPurchaseBoxCommand
from Packets.Commands.Client.LogicPurchaseOfferCommand import LogicPurchaseOfferCommand
from Packets.Commands.Client.LogicSelectSkinCommand import LogicSelectSkinCommand
from Packets.Commands.Client.LogicSelectBrawlerCommand import LogicSelectBrawlerCommand
from Packets.Commands.Client.LogicBoxDataEchoCommand import LogicBoxDataEchoCommand
from Packets.Commands.Client.LogicChangeResourcesEchoCommand import LogicChangeResourcesEchoCommand
from Packets.Commands.Client.LogicSetPlayerStarpowerCommand import LogicSetPlayerStarpowerCommand
from Packets.Commands.Client.LogicPurchaseHeroLvlUpMaterialCommand import LogicPurchaseHeroLvlUpMaterialCommand
from Packets.Commands.Client.LogicPurchaseDoubleCoinsCommand import LogicPurchaseDoubleCoinsCommand
from Packets.Commands.Client.LogicBuySkinCommand import LogicBuySkinCommand
from Packets.Commands.Client.LogicClearShopTickersCommand import LogicClearShopTickersCommand
from Packets.Commands.Client.LogicClaimRankUpRewardCommand import LogicClaimRankUpRewardCommand
from Packets.Commands.Client.LogicNewEventCommand import LogicNewEventCommand
from Packets.Commands.Client.LogicRemoveNewTagBrawler import LogicRemoveNewTagBrawler
from Packets.Commands.Client.LogicChangeAvatarNameCommand import LogicChangeAvatarNameCommand
from Packets.Commands.Client.LogicViewNotificationCommand import LogicViewNotificationCommand
from Packets.Commands.Client.LogicDeleteNotificationCommand import LogicDeleteNotificationCommand


COMMAND_HANDLERS = {
    201: LogicChangeAvatarNameCommand,
    500: LogicPurchaseBoxCommand,
    535: LogicPurchaseBoxCommand,
    517: LogicClaimRankUpRewardCommand,
    515: LogicClearShopTickersCommand,
    519: LogicPurchaseOfferCommand,
    503: LogicNewEventCommand,
    505: LogicSetPlayerThumbnailCommand,
    203: LogicBoxDataEchoCommand,
    207: LogicChangeResourcesEchoCommand,
    506: LogicSelectSkinCommand,
    507: LogicBuySkinCommand,
    525: LogicSelectBrawlerCommand,
    520: Upgrade_Brawler,
    521: LogicPurchaseHeroLvlUpMaterialCommand,
    522: LogicRemoveNewTagBrawler,
    509: LogicPurchaseDoubleCoinsCommand,
    527: LogicSetPlayerNameColorCommand,
    529: LogicSetPlayerStarpowerCommand,
    514: LogicDeleteNotificationCommand,
    528: LogicViewNotificationCommand,
}

                                                                         
                                                                            
                                                                       
IGNORED_COMMAND_ECHOES = {
    201: "avatar-name echo; SetNameMessage already handles the rename",
    203: "box/reward echo; the originating command already committed it",
    207: "resource echo; the originating command already committed it",
}


class EndClientTurn(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.client = client
        self.player = player
        self.initial_bytes = initial_bytes
        self.command_count = 0
        self.command_ids = []
        self.commandID = None

    def decode(self):
        self.read_Vint()
        self.tick = self.read_Vint()
        self.ping = self.read_Vint()
        self.command_count = self.read_Vint()
        if self.command_count < 0 or self.command_count > 64:
            raise ValueError(f"Invalid EndClientTurn command count: {self.command_count}")
                                                                            
                                                                         
        self.command_ids = []
        self.commandID = None

    def process(self):
        for index in range(self.command_count):
            command_id = self.read_Vint()
            self.commandID = command_id
            self.command_ids.append(command_id)
            print(
                f"Client | EndClientTurn commandID: {command_id}; "
                f"command: {index + 1}/{self.command_count}; "
                f"payload: {len(self.initial_bytes)} bytes; "
                f"remaining: {len(self.initial_bytes) - self.tell()} bytes; "
                f"payload_hex: {self.initial_bytes.hex()}; "
                f"remaining_hex: {self.initial_bytes[self.tell():].hex()}"
            )

            if command_id in IGNORED_COMMAND_ECHOES:
                print(
                    f"Client | CommandID {command_id} decoded but not applied: "
                    f"{IGNORED_COMMAND_ECHOES[command_id]}"
                )

            handler = COMMAND_HANDLERS.get(command_id)
            if handler is None:
                print(f"Client | CommandID {command_id} not handled")
                                                                            
                                                     
                return

            try:
                handler.decode(self)
            except ValueError as error:
                print(
                    f"Client | CommandID {command_id} ignored: "
                    f"incomplete/invalid payload ({error})"
                )
                return

            result = handler.process(self)
            if isinstance(result, str):
                print(f"Client | CommandID {command_id} rejected: {result}")

        return None
