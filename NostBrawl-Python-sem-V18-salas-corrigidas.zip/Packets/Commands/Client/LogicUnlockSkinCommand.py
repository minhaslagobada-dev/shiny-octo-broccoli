                                                                         
from Packets.Commands.Client.LogicBuySkinCommand import LogicBuySkinCommand


class LogicUnlockSkinCommand(LogicBuySkinCommand):
    pass
