from Files.CsvLogic.Cards import Cards
from Files.CsvLogic.Characters import Characters
from Files.CsvLogic.Skins import Skins
from Logic.Rewards import RewardError, RewardTransaction
from Utils.Reader import BSMessageReader


class LogicSelectBrawlerCommand(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.client = client
        self.player = player

    def decode(self):
        self.read_Vint()
        self.read_Vint()
        self.readLogicLong()
        self.brawler_reference = self.readScId()
        if self.brawler_reference[0] != 16 or self.brawler_reference[1] < 0:
            raise ValueError(
                f"Invalid brawler DataReference: {self.brawler_reference}"
            )
        self.brawler_id = self.brawler_reference[1]
        if self.brawler_id not in Characters.get_brawlers_id():
            raise ValueError(f"Invalid brawler ID: {self.brawler_id}")

    def process(self):
        try:
            brawler = int(self.brawler_id)
            states = getattr(self.player, "BrawlersUnlockedState", {})
            if states.get(str(brawler), states.get(brawler, 0)) != 1:
                raise RewardError("O brawler precisa estar desbloqueado")

            selected = getattr(self.player, "brawlers_skins", {})
            skin = int(selected.get(str(brawler), selected.get(brawler, 0)) or 0)
            if skin:
                owned = getattr(self.player, "UnlockedSkins", {}).get("Skins", [])
                if skin not in owned or Skins.getBrawler(skin) != brawler:
                    skin = 0

            transaction = RewardTransaction(self.player)
            transaction.set_value("brawler_id", "brawlerID", brawler)
            transaction.set_value("skin_id", "skinID", skin)
            transaction.set_value(
                "starpower", "starpower",
                Cards.get_spg_by_brawler_id(self, brawler, 4),
            )
            transaction.commit()
            return {"brawler": brawler, "skin": skin}
        except (RewardError, TypeError, ValueError) as error:
            return str(error)
