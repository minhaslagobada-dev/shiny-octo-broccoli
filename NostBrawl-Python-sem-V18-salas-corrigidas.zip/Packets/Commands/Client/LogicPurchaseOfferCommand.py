from Logic.RewardDelivery import RewardDelivery
from Logic.Rewards import RewardError
from Logic.ShopService import ShopService
from Utils.Reader import BSMessageReader


class LogicPurchaseOfferCommand(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client
        self.offer_index = 0
        self.target_reference = (0, -1)

    def decode(self):
        self.read_Vint()
        self.read_Vint()
        self.readLogicLong()
        self.offer_index = self.read_Vint()
        self.target_reference = self.readScId()

    def process(self):
        csv_id, item_id = self.target_reference
        if csv_id not in (0, 16):
            return "DataReference inválida para compra da oferta"
        selected_brawler = item_id if csv_id == 16 else 0
        try:
            result = ShopService.purchase(
                self.player, self.offer_index, selected_brawler
            )
        except (RewardError, TypeError, ValueError) as error:
            return str(error)
        RewardDelivery.send_many(self.client, self.player, result["responses"])
        return result
