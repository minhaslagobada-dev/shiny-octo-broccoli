from Files.CsvLogic.Skins import Skins
from Logic.RewardDelivery import RewardDelivery
from Logic.Rewards import RewardError
from Logic.SkinPurchase import SkinPurchase
from Utils.Reader import BSMessageReader


class LogicBuySkinCommand(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.read_Vint()
        self.read_Vint()
        self.readLogicLong()
        self.skin_reference = self.readScId()
        if self.skin_reference[0] != 29 or self.skin_reference[1] < 0:
            raise ValueError(f"Invalid skin DataReference: {self.skin_reference}")
        self.skin_id = self.skin_reference[1]
        self.brawler_id = Skins.getBrawler(self.skin_id)

    def process(self):
        try:
            result = SkinPurchase.purchase(
                self.player, self.skin_id, self.brawler_id
            )
        except (RewardError, ValueError) as error:
            return str(error)
        rewards = RewardDelivery.displays(result["rewardDetails"])
        RewardDelivery.send(self.client, self.player, {
            "kind": "item", "rewards": rewards,
        })
        return result
