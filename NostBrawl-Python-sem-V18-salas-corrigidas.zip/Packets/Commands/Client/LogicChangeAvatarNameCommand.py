from Utils.Reader import BSMessageReader


class LogicChangeAvatarNameCommand(BSMessageReader):
    """Decode the client's avatar-name echo without applying it again.

    SetNameMessage is the only handler allowed to rename the account. This
    decoder exists so a following EndClientTurn command remains aligned.
    """

    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client
        self.echoed_name = ""
        self.avatar_fields = []

    def decode(self):
                                                                            
                                                                         
        self.echoed_name = self.read_string()
        self.avatar_fields = [self.read_Vint() for _ in range(6)]

    def process(self):
        return {"ignored": "avatar-name echo", "name": self.echoed_name}
