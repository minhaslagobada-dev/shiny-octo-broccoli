from Utils.Reader import BSMessageReader


class LogicBoxDataEchoCommand(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.client = client
        self.player = player
        self.initial_bytes = initial_bytes

    @staticmethod
    def _count(reader, label):
        count = reader.read_Vint()
        if count < 0 or count > 64:
            raise ValueError(f"Invalid 203 {label}: {count}")
        return count

    def decode(self):
        self.box_type = self.read_Vint()
        self.box_count_or_type = self.box_type
        unit_count = LogicBoxDataEchoCommand._count(self, "unit count")
        self.box_count = unit_count
        self.box_id = 0
        self.rewards = []
        self.reward_units = []

        for unit_index in range(unit_count):
            unit_type = self.read_Vint()
            reward_count = LogicBoxDataEchoCommand._count(self, "reward count")
            if unit_index == 0:
                self.box_id = unit_type
            unit_rewards = []
            for _ in range(reward_count):
                amount = self.read_Vint()
                primary_reference = self.readScId()
                reward_type = self.read_Vint()
                secondary_reference = self.readScId()
                drop_data = self.read_Vint()
                reference = (
                    secondary_reference
                    if secondary_reference[0]
                    else primary_reference
                )
                reward = (amount, reward_type, reference)
                unit_rewards.append((reward, drop_data))
                self.rewards.append(reward)
            self.reward_units.append((unit_type, unit_rewards))

        self.trophy_road = self.read_Vint()
        self.turn_context = [self.read_Vint() for _ in range(5)]

    def process(self):
        return None
