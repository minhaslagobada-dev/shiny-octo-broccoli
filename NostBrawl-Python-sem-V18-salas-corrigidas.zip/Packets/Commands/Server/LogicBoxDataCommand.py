from Logic.Boxes import Boxes
from Utils.Writer import Writer


class LogicBoxDataCommand(Writer):
    def __init__(
        self, client, player, boxID=100, rewards=None, rewardNames=None,
        rewardsTargetBrawler=None, trophyRoad=0, rewardUnits=None, initial=None,
    ):
        super().__init__(client)
        self.id = 24111
        self.player = player
        box_type = boxID
        box_count = 1
        if isinstance(boxID, dict):
            result = boxID
            boxID = result["boxID"]
            box_type = result.get("boxType", boxID)
            box_count = result.get("boxCount", 1)
            rewards = result["rewards"]
            rewardNames = result["rewardNames"]
            rewardsTargetBrawler = result["rewardsTargetBrawler"]
            trophyRoad = result.get("trophyRoad", 0)
            rewardUnits = result.get("rewardUnits", rewardUnits)
            initial = result.get("initial", initial)
        self.boxID = boxID
        self.boxType = box_type
        self.boxCount = int(box_count)
        self.rewards = list(rewards or [])
        self.rewardNames = list(rewardNames or [])
        self.rewardsTargetBrawler = list(rewardsTargetBrawler or [])
        self.trophyRoad = trophyRoad
        self.rewardUnits = list(rewardUnits or [])
        self.initial = initial

    def getBoxType(self, boxID):
        try:
            return Boxes.get_box_type(boxID)
        except ValueError:
            return boxID

    @staticmethod
    def itemType(item):
        return {
            "Brawler": 1,
            "tokens_doubler": 2,
            "tickets": 3,
            "StarPower": 4,
            "UpgradePoints": 6,
            "Coins": 7,
            "gems": 8,
            "Skin": 9,
        }[item]

    @staticmethod
    def validateRewards(rewards, rewardNames, rewardsTargetBrawler):
        if not (
            len(rewards) == len(rewardNames) == len(rewardsTargetBrawler)
        ):
            raise ValueError("Reward arrays have different lengths")

    def _encode_rewards(self, rewards, rewardNames, rewardsTargetBrawler):
        self.writeVint(len(rewards))
        for amount, name, target in zip(
            rewards, rewardNames, rewardsTargetBrawler
        ):
            amount = int(amount)
            target = int(target)
            reward_type = self.itemType(name)
            if name in {"Coins", "gems", "tickets", "tokens_doubler"}:
                self.writeVint(amount)
                self.writeScId(0, reward_type)
                self.writeVint(0)
                self.writeVint(0)
                continue
            if name == "UpgradePoints":
                self.writeVint(amount)
                self.writeScId(16, target)
                self.writeVint(reward_type)
                self.writeVint(0)
                self.writeVint(0)
                continue
            self.writeVint(1)
            if name == "Skin":
                self.writeVint(0)
                self.writeVint(reward_type)
                self.writeScId(29, amount)
                self.writeVint(0)
                continue
            if name == "StarPower":
                self.writeScId(23, amount)
            else:
                self.writeScId(16, amount)
            self.writeVint(reward_type)
            self.writeVint(0)
            self.writeVint(0)

    def encode(self):
        if self.boxCount < 1:
            raise ValueError("Invalid box count")
        if self.rewardUnits:
            if len(self.rewardUnits) != self.boxCount:
                raise ValueError("Box count and reward units differ")
            units = self.rewardUnits
            initial = self.boxCount if self.initial is None else int(self.initial)
        else:
            units = [{
                "boxType": self.boxType,
                "rewards": self.rewards,
                "rewardNames": self.rewardNames,
                "rewardsTargetBrawler": self.rewardsTargetBrawler,
            }]
            initial = self.boxCount if self.initial is None else int(self.initial)
        for unit in units:
            self.validateRewards(
                unit["rewards"],
                unit["rewardNames"],
                unit["rewardsTargetBrawler"],
            )
        self.writeVint(203)
        self.writeVint(initial)
        self.writeVint(len(units))
        for unit in units:
            self.writeVint(self.getBoxType(unit.get("boxType", self.boxType)))
            self._encode_rewards(
                unit["rewards"],
                unit["rewardNames"],
                unit["rewardsTargetBrawler"],
            )
        self.writeVint(int(self.trophyRoad or 0))
        for _ in range(5):
            self.writeVint(0)
