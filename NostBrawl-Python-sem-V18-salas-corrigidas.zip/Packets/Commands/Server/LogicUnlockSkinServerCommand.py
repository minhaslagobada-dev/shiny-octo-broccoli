from Packets.Commands.Server.LogicSkinDataCommand import LogicSkinDataCommand


class LogicUnlockSkinServerCommand(LogicSkinDataCommand):
    """Resposta dedicada de desbloqueio de skin."""
