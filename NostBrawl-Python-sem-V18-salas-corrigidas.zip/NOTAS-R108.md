# NostBrawl R108

Servidor V13 completo, base R107. O ZIP contém somente `NostBrawl-R108/` e os arquivos do servidor. R106 e R107 permanecem preservadas.

## Correção do erro real de battleEnd

O aceite da R107 no APK produziu `AskForBattleEndMessage (14110)` com 126 bytes e desconexão por `Referência de local inválida`.

A R108 corrige a quarta e a quinta leituras do cabeçalho para `(mapSlot, mapID)`. A versão anterior interpretava esses valores como `(mapID, location)` e só aceitava `0` ou `15` no segundo campo, rejeitando o mapa real.

O estado de resultado não depende mais do falso `location == 15`: em modos não especiais, o servidor usa o `submitted_result` enviado pelo cliente, mantendo a regra de tutorial e o comportamento dos modos especiais.

## Evidência nativa

A análise usou somente a lib ARM64 R101 com SHA-256 `ccba455df76597e1d0ff081a07bf5e0537ad555229ad1166588d66d75ebff4ae`, Ghidra com image base zero e o procedimento ID → getter → vtable → encode/decode → helpers.

- `14110`: encode `0x3fc08c`, decode `0x148d58`; os dois campos são VInts consecutivos.
- `0x25ea2c` e `0x3f20a4`: copiam os dois inteiros do objeto de location para os globais usados em `0x3d1c78`.
- O mesmo par é carregado em `0x391120` e chega ao `TeamCreateMessage (14350)` por `0x41d61c`.
- `14350`: construtor `0x314d50`, encode `0x4011f8`; a ordem nativa é `(mapSlot, mapID, roomType)`.
- Um payload Solo independente de 126 bytes, com VInts executados na ARM64 em Unicorn, reproduziu o erro na R107 e foi aceito após o patch.

## Correções R107 preservadas

- Resultado e rank de Solo/Duo permanecem independentes.
- Batalhas diferentes em sequência são respondidas; replay continua deduplicado pelo hash do `14110`.
- Contadores de vitórias só avançam em vitória real.
- As sete variantes do `23456`, recompensas, transação, retorno ao lobby, Gameroom, perfil, Leaderboard, poder/skin, criptografia e SCID permanecem cobertos.

## Validação

- Suíte completa: **340/340 testes aprovados**.
- Inclui o pacote Solo de 126 bytes, leitura `(slot, mapa)`, resposta nativa completa e fluxo TCP.
- `config.json` e endereços de produção permanecem inalterados.
- Nenhum patch nativo foi necessário.
- **A R108 ainda não foi testada no APK neste ambiente.** A R107 falhou no aceite real acima; não se declara aceite da R108 sem novo teste no dispositivo.
