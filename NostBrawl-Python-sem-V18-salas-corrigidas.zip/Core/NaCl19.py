"""Primitives for the modified TweetNaCl bundled with the V13 reference.

This is a compatibility implementation for that client's Salsa19 variant, not
a general-purpose replacement for NaCl. It uses only Python's standard library.
"""

import hmac


_MASK32 = 0xFFFFFFFF
_FIELD_PRIME = (1 << 255) - 19
_POLY_PRIME = (1 << 130) - 5
_SIGMA = b"expand 32-byte k"


class VerificationError(Exception):
    pass


def _rotl32(value, shift):
    value &= _MASK32
    return ((value << shift) | (value >> (32 - shift))) & _MASK32


def _words(data):
    return [int.from_bytes(data[index:index + 4], "little") for index in range(0, len(data), 4)]


def _salsa19_core(input16, key32, constant16=_SIGMA, hsalsa=False):
    if len(input16) != 16 or len(key32) != 32 or len(constant16) != 16:
        raise ValueError("Invalid Salsa19 input size")

    constants = _words(constant16)
    key = _words(key32)
    input_words = _words(input16)
    x = [0] * 16

    for index in range(4):
        x[5 * index] = constants[index]
        x[1 + index] = key[index]
        x[6 + index] = input_words[index]
        x[11 + index] = key[4 + index]

    initial = x.copy()

                                                                        
    for _ in range(19):
        w = [0] * 16
        for column in range(4):
            t = [x[(5 * column + 4 * index) % 16] for index in range(4)]
            t[1] ^= _rotl32(t[0] + t[3], 7)
            t[2] ^= _rotl32(t[1] + t[0], 9)
            t[3] ^= _rotl32(t[2] + t[1], 13)
            t[0] ^= _rotl32(t[3] + t[2], 18)
            t = [value & _MASK32 for value in t]
            for index in range(4):
                w[4 * column + (column + index) % 4] = t[index]
        x = w

    if hsalsa:
        x = [(x[index] + initial[index]) & _MASK32 for index in range(16)]
        for index in range(4):
            x[5 * index] = (x[5 * index] - constants[index]) & _MASK32
            x[6 + index] = (x[6 + index] - input_words[index]) & _MASK32
        output = [x[5 * index] for index in range(4)]
        output += [x[6 + index] for index in range(4)]
    else:
        output = [(x[index] + initial[index]) & _MASK32 for index in range(16)]

    return b"".join(value.to_bytes(4, "little") for value in output)


def _xsalsa19_xor(data, nonce24, key32):
    if len(nonce24) != 24 or len(key32) != 32:
        raise ValueError("XSalsa19 requires a 24-byte nonce and a 32-byte key")

    subkey = _salsa19_core(nonce24[:16], key32, hsalsa=True)
    counter = bytearray(16)
    counter[:8] = nonce24[16:]
    result = bytearray()

    for offset in range(0, len(data), 64):
        stream = _salsa19_core(bytes(counter), subkey)
        block = data[offset:offset + 64]
        result.extend(
            value ^ stream[index] for index, value in enumerate(block)
        )
        value = (int.from_bytes(counter[8:], "little") + 1) & ((1 << 64) - 1)
        counter[8:] = value.to_bytes(8, "little")

    return bytes(result)


def _poly1305(message, key32):
    if len(key32) != 32:
        raise ValueError("Poly1305 requires a 32-byte one-time key")

    r = int.from_bytes(key32[:16], "little")
    r &= 0x0FFFFFFC0FFFFFFC0FFFFFFC0FFFFFFF
    s = int.from_bytes(key32[16:], "little")
    accumulator = 0

    for offset in range(0, len(message), 16):
        chunk = message[offset:offset + 16]
        number = int.from_bytes(chunk + b"\x01", "little")
        accumulator = ((accumulator + number) * r) % _POLY_PRIME

    return ((accumulator + s) & ((1 << 128) - 1)).to_bytes(16, "little")


def secretbox(message, nonce24, key32):
    """Return MAC + ciphertext, matching the reference C Python wrapper."""
                                                                             
                                                                    
    ciphertext = _xsalsa19_xor(bytes(32) + message, nonce24, key32)[32:]
    poly_key = _xsalsa19_xor(bytes(32), nonce24, key32)
    return _poly1305(ciphertext, poly_key) + ciphertext


def secretbox_open(ciphertext, nonce24, key32):
    if len(ciphertext) < 16:
        raise VerificationError("Ciphertext is too short")

    signature = ciphertext[:16]
    encrypted = ciphertext[16:]
    poly_key = _xsalsa19_xor(bytes(32), nonce24, key32)
    expected = _poly1305(encrypted, poly_key)
    if not hmac.compare_digest(signature, expected):
        raise VerificationError("Ciphertext failed verification")
    return _xsalsa19_xor(bytes(32) + encrypted, nonce24, key32)[32:]


def scalarmult(scalar32, point32):
    """Curve25519 scalar multiplication used by the reference TweetNaCl."""
    if len(scalar32) != 32 or len(point32) != 32:
        raise ValueError("Curve25519 values must contain 32 bytes")

    scalar = bytearray(scalar32)
    scalar[0] &= 248
    scalar[31] &= 127
    scalar[31] |= 64

    point = bytearray(point32)
    point[31] &= 127
    x1 = int.from_bytes(point, "little")
    x2, z2 = 1, 0
    x3, z3 = x1, 1
    swap = 0

    for bit_index in range(254, -1, -1):
        bit = (scalar[bit_index >> 3] >> (bit_index & 7)) & 1
        swap ^= bit
        if swap:
            x2, x3 = x3, x2
            z2, z3 = z3, z2
        swap = bit

        a = (x2 + z2) % _FIELD_PRIME
        aa = (a * a) % _FIELD_PRIME
        b = (x2 - z2) % _FIELD_PRIME
        bb = (b * b) % _FIELD_PRIME
        e = (aa - bb) % _FIELD_PRIME
        c = (x3 + z3) % _FIELD_PRIME
        d = (x3 - z3) % _FIELD_PRIME
        da = (d * a) % _FIELD_PRIME
        cb = (c * b) % _FIELD_PRIME
        x3 = ((da + cb) ** 2) % _FIELD_PRIME
        z3 = (x1 * ((da - cb) ** 2)) % _FIELD_PRIME
        x2 = (aa * bb) % _FIELD_PRIME
        z2 = (e * (aa + 121665 * e)) % _FIELD_PRIME

    if swap:
        x2, x3 = x3, x2
        z2, z3 = z3, z2

    result = (x2 * pow(z2, _FIELD_PRIME - 2, _FIELD_PRIME)) % _FIELD_PRIME
    return result.to_bytes(32, "little")


def scalarmult_base(scalar32):
    return scalarmult(scalar32, bytes([9]) + bytes(31))


def box_beforenm(public_key32, private_key32):
    shared = scalarmult(private_key32, public_key32)
    return _salsa19_core(bytes(16), shared, hsalsa=True)
