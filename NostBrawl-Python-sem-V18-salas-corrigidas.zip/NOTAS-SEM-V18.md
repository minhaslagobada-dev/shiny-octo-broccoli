# Servidor Python sem o conjunto V18

Base: `NostBrawl-R122` (o servidor original continua intacto e sem alterações).
Este pacote é uma cópia de trabalho com o conjunto **V18** removido.

## O que foi removido

1. `Logic/SkinPurchase.py`
   - Removidos `V18_PRICE_GROUPS`, `V18_SKIN_PRICES`, `V18_GOLD_REQUIREMENTS`.
   - Removido `SkinPurchase.required_skin_for()` (só existia para a regra dourada V18).
   - `SkinPurchase.price_for()` agora usa exclusivamente o CSV oficial de skins
     (`Files/CsvLogic/Skins.py` → `GameAssets/csv_logic/skins.csv`).
   - `SkinPurchase.purchase()` não faz mais a checagem de "skin dourada exige a
     prateada" e não devolve mais a chave `v18PriceRule`.
   - O restante do fluxo permanece igual: validação de skin/brawler, exigência de
     brawler desbloqueado, bloqueio de compra repetida, cobrança de gemas dentro
     de `RewardTransaction` (atômica), resposta com `skin`, `brawler`, `price` e
     `isDefaultSkin`.

2. `tests/test_box_trophy_road.py`
   - `SkinPurchaseV18Tests` substituído por `SkinPurchaseTests`, agora validando os
     preços do CSV V13 (25 skins pagas, de brawlers disponíveis na V13).
   - Import de `V18_GOLD_REQUIREMENTS` / `V18_PRICE_GROUPS` / `V18_SKIN_PRICES` removido.
   - Renomeações internas de teste: `V18RNG` → `BoxRNG`, `V18BoxGeneratorTests` →
     `BoxGeneratorTests` (o gerador de caixas não foi alterado).

3. Comentários/docstrings que citavam V18 em
   `Packets/Commands/Server/LogicUnlockSkinServerCommand.py` e
   `Packets/Commands/Client/LogicRemoveNewTagBrawler.py` (só texto, nenhuma lógica).

## O que NÃO mudou

- Gerador de caixas, eventos, troféu de estrada, loja, clube, equipes, amigos,
  SCID, criptografia, banco SQLite e todos os pacotes do protocolo.
- Nenhum preço, requisito ou comportamento foi inventado: os valores agora vêm
  do CSV V13 já presente no projeto.

## Verificação

- `python3 -m pytest tests/ -q` → **466 passed, 564 subtests passed**.
- Servidor sobe com `python3 main.py` (porta de `config.json`), login responde
  `20104` (LoginOk), `24101` (OwnHomeData) e `20105` (FriendList), além de
  perfil `24113` e ranking `24403`.

## Observação

Nenhuma referência a `V18`/`v18` permanece no código ou nos testes deste pacote.
