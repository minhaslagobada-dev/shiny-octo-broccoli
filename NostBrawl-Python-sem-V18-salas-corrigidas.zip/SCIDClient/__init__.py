"""LakeyID/Supercell ID integration for NostBrawl."""
