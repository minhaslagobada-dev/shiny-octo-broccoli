import struct
import zlib


MAX_COMPRESSED_SIZE = 900000
MAX_TOKEN_SIZE = 16384


def encode_compressed_string(value):
    raw = str(value).encode("utf-8")
    compressed = zlib.compress(raw, 9)
    return struct.pack(">i", len(compressed) + 4) + struct.pack("<I", len(raw)) + compressed


def decode_compressed_string(payload, offset=0, max_size=MAX_TOKEN_SIZE):
    if offset < 0 or offset + 12 > len(payload):
        raise ValueError("Compressed string incompleta")
    size = int.from_bytes(payload[offset:offset + 4], "big", signed=True)
    if size < 4 or size - 4 > MAX_COMPRESSED_SIZE:
        raise ValueError("Tamanho de compressed string inválido")
    end = offset + 4 + size
    if end > len(payload):
        raise ValueError("Compressed string truncada")
    expected = int.from_bytes(payload[offset + 4:offset + 8], "little")
    if expected > max_size:
        raise ValueError("Compressed string expandida demais")
    compressed = payload[offset + 8:end]
    decompressor = zlib.decompressobj()
    try:
        raw = decompressor.decompress(compressed, expected + 1)
        if len(raw) > expected or decompressor.unconsumed_tail:
            raise ValueError("Compressed string excede o tamanho declarado")
        raw += decompressor.flush()
    except zlib.error as error:
        raise ValueError("Zlib inválido") from error
    if not decompressor.eof or decompressor.unused_data or len(raw) != expected:
        raise ValueError("Compressed string inconsistente")
    return raw.decode("utf-8"), end


def extract_scid_token(payload, start, validator):
    if start < 0 or start >= len(payload):
        return None
    for offset in range(start, len(payload) - 11):
        size = int.from_bytes(payload[offset:offset + 4], "big", signed=True)
        if size < 6 or size - 4 > MAX_COMPRESSED_SIZE:
            continue
        end = offset + 4 + size
        if end != len(payload) and not (
            end + 1 == len(payload) and payload[end] in (0, 1)
        ):
            continue
        expected = int.from_bytes(payload[offset + 4:offset + 8], "little")
        if expected < 1 or expected > MAX_TOKEN_SIZE or payload[offset + 8] != 0x78:
            continue
        try:
            value, _ = decode_compressed_string(payload, offset)
        except (ValueError, UnicodeError):
            continue
        if validator(value):
            return value
    return None
