import sqlite3
from contextlib import closing
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import quote


class SCIDError(Exception):
    def __init__(self, code):
        super().__init__(code)
        self.code = code


@dataclass
class SCIDAccount:
    id: int
    identity: str
    scid: str
    bind_token: str
    game_low_id: int
    email_marketing_permission: bool
    marketing_consents: dict
    avatar_image: object
    profile_name: str
    block_incoming_friend_requests: bool


class LocalGameAccounts:
    def __init__(self, database_path):
        self.database_path = str(database_path)

    def _connect(self):
        path = Path(self.database_path).expanduser().resolve()
        uri = "file:" + quote(path.as_posix(), safe="/:") + "?mode=ro"
        connection = sqlite3.connect(uri, uri=True, timeout=10)
        connection.row_factory = sqlite3.Row
        return connection

    def game_account(self, low_id):
        with closing(self._connect()) as connection:
            return self._game_row(connection, low_id=int(low_id))

    def game_by_token(self, token, low_id=None):
        with closing(self._connect()) as connection:
            return self._game_row(connection, token=token, low_id=low_id)

    @staticmethod
    def _game_row(connection, low_id=None, token=None):
        if low_id is not None and token is not None:
            row = connection.execute(
                "SELECT lowID, token, name FROM players WHERE lowID = ? AND token = ?",
                (int(low_id), str(token)),
            ).fetchone()
        elif low_id is not None:
            row = connection.execute(
                "SELECT lowID, token, name FROM players WHERE lowID = ?",
                (int(low_id),),
            ).fetchone()
        elif token is not None:
            row = connection.execute(
                "SELECT lowID, token, name FROM players WHERE token = ?",
                (str(token),),
            ).fetchone()
        else:
            return None
        if row is None:
            return None
        return {
            "low_id": int(row["lowID"]),
            "token": row["token"],
            "name": row["name"],
        }
