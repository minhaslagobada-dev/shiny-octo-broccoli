import logging
import threading
from contextlib import nullcontext


LOGGER = logging.getLogger(__name__)


class ActiveGameSessions:
    def __init__(self):
        self._sessions = {}
        self._lock = threading.Lock()

    def register(self, player, client, address=None):
        low_id = int(getattr(player, "low_id", 0) or 0)
        if low_id <= 0:
            return
        remote = address[0] if isinstance(address, (tuple, list)) and address else None
        with self._lock:
            self._sessions[low_id] = {
                "player": player,
                "client": client,
                "address": remote,
                "token": getattr(player, "token", ""),
                "reward_lock": threading.RLock(),
                "account_lock": (getattr(player, "ClientDict", None) or {}).get("AccountLock"),
                "wizard_reward_delivered": False,
            }

    def unregister(self, player, client):
        low_id = int(getattr(player, "low_id", 0) or 0)
        with self._lock:
            current = self._sessions.get(low_id)
            if current is not None and current["client"] is client:
                del self._sessions[low_id]

    def clear(self):
        with self._lock:
            self._sessions.clear()

    def unique_at_address(self, address):
        if not address:
            return None
        with self._lock:
            matches = [value for value in self._sessions.values()
                       if value["address"] == address]
        if len(matches) != 1:
            return None
        session = matches[0]
        return {"low_id": int(session["player"].low_id),
                "token": session["token"], "name": getattr(session["player"], "name", "")}

    def notify_registration(self, low_id):
        low_id = int(low_id)
        while True:
            with self._lock:
                session = self._sessions.get(low_id)
            if session is None:
                return False
            account_lock = session.get("account_lock")
            with account_lock(low_id) if account_lock else nullcontext():
                with self._lock:
                    if self._sessions.get(low_id) is not session:
                        continue
                with session["reward_lock"]:
                    if session["wizard_reward_delivered"]:
                        return False
                    player = session["player"]
                    try:
                        from SCIDClient.Runtime import get_service
                        service = get_service()
                        account = service.store.by_game(low_id) if service is not None else None
                        if account is None:
                            return False
                        player.scid_account = account
                        from Logic.NotificationFactory import NotificationFactory
                        from Packets.Messages.Server.NotifAdd import LogicAddNotificationCommand
                        NotificationFactory.ensure_wizard_barley(player)
                        notification = next(
                            (
                                value
                                for value, skin_id in NotificationFactory._entries(player.Notifications)
                                if skin_id == NotificationFactory.WIZARD_BARLEY_SKIN_ID
                                and not NotificationFactory._read(value)
                            ),
                            None,
                        )
                        if notification is None:
                            return False
                        LogicAddNotificationCommand(
                            session["client"], player, None, notification=notification
                        ).send()
                        session["wizard_reward_delivered"] = True
                        LOGGER.info("SCID Wizard Barley notification sent for game %s", low_id)
                        return True
                    except Exception:
                        LOGGER.exception("Could not deliver SCID registration reward")
                        return False



GAME_SESSIONS = ActiveGameSessions()
