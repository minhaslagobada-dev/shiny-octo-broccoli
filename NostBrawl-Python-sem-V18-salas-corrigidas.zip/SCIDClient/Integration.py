import hashlib
import hmac
import secrets


API_PREFIX = "/internal/game/v1"
NONCE_TTL_SECONDS = 120
MAX_TIMESTAMP_SKEW_SECONDS = 60


def key_bytes(value):
    key = str(value or "").encode("utf-8")
    if len(key) < 32:
        raise ValueError("A chave de integração SCID deve ter pelo menos 32 bytes")
    return key


def new_nonce():
    return secrets.token_hex(16)


def request_signature(key, method, path, timestamp, nonce, body):
    canonical = b"\n".join((
        b"SCID-GAME-REQUEST-V1",
        method.upper().encode("ascii"),
        path.encode("utf-8"),
        str(int(timestamp)).encode("ascii"),
        nonce.encode("ascii"),
        hashlib.sha256(body).hexdigest().encode("ascii"),
    ))
    return hmac.new(key_bytes(key), canonical, hashlib.sha256).hexdigest()


def response_signature(key, nonce, body):
    canonical = b"\n".join((
        b"SCID-GAME-RESPONSE-V1",
        nonce.encode("ascii"),
        hashlib.sha256(body).hexdigest().encode("ascii"),
    ))
    return hmac.new(key_bytes(key), canonical, hashlib.sha256).hexdigest()


def signatures_match(expected, received):
    if not isinstance(expected, str) or not isinstance(received, str):
        return False
    try:
        return hmac.compare_digest(expected, received.lower())
    except TypeError:
        return False


def account_data(account):
    if account is None:
        return None
    return {
        "id": int(account.id),
        "identity": account.identity,
        "scid": account.scid,
        "bind_token": account.bind_token,
        "game_low_id": int(account.game_low_id or 0),
        "email_marketing_permission": bool(account.email_marketing_permission),
        "marketing_consents": dict(account.marketing_consents),
        "avatar_image": account.avatar_image,
        "profile_name": account.profile_name,
        "block_incoming_friend_requests": bool(
            account.block_incoming_friend_requests
        ),
    }


def account_from_data(data):
    if data is None:
        return None
    if not isinstance(data, dict):
        raise ValueError("Conta SCID remota inválida")
    from SCIDClient.Models import SCIDAccount

    account_id = int(data["id"])
    game_low_id = int(data.get("game_low_id") or 0)
    identity = data["identity"]
    scid = data["scid"]
    bind_token = data["bind_token"]
    if (account_id <= 0 or game_low_id < 0
            or not all(isinstance(value, str) and value
                       for value in (identity, scid, bind_token))):
        raise ValueError("Conta SCID remota inválida")
    consents = data.get("marketing_consents", {})
    if not isinstance(consents, dict):
        raise ValueError("Consentimentos SCID remotos inválidos")
    return SCIDAccount(
        id=account_id,
        identity=identity,
        scid=scid,
        bind_token=bind_token,
        game_low_id=game_low_id,
        email_marketing_permission=bool(
            data.get("email_marketing_permission", False)
        ),
        marketing_consents={
            str(scope): bool(consent) for scope, consent in consents.items()
        },
        avatar_image=data.get("avatar_image"),
        profile_name=str(data.get("profile_name") or "Player"),
        block_incoming_friend_requests=bool(
            data.get("block_incoming_friend_requests", False)
        ),
    )
