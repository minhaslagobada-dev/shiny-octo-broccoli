from SCIDClient.Models import SCIDError
from SCIDClient.Runtime import get_service
from Utils.Config import Config


class SCIDGame:
    @staticmethod
    def enabled():
        return bool(Config.GetValue().get("SCID", {}).get("Enabled", True))

    @classmethod
    def before_account_load(cls, message, requested_low_id):
        token = getattr(message, "scid_token", None)
        if not token or not cls.enabled():
            return requested_low_id
        service = get_service()
        if service is None:
            raise SCIDError("scid_unavailable")
        account = service.authenticate(token)
        if account is None:
            raise SCIDError("invalid_token")
        message.scid_account = account
        if account.game_low_id:
            if requested_low_id and requested_low_id != account.game_low_id:
                raise SCIDError("game_account_bound")
            game = service.store.game_account(account.game_low_id)
            if game is None:
                raise SCIDError("game_account_not_found")
            message.player.low_id = game["low_id"]
            message.player.high_id = 0
            message.player.token = game["token"]
            return game["low_id"]
        return requested_low_id

    @classmethod
    def after_account_load(cls, message):
        if not cls.enabled():
            return
        account = getattr(message, "scid_account", None)
        supplied_token = getattr(message, "scid_token", None)
        service = get_service()
        if service is None:
            raise SCIDError("scid_unavailable")
        if account is not None:
            if account.game_low_id == 0:
                service.link_game(account, message.player.low_id)
                account = service.store.by_id(account.id)
                message.scid_account = account
                supplied_token = None
            if account.game_low_id != message.player.low_id:
                raise SCIDError("game_account_bound")
            message.player.scid_account = account
            message.player.scid_token = supplied_token or service.tokens.issue(account)
            return
        account, token = service.token_for_game(message.player.low_id)
        if account is not None:
            message.player.scid_account = account
            message.player.scid_token = token
