# NostBrawl R109

Servidor completo V13 **13.283.1**, derivado da R108. A entrega contém somente o servidor; não inclui APK, patch nativo, dependências nem caches. R106, R107 e R108 permanecem preservadas.

## Diagnóstico do BattleEnd 14110

A rejeição `Resultado BattleEnd inválido` não foi tratada com exceção genérica, ampliação arbitrária de faixas ou descarte do pacote. A auditoria encontrou incompatibilidades estruturais entre a R108 e a LIB R101 ARM64:

1. A R108 lia o quarto e o quinto VInt como `mapSlot,mapID`. O fluxo nativo transporta `evento+0,evento+4`; `evento+4` é o slot e `evento+0` é o identificador do mapa utilizado nesse fluxo. O decoder R109 volta a ler `mapID,mapSlot`.
2. A home enviava `slot,slot` nos eventos. O cliente reutiliza esses campos no `TeamCreate` e no `14110`, portanto um mapa Showdown podia chegar ao servidor com o identificador de um mapa comum e ter seu rank rejeitado no ramo 3v3. A R109 envia `mapID,slot` e mantém a location `15,mapID` no campo próprio.
3. A R108 exigia `0,1,2` no primeiro VInt inclusive em Solo/Duo. Na R101, esse campo contém o resultado para modos comuns, mas contém rank em Solo/Duo. O terceiro VInt também carrega rank nesses dois modos.
4. O `TeamCreate` estava com os mesmos dois campos invertidos. `TeamJoin` e `TeamSpectate` já usavam `mapID,slot` e não foram alterados.
5. A tabela do `StartLoading` enviava variação `1` para quase todos os modos e usava Solo/Duo como `6/6`; esse valor não reproduzia a conversão nativa de nomes nem a distinção Solo/Duo da LIB.

Não existe captura bruta do pacote real de 124 bytes neste ambiente. Por isso, os valores daquele pacote não foram inventados e o aceite no APK continua separado dos testes simulados.

## Evidência direta da LIB R101

LIB: `sources/R101-lib/libg.so`  
SHA-256: `ccba455df76597e1d0ff081a07bf5e0537ad555229ad1166588d66d75ebff4ae`

Procedimento do tutorial do Jordi: packet ID, getter, vtable e encoder/decoder, complementado por Ghidra/Capstone e xrefs ARM64.

- `14110`: encode `0x3fc08c`, decode `0x148d58`.
- Construção em `0x3d1c78`: `+0x4c` recebe resultado/rank; `+0x50` recebe o resultado enviado; `+0x54` recebe rank somente nos modos nativos `6/9`; `+0x58/+0x5c` recebem mapa/slot.
- `0x3a3ce4`: distingue Solo `6` de Duo `9` e grava rank em `+0xec`.
- `0x443c20`: cria o `14110` a partir desse estado.
- `0x161428`: procura evento comparando a chave com `evento+4`. Há callers com slots `1,2,4,5,6,7` e um loop que incrementa o slot até encontrar o evento e guardá-lo em `home+0x200`.
- `TeamCreate 14350`: construtor `0x314d50`, encoder `0x4011f8`; grava `+0x50,+0x54,+0x4c` e o booleano, nessa ordem. Os callers carregam `evento+0/+4` com `ldp`.
- Evento da home: encoder `0x3605a0`, decoder `0x26e534`; a ordem começa por `+0,+4`, seguida pelos demais campos e pela DataReference em `+0x18`.
- `StartLoading 20559`: encode `0x3cca90`, decode `0x20fe1c`; encode/decode são simétricos.
- `0x35add8`: a conversão nativa produz `0,2,7,3,4,5,6,9,8,10,11` e `-1` para desconhecido. Os ramos de resultado em `0x3a3ce4` confirmam o significado dos modos usados pelo servidor.

## Removido ou substituído

- Ordem R108 `mapSlot,mapID` no `14110` e no `TeamCreate`.
- Evento da home com o slot duplicado no lugar do mapa.
- Validação `0..2` aplicada incorretamente ao primeiro campo de Solo/Duo.
- Tabela de variações incompatível: agora CoinRush `0`, BossFight `2`, Survival `7`, BountyHunter `3`, LaserBall `4`, AttackDefend `5`, Solo `6`, Duo `9`, Raid `8` e Tutorial `11`.
- Fallback que marcava o primeiro participante como local quando nenhuma flag local existia.
- Aceitação de DataReference nula como se fosse um personagem presente.

A validação continua estrita: Solo aceita ranks `1..10`, Duo `1..5`, modos comuns aceitam resultado `0..2`, contagens são verificadas por modo, references são conferidas nos CSVs V13, o payload deve terminar exatamente e deve existir exatamente um participante local no fluxo offline. Erros de cabeçalho agora informam mapa, slot, modo, resultado, campo enviado, rank e quantidade de participantes.

## Reutilizado da LIB e da implementação existente

- Codec VInt/Boolean/DataReference V13 já validado por vetores ARM64; criptografia e autenticação permanecem ativas.
- Estrutura `BattleEndService`, factory `14110` e resposta `23456`, sem criar implementação paralela.
- Layout da resposta `23456`: sete VInt, seis booleanos, participantes, experiência, references, recompensas, DataReference e campo opcional.
- `BattleRewardsManager` e `RewardTransaction`: cálculo e persistência transacional, histórico/replay e regras de recompensa já existentes.
- Resultado comum `0=vitória`, `1=derrota`, `2=empate`; em Solo/Duo, a resposta usa rank.
- Retorno à home, `GameRoomService`, perfil, Leaderboard, poder/skin e fluxo de início offline.
- O `14110` não transporta power level. Os participantes não locais criados pelo servidor continuam coerentes com o spawn de poder `10` em `LogicCharacter`; nenhum power foi fingido como se tivesse vindo do pacote.

Não foi necessário aplicar patch nativo nem substituir a LIB. O `OnPlay` solo fora da Gameroom não foi reescrito. Não foram adicionados matchmaking, batalha online, handlers de log ou respostas falsas.

## Testes

- Suíte completa na árvore: **343/343 testes aprovados**.
- Fixtures de `14110` foram corrigidos para `mapID,mapSlot` e para rank nos dois campos nativos de Solo/Duo. Eles são fixtures construídos para teste, não capturas do APK.
- Testes de leitura independente da resposta verificam todos os campos e ausência de bytes residuais.
- Cobertura específica: ranks Solo/Duo, resultados comuns, todos os tipos de location do CSV, recompensas e replay sem duplicação, home `mapID,slot`, `TeamCreate`, `StartLoading`, participantes e diagnóstico detalhado.
- A verificação do ZIP repete a mesma suíte integral após extração, sem usar a árvore de trabalho; o resultado e o hash acompanham a entrega.

## Aceite real pendente

**A R109 não foi executada no APK neste ambiente.** Não há ADB, emulador ou captura do pacote real de 124 bytes. Assim, os testes comprovam a compatibilidade estrutural implementada e a regressão do servidor, mas não substituem o aceite ponta a ponta no dispositivo. Não se declara que o erro real esteja resolvido sem esse teste.
