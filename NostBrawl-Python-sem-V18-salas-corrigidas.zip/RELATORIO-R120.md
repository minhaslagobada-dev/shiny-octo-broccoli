# NostBrawl R120 — Wizard Barley e SCID remoto

## Correção do resgate

O resgate da notificação Wizard Barley agora é auto-contido. Se uma conta antiga ainda estiver com o Barley bloqueado, o fluxo desbloqueia o Brawler `16:6`, concede a skin `29:59`, seleciona a skin quando aplicável e marca a notificação como lida em uma única transação persistente.

A resposta `LogicSkinDataCommand` envia Barley e Wizard Barley juntos no mesmo comando `203`, nessa ordem. As demais notificações de skin continuam usando somente o prêmio de skin.

A repetição do resgate é rejeitada sem duplicar Brawler ou skin. Falha de persistência desfaz todas as alterações da tentativa, permitindo nova tentativa sem perder a notificação.

## Interface LakeyID

O pacote `LakeyID-SCID-R120.zip` remove os quatro botões `X` das telas web, pois o fechamento já é processado pelo cliente nativo. As referências JavaScript e regras CSS desses botões também foram removidas. Os assets foram atualizados para `v=80` para evitar reuse de cache antigo.

## Arquitetura preservada

- O servidor do jogo continua sem o diretório raiz `SCID/`, Flask, Waitress, interface web, Gmail ou banco SCID.
- O SCID standalone permanece em pacote separado, configurado para `http://kg-bsz02.altare.global:25018`.
- HMAC, resposta assinada, nonce persistente, autenticação, restauração, vínculo, bind nativo e demais fluxos da R119 foram preservados.
- Nenhum banco de jogadores, banco SCID ou token-signing key acompanha os ZIPs.

## Validação

- 341 testes do servidor do jogo.
- 37 testes do SCID standalone, incluindo ausência dos botões `X` e das referências inválidas.
- 11 testes de integração com o SCID real, incluindo resgate pelo packet `528`, resposta combinada, persistência após recarga e rejeição de replay.

Total: 389 testes aprovados. O aceite visual do prêmio e da interface no aparelho continua sendo do usuário.

## Inicialização

Inicie cada projeto em seu próprio diretório com:

```bash
python3 main.py
```

O APK e as LIBs não foram alterados nesta revisão.
