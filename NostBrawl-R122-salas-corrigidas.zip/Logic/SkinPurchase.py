"""V18 skin-purchase rules adapted to Nost's V13/SQLite account layout."""

from Files.CsvLogic.Skins import Skins
from Logic.Rewards import RewardError, RewardTransaction


V18_PRICE_GROUPS = {
    50: (15, 27, 29, 94, 117, 118),
    80: (5, 11, 20, 25, 28, 45, 47, 56, 58, 61, 70, 88, 92, 93),
    100: (95, 97, 99, 101, 103, 105, 107, 109, 111, 113, 115),
    150: (26, 30, 44, 50, 57, 60, 64, 68, 69, 71, 72, 75, 79, 90, 91),
    250: (96, 98, 100, 102, 104, 106, 108, 110, 112, 114, 116),
    300: (49,),
}

V18_SKIN_PRICES = {
    skin: price
    for price, skins in V18_PRICE_GROUPS.items()
    for skin in skins
}

V18_GOLD_REQUIREMENTS = dict(zip(
    V18_PRICE_GROUPS[250],
    V18_PRICE_GROUPS[100],
))


class SkinPurchase:
    @staticmethod
    def price_for(skin):
        """V18 tables win; unlisted V13 skins retain their CSV price."""
        skin = int(skin)
        if skin in V18_SKIN_PRICES:
            return V18_SKIN_PRICES[skin]
        return int(Skins.getSkinPrice(skin))

    @staticmethod
    def required_skin_for(skin):
        return V18_GOLD_REQUIREMENTS.get(int(skin), 0)

    @classmethod
    def purchase(cls, player, skin, brawler):
        try:
            skin = int(skin)
            brawler = int(brawler)
        except (TypeError, ValueError):
            raise RewardError("Skin inválida") from None

        if skin not in Skins.get_skins_id():
            raise RewardError("Skin inválida")
        actual_brawler = Skins.getBrawler(skin)
        if brawler != actual_brawler:
            raise RewardError("Skin e brawler não correspondem")

        states = getattr(player, "BrawlersUnlockedState", {})
        unlocked = states.get(str(brawler), states.get(brawler, 0)) == 1
        is_default = Skins.getIsDefaultSkin(skin)
        owned = getattr(player, "UnlockedSkins", {}).get("Skins", [])
        required_skin = 0 if is_default else cls.required_skin_for(skin)
        price = 0 if is_default else cls.price_for(skin)

        transaction = RewardTransaction(player)
        if is_default:
            if unlocked:
                raise RewardError("Brawler já desbloqueado")
            transaction.add_reward("Brawler", brawler)
        else:
            if not unlocked:
                raise RewardError("A skin exige um brawler desbloqueado")
            if skin in owned:
                raise RewardError("Skin já desbloqueada")
            if required_skin and required_skin not in owned:
                raise RewardError(
                    f"Skin dourada exige a skin prateada {required_skin}"
                )
            transaction.charge("gems", price)
            transaction.add_reward("Skin", skin, brawler)

        if is_default:
            transaction.set_value("skin_id", "skinID", skin)
            transaction.set_value("brawler_id", "brawlerID", brawler)
        transaction.commit()
        result = transaction.result(100, 100)
        result.update({
            "skin": skin,
            "brawler": brawler,
            "price": price,
            "requiredSkin": required_skin,
            "isDefaultSkin": is_default,
            "v18PriceRule": skin in V18_SKIN_PRICES,
        })
        return result
