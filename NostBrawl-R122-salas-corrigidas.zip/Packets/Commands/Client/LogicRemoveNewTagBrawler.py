from Logic.Rewards import RewardTransaction
from Utils.Reader import BSMessageReader


class LogicRemoveNewTagBrawler(BSMessageReader):
    """V18 LogicRemoveNewTagBrawler adapted to Nost JSON progression."""

    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client
        self.brawler_id = None
        self.new_tag_state = None

    def decode(self):
        self.read_Vint()
        self.read_Vint()
        self.readLogicLong()
        reference = self.readScId()
        if reference[0] != 16 or reference[1] < 0:
            raise ValueError(f"Invalid brawler DataReference: {reference}")
        self.brawler_id = reference[1]
                                                                         
                                                                                
                                                            
        self.new_tag_state = self.read_int()

    def process(self):
        progression = getattr(self.player, "progression", {})
        tags = progression.get("brawlerNewTag", {}) if isinstance(progression, dict) else {}
        key = str(self.brawler_id)
        if tags.get(key, tags.get(self.brawler_id, 0)) != 1:
            return {"brawler": self.brawler_id, "changed": False}
        updated = dict(tags)
        updated[key] = 0
        transaction = RewardTransaction(self.player)
        transaction.set_progression_value("brawlerNewTag", updated)
        transaction.commit()
        return {"brawler": self.brawler_id, "changed": True}
